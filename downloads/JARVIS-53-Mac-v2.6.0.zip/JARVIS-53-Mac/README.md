# J53 All Access v2.6.0

JARVIS 53 by Dynamic Robotics is a voice-first desktop assistant for local computer actions, AI chat, productivity, and safety-aware automation. This release has one premium J53 All Access subscription (₹553 monthly or ₹5,530 annually), manual payment-reference verification, a metallic-gold J53 identity, complete static website assets, and multi-provider cloud AI failover.

## Install

- **macOS:** run `start-mac.command`.
- **Windows:** run `start-windows.bat`.
- Requires Node.js 20.9+; the first launch installs dependencies and builds the local app.
- Open `http://127.0.0.1:3000` after launch. The local app binds to loopback; do not expose it directly to the internet.

## Access and cost

The app has one **J53 All Access** subscription with monthly or annual billing; there are no Starter/Pro/Ultra feature tiers. Local access requests can be approved in the local Admin dashboard. Payment-reference approvals and API keys are stored in this installation. This package does not yet provide a shared hosted activation backend for controlling customer installations on other computers.

Generative features rotate across configured OpenRouter, NVIDIA NIM, and Google Gemini API keys. Add keys in Admin → AI Keys and select the matching provider for each key. For environment configuration, use `OPENROUTER_API_KEYS`, `NVIDIA_API_KEYS`, and `GEMINI_API_KEYS` (comma-separated for multiple keys), or their singular `*_API_KEY` variants. Optional model overrides are `OPENROUTER_MODEL`, `NVIDIA_MODEL`, and `GEMINI_MODEL`. The defaults are an economical GLM Flash route, NVIDIA Llama 3.1 8B Instruct, and Gemini Flash. Cloud inference is usage-billed and is not guaranteed free or unlimited.

Exact local commands such as `open Calculator`, `mute`, and `volume 40` are handled locally without an AI request. Natural-language questions use cloud AI and rotate between configured providers/keys, retrying another cloud route after errors, rate limits, timeouts, or unreadable structured responses. If every cloud route fails, JARVIS reports a clear error; it does not replace a failed generative answer with the local answer brain.

## Voice

In-app hold-Space/tap-mic talk works while the JARVIS window is focused. For system-wide push-to-talk, install the optional companion in `native/`, grant the OS permissions it asks for, and run it alongside JARVIS. Hold **Right Option (⌥) or Right Command (⌘)** on macOS and **F8** on Windows (override with `JARVIS_HOTKEY`). Transcription runs locally before recognized text is sent to the configured model. Conversation history and HUD preferences persist in the local SQLite database, so the HUD restores your last exchange and theme on every launch.

## Admin

Admin is OFF by default. Owner only: set JARVIS_ADMIN_MODE=1 and a strong JARVIS_ADMIN_PIN in .env, then open /admin.

## Build/test

```bash
npm install
npm run build
npm run start
```

Before publishing, verify one local command, one general question, a multi-step task, voice while another application is focused, provider rotation with valid keys, failover with one invalid/rate-limited key, and a clear error when all cloud keys are unavailable.


## API-key privacy

The release ZIP does not include `.env` or the local key store. On first launch, the launcher creates `.env` from `.env.example`. Add keys under Admin → AI Keys. Key entry is password-masked and the list endpoint returns only opaque identifiers and a fixed hidden label. Never commit `.env` or `data/keys.json`; do not paste API keys into the website.
