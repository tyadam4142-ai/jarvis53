# J53 All Access v2.4.2 — Release Notes

## Fixes
- Fixed Admin customer table's missing `PLAN_LABELS` reference; all legacy plans display as the single J53 All Access plan.
- Included the stable opaque API-key `id` in the sanitized key-pool status response, repairing TypeScript compatibility and admin removal handles.
- Preserved server-side key handling, provider failover, and masked key UI.

## Build and release notes
- Dependencies are installed by the launcher on first run.
- Keep your private `.env`, saved API-key pool, and SQLite database local; they are intentionally excluded from release ZIPs.
- Run `npm run build` on the target OS before production deployment. A full native production build is not claimed by this package's preparation step.
