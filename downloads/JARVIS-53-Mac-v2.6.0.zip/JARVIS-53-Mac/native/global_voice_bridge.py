#!/usr/bin/env python3
"""JARVIS 53 system-wide hold-to-talk companion (local audio transcription).

Hold the global hotkey while speaking in any app. Speech is transcribed locally
with faster-whisper, then the text is sent over loopback to the JARVIS app using
a per-launch bearer token. The audio is not uploaded to a speech service.

Hotkeys (hold to talk):
- macOS default: Right Option (⌥) or Right Command (⌘). F8 is intentionally NOT
  used on macOS because macOS maps it to Play/Pause media.
- Windows default: F8.
- Override with the JARVIS_HOTKEY environment variable, comma separated.
  Recognised names: right_option, right_command, right_ctrl, right_shift,
  caps_lock, insert, pause, f1..f12.
"""
from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
TOKEN_FILE = ROOT / ".j53-bridge-token"
API_URL = os.environ.get("JARVIS_LOCAL_API", "http://127.0.0.1:3000/api/voice/command")
MODEL_SIZE = os.environ.get("JARVIS_WHISPER_MODEL", "base.en")
SAMPLE_RATE = 16000
MAX_RECORD_SECONDS = 30

# ── Hotkey configuration ────────────────────────────────────────────────────
SYSTEM = platform.system()
if SYSTEM == "Darwin":
    DEFAULT_HOTKEYS = "right_option,right_command"   # macOS media keys own F8
elif SYSTEM == "Windows":
    DEFAULT_HOTKEYS = "f8"
else:
    DEFAULT_HOTKEYS = "f8,right_ctrl"

HOTKEY_SPEC = os.environ.get("JARVIS_HOTKEY", DEFAULT_HOTKEYS)

ALIASES: dict[str, str] = {
    "right_option": "alt_r",
    "right_alt": "alt_r",
    "alt_r": "alt_r",
    "right_command": "cmd_r",
    "right_cmd": "cmd_r",
    "cmd_r": "cmd_r",
    "right_ctrl": "ctrl_r",
    "right_control": "ctrl_r",
    "ctrl_r": "ctrl_r",
    "right_shift": "shift_r",
    "shift_r": "shift_r",
    "caps_lock": "caps_lock",
    "capslock": "caps_lock",
    "insert": "insert",
    "ins": "insert",
    "pause": "pause",
    "scroll_lock": "scroll",
    "page_down": "page_down",
    "page_up": "page_up",
}
for _n in range(1, 13):
    ALIASES[f"f{_n}"] = f"f{_n}"

PRETTY_NAMES: dict[str, str] = {
    "alt_r": "Right Option (⌥)" if SYSTEM == "Darwin" else "Right Alt",
    "cmd_r": "Right Command (⌘)",
    "ctrl_r": "Right Ctrl",
    "shift_r": "Right Shift",
    "caps_lock": "Caps Lock",
    "insert": "Insert",
    "pause": "Pause",
    "scroll": "Scroll Lock",
    "page_down": "Page Down",
    "page_up": "Page Up",
}


def pretty_key(name: str) -> str:
    if name.startswith("f") and name[1:].isdigit():
        return name.upper()
    return PRETTY_NAMES.get(name, name)


def resolve_hotkeys() -> list[str]:
    """Translate the env spec into pynput Key attribute names."""
    out: list[str] = []
    for raw in HOTKEY_SPEC.split(","):
        name = raw.strip().lower()
        if not name:
            continue
        canonical = ALIASES.get(name)
        if canonical and canonical not in out:
            out.append(canonical)
    return out


try:
    import numpy as np
    import sounddevice as sd
    from faster_whisper import WhisperModel
    from pynput import keyboard
except ImportError as exc:
    print(f"[JARVIS Global Voice] Missing dependency: {exc}", file=sys.stderr)
    print("Run the native installer for this platform, then start JARVIS again.", file=sys.stderr)
    raise SystemExit(2)

start_requested = threading.Event()
key_held = threading.Event()
stop_requested = threading.Event()
working = threading.Event()
cancel_current = threading.Event()


def token_value() -> str:
    try:
        return TOKEN_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def speak(text: str) -> None:
    """Use the operating system's speech engine; never build a shell command from AI text."""
    clean = " ".join(text.split()).strip()[:1200]
    if not clean:
        return
    try:
        if SYSTEM == "Darwin":
            subprocess.Popen(["say", clean], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif SYSTEM == "Windows":
            script = "Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak([Console]::In.ReadToEnd())"
            subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], input=clean, text=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20, check=False)
        else:
            print(f"JARVIS: {clean}")
    except Exception as exc:
        print(f"[TTS unavailable] {exc}")
        print(f"JARVIS: {clean}")


def send_text(text: str) -> None:
    token = token_value()
    if not token:
        speak("JARVIS global voice is not connected. Restart the JARVIS launcher.")
        return
    payload = json.dumps({"text": text}).encode("utf-8")
    request = urllib.request.Request(API_URL, data=payload, headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"}, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            data: dict[str, Any] = json.loads(response.read().decode("utf-8"))
        answer = str(data.get("say") or data.get("error") or "I did not receive a response.")
        print(f"You: {text}\nJARVIS: {answer}\nProvider: {data.get('provider', 'unknown')}\n")
        speak(answer)
    except urllib.error.HTTPError as exc:
        detail = exc.read(600).decode("utf-8", errors="replace")
        print(f"[JARVIS API {exc.code}] {detail}")
        speak("I couldn't complete that command. Check the JARVIS window and try again.")
    except Exception as exc:
        print(f"[JARVIS connection error] {exc}")
        speak("I couldn't reach the local JARVIS service. Please make sure JARVIS is running.")


def transcribe_audio(samples: list[Any], model: Any) -> str:
    if not samples:
        return ""
    audio = np.concatenate(samples, axis=0).astype(np.float32).reshape(-1) / 32768.0
    if audio.size < SAMPLE_RATE * 0.25:
        return ""
    segments, _ = model.transcribe(audio, language="en", beam_size=5, vad_filter=True, condition_on_previous_text=False)
    return " ".join(segment.text.strip() for segment in segments).strip()


def record_until_release(model: Any) -> None:
    working.set()
    cancel_current.clear()
    hot = " / ".join(pretty_key(h) for h in HOTKEY_ATTRS) or "the hotkey"
    print(f"\nListening… release {hot} to send. (Press Esc once to cancel this clip.)")
    chunks: list[Any] = []
    overflow = False

    def audio_callback(indata: Any, frames: int, time_info: Any, status: Any) -> None:
        nonlocal overflow
        if status:
            overflow = True
        if key_held.is_set() and not stop_requested.is_set() and not cancel_current.is_set():
            chunks.append(indata.copy())

    try:
        with sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype="int16", blocksize=0, callback=audio_callback):
            started = time.monotonic()
            while key_held.is_set() and not stop_requested.is_set() and not cancel_current.is_set() and (time.monotonic() - started) < MAX_RECORD_SECONDS:
                time.sleep(0.03)
        if stop_requested.is_set() or cancel_current.is_set():
            if cancel_current.is_set():
                print("[Clip cancelled]")
                speak("Cancelled.")
            return
        text = transcribe_audio(chunks, model)
        if text:
            print(f"Heard: {text}")
            send_text(text)
        else:
            speak("I didn't catch that. Please try again.")
        if overflow:
            print("[Audio warning] The microphone reported an input overflow.")
    except Exception as exc:
        print(f"[Microphone error] {exc}")
        speak("I couldn't access the microphone. Check microphone permissions for Python or Terminal.")
    finally:
        working.clear()
        cancel_current.clear()


def build_listener(hotkey_attrs: list[str]):
    """Create a fresh keyboard listener bound to the configured hotkeys.

    Esc cancels the in-progress clip only — it never terminates the companion,
    so an accidental Esc press in any app cannot silently disable JARVIS.
    To quit the companion use Ctrl+C in its console window.
    """

    def on_press(key: Any) -> None:
        try:
            if key == keyboard.Key.esc:
                if working.is_set():
                    cancel_current.set()
                return
            if getattr(key, "shift", False) and key == keyboard.Key.esc:
                stop_requested.set()
                return
        except Exception:
            pass
        if not working.is_set():
            for attr in hotkey_attrs:
                if key == getattr(keyboard.Key, attr, None):
                    key_held.set()
                    start_requested.set()
                    return

    def on_release(key: Any) -> None:
        for attr in hotkey_attrs:
            if key == getattr(keyboard.Key, attr, None):
                key_held.clear()
                return

    return keyboard.Listener(on_press=on_press, on_release=on_release)


def main() -> None:
    global HOTKEY_ATTRS
    if not token_value():
        print("No local bridge token was found. Start JARVIS 53 using its launcher first.", file=sys.stderr)
        raise SystemExit(3)

    hotkey_attrs = resolve_hotkeys()
    if not hotkey_attrs:
        print(f"No valid hotkeys in JARVIS_HOTKEY={HOTKEY_SPEC!r}. Using platform default.", file=sys.stderr)
        os.environ.pop("JARVIS_HOTKEY", None)
        hotkey_attrs = resolve_hotkeys() or (["alt_r", "cmd_r"] if SYSTEM == "Darwin" else ["f8"])
    HOTKEY_ATTRS = hotkey_attrs

    pretty = ", ".join(pretty_key(a) for a in hotkey_attrs)
    print(f"JARVIS 53 Global Voice Companion · hold {pretty} anywhere to speak · Ctrl+C to quit")
    print(f"Loading local speech model: {MODEL_SIZE} (first run may download model files)…")
    model = WhisperModel(MODEL_SIZE, device="cpu", compute_type="int8")
    print("Ready. Audio transcription stays on this computer.")

    # Supervised listener: if the OS ever tears it down, rebuild it automatically.
    while not stop_requested.is_set():
        listener = build_listener(hotkey_attrs)
        listener.start()
        try:
            while not stop_requested.is_set() and listener.is_alive():
                if start_requested.wait(0.1):
                    start_requested.clear()
                    if not working.is_set() and key_held.is_set():
                        record_until_release(model)
                time.sleep(0.02)
        except KeyboardInterrupt:
            stop_requested.set()
            break
        finally:
            key_held.clear()
            try:
                listener.stop()
            except Exception:
                pass
        if not stop_requested.is_set():
            print("[JARVIS Global Voice] Keyboard listener restarted.")


HOTKEY_ATTRS: list[str] = []

if __name__ == "__main__":
    main()
