/* JARVIS 53 — minimal, update-safe service worker.
   Strategy:
   - Never cache /api/**, HTML, or the manifest of truth responses.
   - Cache-first only for immutable static assets (icons, logo, fonts).
   - Everything else passes straight through to the network.
   Bump CACHE any time shipped static assets change. */
const CACHE = 'j53-static-v2.6.0';
const IMMUTABLE = [
  '/favicon.svg',
  '/j53-logo.svg',
  '/logo.svg',
  '/reactor.svg',
  '/icon-192.png',
  '/icon-512.png',
  '/apple-icon-180.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(IMMUTABLE)).catch(() => undefined)
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname === '/sw.js') return;

  const immutable = IMMUTABLE.includes(url.pathname) || /\.(png|svg|ico|woff2?|ttf)$/i.test(url.pathname);
  if (!immutable) return; // HTML/JS/CSS always network — never serve a stale HUD

  event.respondWith(
    caches.match(req).then(
      (hit) =>
        hit ||
        fetch(req)
          .then((res) => {
            if (res.ok) {
              const copy = res.clone();
              caches.open(CACHE).then((cache) => cache.put(req, copy)).catch(() => undefined);
            }
            return res;
          })
          .catch(() => caches.match('/favicon.svg'))
    )
  );
});
