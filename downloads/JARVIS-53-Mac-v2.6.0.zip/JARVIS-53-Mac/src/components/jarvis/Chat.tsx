'use client';

/**
 * JARVIS 53 — conversation stream.
 * Typewriter reveal (wall-clock, background-proof), live tool-execution cards
 * with inline risk confirmation, hold-to-talk (Web Speech API) with a Web Audio
 * frequency analyser, markdown replies, and background-tab resilience.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { useJarvis, type Message as Msg, type ToolEvent } from './store';
import { CheckCircle2, XCircle, ShieldAlert, ShieldCheck, HelpCircle, Mic, MicOff, Volume2, VolumeX, Trash2, Send, ArrowDown } from 'lucide-react';

/* ── Platform-aware global hotkey hint (matches native/global_voice_bridge.py) ── */
function usePlatformHint() {
  const [hint, setHint] = useState<{ key: string; companion: string }>({ key: 'F8', companion: 'Global Voice Companion' });
  useEffect(() => {
    const ua = navigator.userAgent || navigator.platform || '';
    const isMac = /Mac|iPhone|iPad|iPod/i.test(ua);
    setHint(
      isMac
        ? { key: 'Right Option ⌥ (or Right ⌘)', companion: 'Global Voice Companion' }
        : { key: 'F8', companion: 'Global Voice Companion' }
    );
  }, []);
  return hint;
}

/* ── Tool card ── */
function ToolCard({ event, msgId, index }: { event: ToolEvent; msgId: string; index: number }) {
  const updateToolEvent = useJarvis((s) => s.updateToolEvent);
  const approveTool = useJarvis((s) => s.approveTool);

  const icon =
    event.status === 'done' ? (
      <CheckCircle2 className="h-4 w-4 shrink-0 text-[var(--j53-green)]" />
    ) : event.status === 'error' ? (
      <XCircle className="h-4 w-4 shrink-0 text-[var(--j53-red)]" />
    ) : event.status === 'confirm_required' ? (
      <ShieldAlert className="h-4 w-4 shrink-0 text-[var(--j53-gold)]" />
    ) : event.status === 'unsupported' ? (
      <HelpCircle className="h-4 w-4 shrink-0 text-[var(--j53-muted)]" />
    ) : (
      <span className="j53-spinner" />
    );

  const argSummary = Object.entries(event.args ?? {})
    .filter(([, v]) => v !== '' && v !== undefined)
    .map(([k, v]) => `${k}: ${String(v).slice(0, 60)}`)
    .slice(0, 3)
    .join(' · ');

  return (
    <div className="j53-fadeup mt-2 rounded-lg border border-[rgba(var(--j53-accent-rgb),0.14)] bg-[rgba(var(--j53-bg-rgb),0.6)] p-3">
      <div className="flex items-start gap-2.5">
        {icon}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-[12.5px] text-[var(--j53-accent)]">{event.tool}</span>
            {event.risk !== 'low' && (
              <span className={`j53-pill ${event.risk === 'high' ? 'text-[var(--j53-red)]' : 'text-[var(--j53-gold)]'}`} style={{ fontSize: 9, padding: '2px 8px' }}>
                {event.risk.toUpperCase()} RISK
              </span>
            )}
            <span className="j53-label" style={{ fontSize: 9 }}>
              {event.status === 'done' ? 'executed' : event.status}
            </span>
          </div>
          {argSummary && <p className="mt-0.5 truncate font-mono text-[11px] text-[var(--j53-muted)]">{argSummary}</p>}
          {event.output && event.status !== 'confirm_required' && (
            <p className="mt-1.5 whitespace-pre-wrap break-words text-[13px] leading-5 text-[var(--j53-text-2)]">{event.output.slice(0, 700)}</p>
          )}
          {event.status === 'confirm_required' && (
            <div className="mt-2.5 flex flex-wrap gap-2">
              <button className="j53-btn" style={{ padding: '6px 14px' }} onClick={() => approveTool(msgId, index)}>
                <ShieldCheck className="h-3.5 w-3.5" /> Approve & Run
              </button>
              <button className="j53-btn j53-btn--danger" style={{ padding: '6px 14px' }} onClick={() => updateToolEvent(msgId, index, { status: 'error', output: 'Cancelled by operator.' })}>
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ── Typewriter message — wall-clock driven, so a throttled background tab
      instantly catches up on return instead of crawling for a minute. ── */
function JarvisText({ text, done, onDone }: { text: string; done: boolean; onDone: () => void }) {
  const [n, setN] = useState(done ? text.length : 0);
  const startRef = useRef(0);

  useEffect(() => {
    if (done) {
      setN(text.length);
      return;
    }
    // Characters per second scales with length: long answers still land in ~2.5s.
    const duration = Math.min(2600, 450 + text.length * 14);
    const cps = text.length / duration;
    startRef.current = performance.now();
    let raf = 0;
    let finished = false;
    const tick = () => {
      const elapsed = performance.now() - startRef.current;
      const next = Math.min(text.length, Math.floor(elapsed * cps));
      setN(next);
      if (next >= text.length) {
        finished = true;
        onDone();
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      // Ensure completion even if unmounted mid-reveal.
      if (!finished && n < text.length) setN(text.length);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, done]);

  if (done && n >= text.length) {
    return (
      <div className="j53-md text-[15px] leading-6 text-[var(--j53-text)]">
        <ReactMarkdown
          components={{
            a: (props) => <a {...props} target="_blank" rel="noreferrer" className="text-[var(--j53-accent)] underline decoration-[rgba(var(--j53-accent-rgb),0.4)] underline-offset-2 hover:decoration-[var(--j53-accent)]" />,
            code: ({ className, children, ...props }) => {
              const isBlock = /language-/.test(className ?? '');
              if (isBlock) return <code className={className} {...props}>{children}</code>;
              return <code className="rounded bg-[rgba(var(--j53-accent-rgb),0.1)] px-1.5 py-0.5 font-mono text-[13px] text-[var(--j53-accent2)]" {...props}>{children}</code>;
            },
          }}
        >
          {text}
        </ReactMarkdown>
      </div>
    );
  }
  return (
    <p className="whitespace-pre-wrap break-words text-[15px] leading-6 text-[var(--j53-text)]">
      {text.slice(0, n)}
      {n < text.length && <span className="j53-caret text-[var(--j53-accent)]">▍</span>}
    </p>
  );
}

function Bubble({ m }: { m: Msg }) {
  const updateMessage = useJarvis((s) => s.updateMessage);
  if (m.role === 'user') {
    return (
      <div className="j53-fadeup flex justify-end">
        <div className="max-w-[85%] rounded-xl rounded-br-sm border border-[rgba(var(--j53-accent-rgb),0.25)] bg-[rgba(var(--j53-accent-rgb),0.07)] px-4 py-2.5 text-[15px] leading-6 text-[var(--j53-text)]">
          {m.text}
        </div>
      </div>
    );
  }
  return (
    <div className="j53-fadeup flex justify-start">
      <div className="w-full max-w-full">
        {m.text ? (
          <div className="j53-panel px-4 py-3">
            <div className="mb-1 flex items-center gap-2">
              <span className="j53-label" style={{ color: 'var(--j53-accent)' }}>
                JARVIS 53
              </span>
              {m.provider && <span className={`j53-pill ${m.provider === 'unavailable' ? 'j53-pill--warn' : ''}`} style={{ fontSize: 9 }}>{m.provider === 'builtin' ? 'MANAGED AI' : m.provider === 'openrouter' ? 'OPENROUTER' : m.provider === 'nvidia' ? 'NVIDIA NIM' : m.provider === 'gemini' ? 'GOOGLE GEMINI' : m.provider === 'unavailable' ? 'CLOUD AI UNAVAILABLE' : 'LOCAL ACTION'}</span>}
              {m.model && <span className="j53-pill" style={{ fontSize: 9, maxWidth: 260, overflow: 'hidden', textOverflow: 'ellipsis' }} title={`Model: ${m.model}`}>{m.model}</span>}
            </div>
            {m.routeNote && <p className="mb-2 text-[11px] leading-4 text-[var(--j53-muted)]">{m.routeNote}</p>}
            <JarvisText text={m.text} done={Boolean(m.revealed)} onDone={() => updateMessage(m.id, { revealed: true })} />
          </div>
        ) : (
          <div className="j53-panel inline-flex items-center gap-2 px-4 py-3">
            <span className="j53-spinner" />
            <span className="j53-label">processing</span>
            <span className="j53-typing">
              <span />
              <span />
              <span />
            </span>
          </div>
        )}
        {m.tools?.map((t, i) => (
          <ToolCard key={`${m.id}-${i}`} event={t} msgId={m.id} index={i} />
        ))}
      </div>
    </div>
  );
}

/* ── Voice input: continuous + auto-restart + background-resume.
      Hold Space, or tap the mic to start/stop. ── */
function useSpeech(onFinal: (text: string) => void) {
  const [supported, setSupported] = useState(false);
  const recRef = useRef<any>(null);
  const wantRef = useRef(false);
  const tapRef = useRef(false);
  const committedRef = useRef('');
  const sessFinalRef = useRef('');
  const sessInterimRef = useRef('');
  const silenceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const failsRef = useRef(0);
  const resumeRef = useRef(false); // recognition died while tab hidden — revive on focus
  const onFinalRef = useRef(onFinal);
  const setOrbMode = useJarvis((s) => s.setOrbMode);
  const setMicLevel = useJarvis((s) => s.setMicLevel);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const meterTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => { onFinalRef.current = onFinal; }, [onFinal]);

  useEffect(() => {
    const w = window as any;
    setSupported(Boolean(w.SpeechRecognition || w.webkitSpeechRecognition));
    return () => { wantRef.current = false; try { recRef.current?.abort(); } catch {} };
  }, []);

  const startAudio = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!wantRef.current) { stream.getTracks().forEach((t) => t.stop()); return; }
      streamRef.current = stream;
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      ctx.createMediaStreamSource(stream).connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      // setInterval (not rAF) keeps the level meter alive even when the tab is
      // backgrounded — requestAnimationFrame is frozen in hidden tabs.
      if (meterTimerRef.current) clearInterval(meterTimerRef.current);
      meterTimerRef.current = setInterval(() => {
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) sum += data[i] * data[i];
        setMicLevel(Math.min(1, Math.sqrt(sum / data.length) / 90));
      }, 66);
    } catch { /* mic level meter is cosmetic */ }
  }, [setMicLevel]);

  const stopAudio = useCallback(() => {
    if (meterTimerRef.current) { clearInterval(meterTimerRef.current); meterTimerRef.current = null; }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    audioCtxRef.current?.close().catch(() => undefined);
    audioCtxRef.current = null;
    setMicLevel(0);
  }, [setMicLevel]);

  const clearSilence = () => { if (silenceRef.current) { clearTimeout(silenceRef.current); silenceRef.current = null; } };

  const finalize = useCallback(() => {
    clearSilence();
    wantRef.current = false;
    resumeRef.current = false;
    setOrbMode('idle');
    stopAudio();
    const text = `${committedRef.current} ${sessFinalRef.current} ${sessInterimRef.current}`.replace(/\s+/g, ' ').trim();
    committedRef.current = ''; sessFinalRef.current = ''; sessInterimRef.current = '';
    if (text) onFinalRef.current(text);
  }, [setOrbMode, stopAudio]);

  const stop = useCallback(() => {
    wantRef.current = false;
    resumeRef.current = false;
    clearSilence();
    try { recRef.current?.stop(); } catch { finalize(); }
    // Safety net: if the browser never fires onend, still send what we heard.
    setTimeout(() => { if (recRef.current) { recRef.current = null; finalize(); } }, 1500);
  }, [finalize]);

  const armSilence = useCallback(() => {
    clearSilence();
    if (tapRef.current) silenceRef.current = setTimeout(() => stop(), 3000); // tap mode: 3s of quiet ends it
  }, [stop]);

  const begin = useCallback(() => {
    const w = window as any;
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) return false;
    try {
      const rec = new SR();
      rec.continuous = true;
      rec.interimResults = true;
      rec.maxAlternatives = 1;
      rec.lang = navigator.language || 'en-US';
      rec.onresult = (e: any) => {
        failsRef.current = 0;
        let f = '', i = '';
        for (let k = 0; k < e.results.length; k++) {
          const r = e.results[k];
          if (r.isFinal) f += r[0].transcript + ' '; else i += r[0].transcript;
        }
        sessFinalRef.current = f; sessInterimRef.current = i;
        armSilence();
      };
      rec.onerror = (e: any) => {
        if (e.error === 'not-allowed' || e.error === 'service-not-allowed') { wantRef.current = false; }
        else if (e.error === 'network') { failsRef.current += 3; }
        // 'aborted' / 'no-speech' while hidden: do NOT count as a failure — we resume on focus.
      };
      rec.onend = () => {
        committedRef.current = `${committedRef.current} ${sessFinalRef.current} ${sessInterimRef.current}`.trim();
        sessFinalRef.current = ''; sessInterimRef.current = '';
        if (!wantRef.current) {
          recRef.current = null;
          finalize();
          return;
        }
        // Chrome kills SpeechRecognition the moment the tab is hidden.
        // Park the session and revive it when the tab is visible again.
        if (typeof document !== 'undefined' && document.hidden) {
          resumeRef.current = true;
          return;
        }
        if (failsRef.current < 4) {
          failsRef.current += 1; // browser ended the session on its own (silence/timeout) — keep listening
          setTimeout(() => { if (wantRef.current) { if (!begin()) finalize(); } }, 150);
        } else {
          recRef.current = null;
          finalize();
        }
      };
      rec.start();
      recRef.current = rec;
      return true;
    } catch { return false; }
  }, [armSilence, finalize]);

  /* Revive parked sessions + audio when the tab becomes visible again. */
  useEffect(() => {
    const onVisible = () => {
      if (document.hidden) return;
      void audioCtxRef.current?.resume().catch(() => undefined);
      if (wantRef.current && resumeRef.current && !recRef.current) {
        resumeRef.current = false;
        failsRef.current = 0;
        setTimeout(() => { if (wantRef.current && !recRef.current) { if (!begin()) finalize(); } }, 220);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [begin, finalize]);

  const start = useCallback((mode: 'hold' | 'tap' = 'hold') => {
    if (wantRef.current) return true;
    committedRef.current = ''; sessFinalRef.current = ''; sessInterimRef.current = ''; failsRef.current = 0;
    resumeRef.current = false;
    wantRef.current = true;
    tapRef.current = mode === 'tap';
    if (!begin()) { wantRef.current = false; return false; }
    setOrbMode('listening');
    void startAudio();
    armSilence();
    return true;
  }, [begin, setOrbMode, startAudio, armSilence]);

  const toggle = useCallback(() => { if (wantRef.current) stop(); else start('tap'); }, [start, stop]);

  return { supported, start, stop, toggle };
}

/* ── Main chat panel ── */
const SUGGESTIONS = [
  'Open Spotify and play focus music',
  'Set volume to 30',
  "What's the weather?",
  'Draft an email to Sam about the launch',
  'Battery status',
  'Take a note: ship the release notes',
];

export default function Chat() {
  const messages = useJarvis((s) => s.messages);
  const busy = useJarvis((s) => s.busy);
  const send = useJarvis((s) => s.send);
  const orbMode = useJarvis((s) => s.orbMode);
  const ttsEnabled = useJarvis((s) => s.ttsEnabled);
  const toggleTts = useJarvis((s) => s.toggleTts);
  const clearMessages = useJarvis((s) => s.clearMessages);

  const [input, setInput] = useState('');
  const [pinned, setPinned] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const holdingRef = useRef(false);
  const submitVoice = useCallback((text: string) => { void send(text); }, [send]);
  const { supported: voiceSupported, start, stop, toggle } = useSpeech(submitVoice);
  const hint = usePlatformHint();

  /* Smart auto-scroll: follow the stream only when the operator is at the bottom. */
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || !pinned) return;
    el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [messages, pinned]);

  const onStreamScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    setPinned(el.scrollHeight - el.scrollTop - el.clientHeight < 90);
  }, []);

  /* Global push-to-talk — Space when not typing. If the window loses focus
     mid-hold (alt-tab), send what we captured instead of leaving a dead mic. */
  useEffect(() => {
    const isTyping = (el: EventTarget | null) => {
      const node = el as HTMLElement | null;
      return Boolean(node && (node.tagName === 'INPUT' || node.tagName === 'TEXTAREA' || node.isContentEditable));
    };
    const down = (e: KeyboardEvent) => {
      if (e.code !== 'Space' || isTyping(e.target) || busy || holdingRef.current) return;
      e.preventDefault();
      holdingRef.current = true;
      if (voiceSupported) start('hold');
    };
    const up = (e: KeyboardEvent) => {
      if (e.code !== 'Space' || !holdingRef.current) return;
      holdingRef.current = false;
      if (voiceSupported) stop();
    };
    const onBlur = () => {
      if (holdingRef.current) {
        holdingRef.current = false;
        if (voiceSupported) stop();
      }
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', onBlur);
    };
  }, [busy, voiceSupported, start, stop]);

  /* "/" focuses the composer from anywhere (when not already typing). */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const node = e.target as HTMLElement | null;
      const typing = node && (node.tagName === 'INPUT' || node.tagName === 'TEXTAREA' || node.isContentEditable);
      if (e.key === '/' && !typing) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const submit = () => {
    if (!input.trim() || busy) return;
    void send(input);
    setInput('');
    setPinned(true);
  };

  const listening = orbMode === 'listening';
  const showJump = !pinned && messages.length > 0;

  return (
    <div className="relative flex h-full min-h-0 flex-col">
      {/* stream */}
      <div ref={scrollRef} onScroll={onStreamScroll} className="j53-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-1 pb-4">
        {messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center gap-5 text-center">
            <div>
              <p className="j53-display text-lg tracking-[0.2em] text-[var(--j53-accent)]/80">GOOD TO SEE YOU AGAIN</p>
              <p className="mt-2 max-w-md text-sm leading-6 text-[var(--j53-muted)]">
                Hold <kbd className="j53-kbd">Space</kbd> while this window is active, tap the mic, or hold{' '}
                <kbd className="j53-kbd">{hint.key}</kbd> in any app after installing the {hint.companion}.
                {voiceSupported ? '' : ' Voice needs Chrome or Edge.'}
              </p>
            </div>
            <div className="flex max-w-lg flex-wrap items-center justify-center gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  className="j53-chip"
                  onClick={() => { if (!busy) { void send(s); setPinned(true); } }}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
        {messages.map((m) => (
          <Bubble key={m.id} m={m} />
        ))}
      </div>

      {/* jump to latest */}
      {showJump && (
        <button
          type="button"
          aria-label="Jump to latest"
          className="j53-btn j53-fadeup absolute bottom-24 right-4 z-10 !rounded-full !px-3 !py-3 shadow-lg"
          onClick={() => { setPinned(true); scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }); }}
        >
          <ArrowDown className="h-4 w-4" />
        </button>
      )}

      {/* composer */}
      <div className="j53-panel mt-2 p-3">
        <div className="flex items-center gap-2">
          <button
            className={`j53-btn ${listening ? 'j53-pulse' : ''}`}
            style={{ padding: '11px 14px' }}
            title={voiceSupported ? 'Tap to talk, tap again to send (or pause 3s). You can also hold Space. Any-app talk: hold the global hotkey with the Global Voice Companion.' : 'Voice not supported in this browser — try current Chrome or Edge'}
            aria-label="Tap to talk, tap again to send"
            onClick={() => { if (voiceSupported) toggle(); }}
            type="button"
          >
            {listening ? <Mic className="h-4.5 w-4.5 text-[var(--j53-accent)]" /> : <MicOff className="h-4.5 w-4.5" />}
          </button>

          <input
            ref={inputRef}
            className="j53-input flex-1"
            placeholder={listening ? 'Listening… tap the mic or release Space to send' : 'Ask JARVIS or type a command…  (press / to focus)'}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                submit();
              }
            }}
            aria-label="Message JARVIS"
          />

          <button className="j53-btn" style={{ padding: '11px 14px' }} onClick={toggleTts} title={ttsEnabled ? 'Voice replies ON' : 'Voice replies OFF'} aria-label="Toggle spoken replies" type="button">
            {ttsEnabled ? <Volume2 className="h-4.5 w-4.5" /> : <VolumeX className="h-4.5 w-4.5" />}
          </button>
          <button className="j53-btn" style={{ padding: '11px 14px' }} onClick={clearMessages} title="Clear conversation" aria-label="Clear conversation" type="button">
            <Trash2 className="h-4.5 w-4.5" />
          </button>
          <button className="j53-btn j53-btn--gold" onClick={submit} disabled={busy || !input.trim()} aria-label="Send" type="button">
            <Send className="h-4.5 w-4.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
