'use client';

/**
 * JARVIS 53 — Productivity Studio: tasks, notes, prompt library.
 * Local-first (localStorage) with JARVIS-native actions via the chat.
 */
import { useEffect, useState } from 'react';
import { useJarvis } from './store';
import { CheckSquare, ListChecks, NotebookPen, Sparkles, Square, Trash2, Wand2 } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  done: boolean;
  ts: number;
}
interface Note {
  id: string;
  title: string;
  body: string;
  ts: number;
}

const PROMPTS = [
  'Run a system report',
  "What's the weather in New York?",
  'Open Spotify and play deep focus',
  'Set volume to 25 and mute notifications',
  'Search my files for invoice',
  'Take a note: call the supplier at 4pm',
  'Remind me to stretch in 45 minutes',
  'Create a calendar event: Design review, tomorrow 14:00, 45 minutes',
  'Draft an email to alex@starkindustries.com about the Q3 launch timeline',
  'Headlines from around the world',
  'Convert 100 USD to INR',
  'Snap my windows side by side',
];

export default function Studio() {
  const send = useJarvis((s) => s.send);
  const [tab, setTab] = useState<'tasks' | 'notes' | 'prompts'>('tasks');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [taskInput, setTaskInput] = useState('');
  const [noteTitle, setNoteTitle] = useState('');
  const [noteBody, setNoteBody] = useState('');

  useEffect(() => {
    try {
      setTasks(JSON.parse(localStorage.getItem('j53_tasks') ?? '[]'));
      setNotes(JSON.parse(localStorage.getItem('j53_notes') ?? '[]'));
    } catch {
      /* fresh start */
    }
  }, []);

  function persistTasks(next: Task[]) {
    setTasks(next);
    localStorage.setItem('j53_tasks', JSON.stringify(next));
  }
  function persistNotes(next: Note[]) {
    setNotes(next);
    localStorage.setItem('j53_notes', JSON.stringify(next));
  }

  return (
    <div className="mx-auto w-full max-w-3xl">
      <div className="mb-4 flex gap-2">
        {(
          [
            ['tasks', <ListChecks key="t" className="h-3.5 w-3.5" />],
            ['notes', <NotebookPen key="n" className="h-3.5 w-3.5" />],
            ['prompts', <Sparkles key="p" className="h-3.5 w-3.5" />],
          ] as const
        ).map(([id, icon]) => (
          <button key={id} className={`j53-btn flex-1 ${tab === id ? 'j53-glow' : ''}`} onClick={() => setTab(id)} type="button">
            {icon} {id.toUpperCase()}
          </button>
        ))}
      </div>

      {tab === 'tasks' && (
        <div className="j53-panel p-5">
          <div className="flex gap-2">
            <input
              className="j53-input flex-1"
              placeholder="Add a task… (JARVIS can also add tasks via voice)"
              value={taskInput}
              onChange={(e) => setTaskInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && taskInput.trim()) {
                  persistTasks([{ id: Math.random().toString(36).slice(2), title: taskInput.trim(), done: false, ts: Date.now() }, ...tasks]);
                  setTaskInput('');
                }
              }}
              aria-label="New task"
            />
            <button
              className="j53-btn"
              onClick={() => {
                if (!taskInput.trim()) return;
                persistTasks([{ id: Math.random().toString(36).slice(2), title: taskInput.trim(), done: false, ts: Date.now() }, ...tasks]);
                setTaskInput('');
              }}
              type="button"
            >
              Add
            </button>
          </div>
          <div className="j53-scroll mt-4 max-h-[52vh] space-y-2 overflow-y-auto pr-1">
            {tasks.length === 0 && <p className="text-sm text-[var(--j53-muted)]">Clean slate. Add a task, or say &ldquo;remind me to…&rdquo; in the console.</p>}
            {tasks.map((t) => (
              <div key={t.id} className="flex items-center gap-3 rounded-lg border border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.55)] px-3 py-2.5">
                <button
                  onClick={() => persistTasks(tasks.map((x) => (x.id === t.id ? { ...x, done: !x.done } : x)))}
                  aria-label={t.done ? 'Mark incomplete' : 'Mark complete'}
                  type="button"
                >
                  {t.done ? <CheckSquare className="h-4.5 w-4.5 text-[var(--j53-green)]" /> : <Square className="h-4.5 w-4.5 text-[var(--j53-muted)]" />}
                </button>
                <span className={`flex-1 text-[14px] ${t.done ? 'text-[var(--j53-muted)] line-through' : 'text-[var(--j53-text)]'}`}>{t.title}</span>
                <button onClick={() => persistTasks(tasks.filter((x) => x.id !== t.id))} aria-label="Delete task" type="button">
                  <Trash2 className="h-4 w-4 text-[var(--j53-muted)] transition-colors hover:text-[var(--j53-red)]" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'notes' && (
        <div className="j53-panel p-5">
          <div className="grid gap-2 sm:grid-cols-[1fr_2fr_auto]">
            <input className="j53-input" placeholder="Title" value={noteTitle} onChange={(e) => setNoteTitle(e.target.value)} aria-label="Note title" />
            <input className="j53-input" placeholder="Note content…" value={noteBody} onChange={(e) => setNoteBody(e.target.value)} aria-label="Note body" />
            <button
              className="j53-btn"
              onClick={() => {
                if (!noteBody.trim()) return;
                persistNotes([{ id: Math.random().toString(36).slice(2), title: noteTitle.trim() || 'Quick note', body: noteBody.trim(), ts: Date.now() }, ...notes]);
                setNoteTitle('');
                setNoteBody('');
              }}
              type="button"
            >
              Save
            </button>
          </div>
          <div className="j53-scroll mt-4 max-h-[52vh] space-y-2 overflow-y-auto pr-1">
            {notes.length === 0 && <p className="text-sm text-[var(--j53-muted)]">No notes yet. Say &ldquo;take a note…&rdquo; and JARVIS writes it down.</p>}
            {notes.map((n) => (
              <div key={n.id} className="rounded-lg border border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.55)] px-3 py-2.5">
                <div className="flex items-center justify-between">
                  <p className="text-[13.5px] font-semibold text-[var(--j53-accent)]">{n.title}</p>
                  <button onClick={() => persistNotes(notes.filter((x) => x.id !== n.id))} aria-label="Delete note" type="button">
                    <Trash2 className="h-4 w-4 text-[var(--j53-muted)] transition-colors hover:text-[var(--j53-red)]" />
                  </button>
                </div>
                <p className="mt-1 whitespace-pre-wrap text-[13px] leading-5 text-[var(--j53-text-2)]">{n.body}</p>
                <p className="j53-label mt-1.5" style={{ fontSize: 8 }}>
                  {new Date(n.ts).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'prompts' && (
        <div className="j53-panel p-5">
          <p className="j53-label mb-1">prompt library</p>
          <p className="mb-4 text-sm text-[var(--j53-muted)]">One-tap commands that show off the full tool registry.</p>
          <div className="flex flex-wrap gap-2">
            {PROMPTS.map((p) => (
              <button
                key={p}
                className="flex items-center gap-1.5 rounded-full border border-[rgba(var(--j53-accent-rgb),0.18)] bg-[rgba(var(--j53-accent-rgb),0.05)] px-3.5 py-2 text-[13px] text-[var(--j53-text-2)] transition-all hover:border-[rgba(var(--j53-accent-rgb),0.45)] hover:text-[var(--j53-text)]"
                onClick={() => {
                  send(p);
                  useJarvis.getState().setView('console');
                }}
                type="button"
              >
                <Wand2 className="h-3.5 w-3.5 text-[var(--j53-accent)]" /> {p}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
