'use client';

/**
 * JARVIS 53 — central client state.
 */
import { create } from 'zustand';

export type Risk = 'low' | 'medium' | 'high';

export interface ToolEvent {
  tool: string;
  label: string;
  risk: Risk;
  status: 'done' | 'error' | 'confirm_required' | 'unsupported' | 'running';
  output: string;
  args: Record<string, unknown>;
  available: boolean;
}

export interface Message {
  id: string;
  role: 'user' | 'jarvis';
  text: string;
  tools?: ToolEvent[];
  ts: number;
  provider?: string;
  model?: string;
  routeNote?: string;
  revealed?: boolean; // typewriter finished
}

export interface Announcement {
  id: number;
  title: string;
  body: string;
  level: string;
}

export type Phase = 'boot' | 'gate' | 'app';
export type OrbMode = 'idle' | 'listening' | 'thinking' | 'speaking';
export type View = 'console' | 'studio' | 'support' | 'comms';

export interface SystemStatus {
  platform: string;
  platformLabel: string;
  host: string;
  uptimeSec: number;
  cpuCount: number;
  cpuModel: string;
  loadPct: number;
  memPct: number;
  memUsed: string;
  memTotal: string;
  battery: string | null;
  wifi: string | null;
}

export interface Health {
  version: string;
  platform: string;
  platformLabel: string;
  aiProvider: string;
  keyPool: { total: number; healthy: number };
  toolCount: number;
  nativeTools: number;
}

/* ── Appearance engine ── */
export type ThemeId = 'midnight' | 'mark42' | 'matrix' | 'violet' | 'solar' | 'titanium';
export type GlowLevel = 'off' | 'subtle' | 'standard' | 'extreme';
export type FontMode = 'orbitron' | 'mono' | 'sleek';
export type Density = 'comfortable' | 'compact';

export interface Appearance {
  theme: ThemeId;
  accent: string | null; // custom hex override, null = theme default
  glow: GlowLevel;
  scanlines: boolean;
  grid: boolean;
  sweep: boolean;
  font: FontMode;
  density: Density;
}

export const DEFAULT_APPEARANCE: Appearance = {
  theme: 'midnight',
  accent: null,
  glow: 'subtle',
  scanlines: false,
  grid: false,
  sweep: false,
  font: 'sleek',
  density: 'comfortable',
};

const APPEARANCE_KEY = 'j53_appearance_v2_1';

export function hexToRgbTriplet(hex: string): string {
  const m = hex.replace('#', '');
  const full = m.length === 3 ? m.split('').map((c) => c + c).join('') : m;
  const n = parseInt(full, 16);
  return `${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}`;
}

/** Push appearance onto <html> as data-attrs + inline vars. */
export function applyAppearance(a: Appearance) {
  if (typeof document === 'undefined') return;
  const el = document.documentElement;
  el.dataset.j53Theme = a.theme;
  el.dataset.j53Glow = a.glow;
  el.dataset.j53Scan = a.scanlines ? 'on' : 'off';
  el.dataset.j53Grid = a.grid ? 'on' : 'off';
  el.dataset.j53Sweep = a.sweep ? 'on' : 'off';
  el.dataset.j53Font = a.font;
  el.dataset.j53Density = a.density;
  if (a.accent) {
    el.style.setProperty('--j53-accent', a.accent);
    el.style.setProperty('--j53-accent-rgb', hexToRgbTriplet(a.accent));
  } else {
    el.style.removeProperty('--j53-accent');
    el.style.removeProperty('--j53-accent-rgb');
  }
}

export function loadAppearance(): Appearance {
  if (typeof window === 'undefined') return DEFAULT_APPEARANCE;
  try {
    const raw = window.localStorage.getItem(APPEARANCE_KEY);
    if (!raw) return DEFAULT_APPEARANCE;
    return { ...DEFAULT_APPEARANCE, ...(JSON.parse(raw) as Partial<Appearance>) };
  } catch {
    return DEFAULT_APPEARANCE;
  }
}

export function saveAppearance(a: Appearance) {
  try {
    window.localStorage.setItem(APPEARANCE_KEY, JSON.stringify(a));
  } catch {
    /* private mode */
  }
}

interface JarvisState {
  phase: Phase;
  setPhase: (p: Phase) => void;

  phone: string | null;
  plan: string | null;
  name: string | null;
  setCustomer: (p: { phone: string; plan: string; name: string | null }) => void;

  historyLoaded: boolean;
  hydrate: () => Promise<void>;

  announcement: Announcement | null;
  setAnnouncement: (a: Announcement | null) => void;

  health: Health | null;
  setHealth: (h: Health) => void;

  systemStatus: SystemStatus | null;
  setSystemStatus: (s: SystemStatus) => void;

  messages: Message[];
  busy: boolean;
  addMessage: (m: Message) => void;
  updateMessage: (id: string, patch: Partial<Message>) => void;
  updateToolEvent: (msgId: string, index: number, patch: Partial<ToolEvent>) => void;
  clearMessages: () => void;

  toolLogs: Array<{ id: string; tool: string; label: string; status: ToolEvent['status']; at: number; output: string }>;
  pushToolLog: (l: { tool: string; label: string; status: ToolEvent['status']; output: string }) => void;

  orbMode: OrbMode;
  setOrbMode: (m: OrbMode) => void;
  micLevel: number;
  setMicLevel: (v: number) => void;

  view: View;
  setView: (v: View) => void;

  appearance: Appearance;
  setAppearance: (patch: Partial<Appearance>) => void;
  resetAppearance: () => void;
  customizeOpen: boolean;
  setCustomizeOpen: (v: boolean) => void;

  ttsEnabled: boolean;
  toggleTts: () => void;

  pttKey: string;
  setPttKey: (k: string) => void;

  cmdOpen: boolean;
  setCmdOpen: (v: boolean) => void;

  send: (text: string) => Promise<void>;
  executeQuick: (toolId: string, args?: Record<string, unknown>, confirmed?: boolean) => Promise<ToolEvent | null>;
  approveTool: (msgId: string, index: number) => Promise<void>;
}

const uid = () => Math.random().toString(36).slice(2, 10);

async function api<T>(url: string, body?: unknown): Promise<T> {
  const res = await fetch(url, body !== undefined ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : { cache: 'no-store' });
  const data = (await res.json()) as T & { error?: string };
  if (!res.ok) throw new Error(data?.error || `Request failed (${res.status}).`);
  return data;
}

/** Fire-and-forget write of HUD preferences to the local database (debounced per call site). */
let prefSyncTimer: ReturnType<typeof setTimeout> | null = null;
function syncPreferences(payload: Appearance & { ttsEnabled: boolean }) {
  const phone = useJarvis.getState().phone;
  if (!phone) return; // preferences sync only for activated customers
  if (prefSyncTimer) clearTimeout(prefSyncTimer);
  prefSyncTimer = setTimeout(() => {
    void fetch('/api/preferences', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ phone, data: payload }),
    }).catch(() => undefined);
  }, 700);
}

/** Persist one conversation turn so history survives restarts. */
function persistMessage(m: { id: string; role: 'user' | 'jarvis'; text: string; provider?: string; model?: string }) {
  const phone = useJarvis.getState().phone;
  void fetch('/api/chat/history', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ id: m.id, phone, role: m.role, content: m.text, provider: m.provider, model: m.model }),
  }).catch(() => undefined);
}

export const useJarvis = create<JarvisState>((set, get) => ({
  phase: 'boot',
  setPhase: (p) => set({ phase: p }),

  phone: null,
  plan: null,
  name: null,
  setCustomer: (p) => set({ phone: p.phone, plan: p.plan, name: p.name }),

  historyLoaded: false,
  /** Pull conversation memory + preferences from the local database. */
  hydrate: async () => {
    const phone = get().phone;
    try {
      const [hist, prefs] = await Promise.all([
        api<{ messages: Array<{ id: string; role: 'user' | 'jarvis'; text: string; provider?: string; model?: string; ts: number }> }>(
          `/api/chat/history${phone ? `?phone=${encodeURIComponent(phone)}` : ''}`
        ).catch(() => ({ messages: [] })),
        phone ? api<{ data: Partial<Appearance> & { ttsEnabled?: boolean } | null }>(`/api/preferences?phone=${encodeURIComponent(phone)}`).catch(() => ({ data: null })) : Promise.resolve({ data: null }),
      ]);
      const patch: Partial<JarvisState> = {};
      if (!get().historyLoaded && hist.messages?.length) {
        patch.messages = hist.messages.map((m) => ({ ...m, revealed: true }));
      }
      patch.historyLoaded = true;
      if (prefs.data && typeof prefs.data === 'object') {
        const merged = { ...get().appearance, ...prefs.data };
        delete (merged as { ttsEnabled?: boolean }).ttsEnabled;
        saveAppearance(merged as Appearance);
        applyAppearance(merged as Appearance);
        patch.appearance = merged as Appearance;
        if (typeof prefs.data.ttsEnabled === 'boolean') patch.ttsEnabled = prefs.data.ttsEnabled;
      }
      set(patch as JarvisState);
    } catch {
      set({ historyLoaded: true });
    }
  },

  announcement: null,
  setAnnouncement: (a) => set({ announcement: a }),

  health: null,
  setHealth: (h) => set({ health: h }),

  systemStatus: null,
  setSystemStatus: (s) => set({ systemStatus: s }),

  messages: [],
  busy: false,
  addMessage: (m) => set((s) => ({ messages: [...s.messages, m] })),
  updateMessage: (id, patch) => set((s) => ({ messages: s.messages.map((m) => (m.id === id ? { ...m, ...patch } : m)) })),
  updateToolEvent: (msgId, index, patch) =>
    set((s) => ({
      messages: s.messages.map((m) =>
        m.id === msgId && m.tools ? { ...m, tools: m.tools.map((t, i) => (i === index ? { ...t, ...patch } : t)) } : m
      ),
    })),
  clearMessages: () => {
    set({ messages: [] });
    const phone = get().phone;
    void fetch(`/api/chat/history${phone ? `?phone=${encodeURIComponent(phone)}` : ''}`, { method: 'DELETE' }).catch(() => undefined);
  },

  toolLogs: [],
  pushToolLog: (l) =>
    set((s) => ({
      toolLogs: [{ id: uid(), at: Date.now(), ...l }, ...s.toolLogs].slice(0, 60),
    })),

  orbMode: 'idle',
  setOrbMode: (m) => set({ orbMode: m }),
  micLevel: 0,
  setMicLevel: (v) => set({ micLevel: v }),

  view: 'console',
  setView: (v) => set({ view: v }),

  appearance: DEFAULT_APPEARANCE,
  setAppearance: (patch) =>
    set((s) => {
      const next = { ...s.appearance, ...patch };
      saveAppearance(next);
      applyAppearance(next);
      syncPreferences({ ...next, ttsEnabled: get().ttsEnabled });
      return { appearance: next };
    }),
  resetAppearance: () =>
    set(() => {
      saveAppearance(DEFAULT_APPEARANCE);
      applyAppearance(DEFAULT_APPEARANCE);
      return { appearance: DEFAULT_APPEARANCE };
    }),
  customizeOpen: false,
  setCustomizeOpen: (v) => set({ customizeOpen: v }),

  ttsEnabled: true,
  toggleTts: () =>
    set((s) => {
      syncPreferences({ ...s.appearance, ttsEnabled: !s.ttsEnabled });
      return { ttsEnabled: !s.ttsEnabled };
    }),

  pttKey: 'space',
  setPttKey: (k) => set({ pttKey: k }),

  cmdOpen: false,
  setCmdOpen: (v) => set({ cmdOpen: v }),

  /** Send an utterance to the JARVIS brain and stream the outcome into the HUD. */
  send: async (text) => {
    const trimmed = text.trim();
    if (!trimmed || get().busy) return;
    const phone = get().phone;

    const userMsg: Message = { id: uid(), role: 'user', text: trimmed, ts: Date.now(), revealed: true };
    get().addMessage(userMsg);
    persistMessage(userMsg);
    const placeholderId = uid();
    get().addMessage({ id: placeholderId, role: 'jarvis', text: '', ts: Date.now(), revealed: false });
    set({ busy: true, orbMode: 'thinking' });

    try {
      const history = get()
        .messages.filter((m) => m.id !== placeholderId && m.text)
        .slice(-9, -1)
        .map((m) => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text }));

      const res = await api<{ say: string; actions: ToolEvent[]; provider: string; model?: string; routeNote?: string }>('/api/chat', { text: trimmed, phone, history });

      // Register tool events + activity feed
      const events: ToolEvent[] = (res.actions ?? []).map((a) => ({ ...a, status: a.status ?? 'done' }));
      events.forEach((e) => get().pushToolLog({ tool: e.tool, label: e.label, status: e.status, output: e.output }));

      const reply: Partial<Message> = {
        text: res.say || (events.length ? 'Done, sir.' : "I'm on it."),
        tools: events,
        provider: res.provider,
        model: res.model,
        routeNote: res.routeNote,
      };
      get().updateMessage(placeholderId, reply);
      persistMessage({ id: placeholderId, role: 'jarvis', text: reply.text ?? '', provider: res.provider, model: res.model });
      set({ orbMode: 'speaking' });
      if (get().ttsEnabled && typeof window !== 'undefined' && 'speechSynthesis' in window && res.say) {
        try {
          window.speechSynthesis.cancel();
          const utter = new SpeechSynthesisUtterance(res.say.replace(/[•—]/g, ' ').slice(0, 400));
          utter.rate = 1.04;
          utter.pitch = 0.92;
          window.speechSynthesis.speak(utter);
          utter.onend = () => set({ orbMode: 'idle' });
          // Safety: never stay in speaking mode
          setTimeout(() => {
            if (get().orbMode === 'speaking' && !window.speechSynthesis.speaking) set({ orbMode: 'idle' });
          }, 6000);
        } catch {
          set({ orbMode: 'idle' });
        }
      } else {
        setTimeout(() => set({ orbMode: 'idle' }), 1200);
      }
    } catch (e) {
      const message = e instanceof Error ? e.message : 'An unexpected error occurred.';
      get().updateMessage(placeholderId, {
        text: `I couldn't complete that request. ${message}`,
        tools: [],
        provider: 'unavailable',
      });
      set({ orbMode: 'idle' });
    } finally {
      set({ busy: false });
    }
  },

  /** Run a tool directly (quick actions / command bar). */
  executeQuick: async (toolId, args = {}, confirmed = false) => {
    const phone = get().phone;
    try {
      const res = await api<ToolEvent>('/api/tools/execute', { toolId, args, confirmed, phone });
      get().pushToolLog({ tool: res.tool ?? toolId, label: res.label ?? toolId, status: res.status, output: res.output });
      return res;
    } catch {
      return null;
    }
  },

  /** Approve a confirm_required tool card inline. */
  approveTool: async (msgId, index) => {
    const msg = get().messages.find((m) => m.id === msgId);
    const event = msg?.tools?.[index];
    if (!event) return;
    get().updateToolEvent(msgId, index, { status: 'running' });
    const res = await get().executeQuick(event.tool, event.args, true);
    if (res) get().updateToolEvent(msgId, index, { status: res.status, output: res.output });
  },
}));
