/**
 * JARVIS 53 — Linux/server handlers.
 * Pure Node + network automations that work on ANY machine (including the
 * hosted preview). Desktop-only tools stay gracefully unsupported.
 */
import { execCmd, resolvePath, isPathSafe, enc, fetchJson, fetchText, fmtBytes, toolUnavailable, HOME } from '../os';
import type { ExecResult } from '../os';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';

type Args = Record<string, unknown>;
type Handler = (a: Args) => Promise<ExecResult>;

const ok = (stdout: string): ExecResult => ({ code: 0, stdout, stderr: '' });
const fail = (stderr: string): ExecResult => ({ code: 1, stdout: '', stderr });

const str = (a: Args, k: string, d = ''): string => (a[k] === undefined || a[k] === null ? d : String(a[k]));
const num = (a: Args, k: string, d = 0): number => {
  const n = Number(a[k]);
  return Number.isFinite(n) ? n : d;
};

/* ── System ── */
const systemInfo: Handler = async () => {
  const up = os.uptime();
  const d = Math.floor(up / 86400), h = Math.floor((up % 86400) / 3600), m = Math.floor((up % 3600) / 60);
  const total = os.totalmem(), free = os.freemem();
  let disk = '';
  try {
    const st = await fs.statfs(HOME);
    disk = `Disk: ${fmtBytes((st.blocks - st.bfree) * st.bsize)} used of ${fmtBytes(st.blocks * st.bsize)}\n`;
  } catch { /* ignore */ }
  const cpus = os.cpus();
  return ok(
    `System Report — ${os.type()} ${os.release()} (${os.arch()})\n` +
      `CPU: ${cpus[0]?.model.trim() ?? 'Unknown'} × ${cpus.length}\n` +
      `Memory: ${fmtBytes(total - free)} used of ${fmtBytes(total)} (${Math.round(((total - free) / total) * 100)}%)\n` +
      disk +
      `Uptime: ${d}d ${h}h ${m}m\n` +
      `Note: full hardware control (volume, lock, sleep…) unlocks on macOS and Windows installs.`
  );
};

/* ── Files (fs-based, cross-platform) ── */
const filesList: Handler = async (a) => {
  const dir = resolvePath(str(a, 'path', '~'));
  const guard = isPathSafe(dir);
  if (!guard.safe) return fail(guard.reason!);
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const items = await Promise.all(
      entries.slice(0, 60).map(async (e) => {
        if (e.name.startsWith('.')) return null;
        let size = '';
        try {
          const st = await fs.stat(path.join(dir, e.name));
          size = e.isDirectory() ? 'folder' : fmtBytes(st.size);
        } catch { /* ignore */ }
        return `${e.isDirectory() ? '📁' : '📄'} ${e.name}${size ? ` — ${size}` : ''}`;
      })
    );
    const clean = items.filter(Boolean);
    return ok(clean.length ? `${dir}\n\n${clean.join('\n')}` : `${dir} is empty.`);
  } catch (e) {
    return fail(`Can't list ${dir}: ${(e as Error).message}`);
  }
};

const filesRead: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  try {
    const st = await fs.stat(p);
    if (st.size > 200_000) return fail('File too large to display.');
    return ok(`${p}\n\n${await fs.readFile(p, 'utf8')}`.slice(0, 8200));
  } catch (e) {
    return fail(`Can't read ${p}: ${(e as Error).message}`);
  }
};

const filesWrite: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const content = str(a, 'content');
  const append = a.append === true || a.append === 'true';
  await fs.mkdir(path.dirname(p), { recursive: true });
  await (append ? fs.appendFile(p, `\n${content}`, 'utf8') : fs.writeFile(p, content, 'utf8'));
  return ok(`${append ? 'Appended to' : 'Wrote'} ${p} (${fmtBytes(Buffer.byteLength(content))}).`);
};

const filesMkdir: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  await fs.mkdir(p, { recursive: true });
  return ok(`Created folder ${p}.`);
};

const filesCopy: Handler = async (a) => {
  const from = resolvePath(str(a, 'from'));
  const to = resolvePath(str(a, 'to'));
  for (const p of [from, to]) {
    const guard = isPathSafe(p);
    if (!guard.safe) return fail(guard.reason!);
  }
  await fs.copyFile(from, to);
  return ok(`Copied → ${to}`);
};

const filesMove: Handler = async (a) => {
  const from = resolvePath(str(a, 'from'));
  const to = resolvePath(str(a, 'to'));
  for (const p of [from, to]) {
    const guard = isPathSafe(p);
    if (!guard.safe) return fail(guard.reason!);
  }
  await fs.rename(from, to);
  return ok(`Moved → ${to}`);
};

const filesInfo: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const st = await fs.stat(p);
  return ok(`${p}\nType: ${st.isDirectory() ? 'Folder' : 'File'}\nSize: ${fmtBytes(st.size)}\nModified: ${st.mtime.toLocaleString()}\nCreated: ${st.birthtime.toLocaleString()}`);
};

const filesRecent: Handler = async () => {
  const dir = path.join(HOME, 'Downloads');
  const entries = await fs.readdir(dir, { withFileTypes: true }).catch(() => []);
  const withTime = await Promise.all(
    entries.filter((e) => !e.name.startsWith('.')).map(async (e) => {
      const st = await fs.stat(path.join(dir, e.name)).catch(() => null);
      return st ? { name: e.name, mtime: st.mtime, size: st.size } : null;
    })
  );
  const sorted = withTime.filter(Boolean).sort((x, y) => y!.mtime.getTime() - x!.mtime.getTime()).slice(0, 15);
  return ok(sorted.length ? `Newest in Downloads:\n${sorted.map((f) => `• ${f!.name} — ${fmtBytes(f!.size)} (${f!.mtime.toLocaleDateString()})`).join('\n')}` : 'Downloads is empty.');
};

/* ── Vault (notes/tasks) ── */
async function vaultFile(kind: 'tasks' | 'notes'): Promise<string> {
  const dir = path.join(HOME, 'Documents', 'JARVIS53');
  await fs.mkdir(dir, { recursive: true });
  return path.join(dir, `${kind}.txt`);
}

const notesAdd: Handler = async (a) => {
  const title = str(a, 'title', 'JARVIS Note');
  const body = str(a, 'body');
  const f = await vaultFile('notes');
  await fs.appendFile(f, `\n=== ${title} — ${new Date().toLocaleString()} ===\n${body}\n`, 'utf8');
  return ok(`Note "${title}" saved to your JARVIS vault.`);
};

const notesList: Handler = async () => {
  const f = await vaultFile('notes');
  const content = await fs.readFile(f, 'utf8').catch(() => '');
  const titles = content.split('\n').filter((l) => l.startsWith('===')).slice(-15).reverse();
  return titles.length ? ok(`Your ${titles.length} most recent notes:\n${titles.map((t) => `• ${t.replace(/===/g, '').trim()}`).join('\n')}`) : ok('No notes yet.');
};

const tasksCreate: Handler = async (a) => {
  const title = str(a, 'title');
  const f = await vaultFile('tasks');
  await fs.appendFile(f, `[ ] ${title} — ${new Date().toLocaleString()}\n`, 'utf8');
  return ok(`Task "${title}" added to your JARVIS task vault.`);
};

const tasksList: Handler = async () => {
  const f = await vaultFile('tasks');
  const content = await fs.readFile(f, 'utf8').catch(() => '');
  const lines = content.split('\n').filter((l) => l.startsWith('[ ]')).slice(-20);
  return lines.length ? ok(`Open tasks:\n${lines.join('\n')}`) : ok('No open tasks.');
};

const remindersCreate: Handler = async (a) => tasksCreate(a);
const remindersList: Handler = async () => tasksList({});

/* ── Web (return URLs — headless servers have no browser) ── */
const webOpen: Handler = async (a) => {
  let url = str(a, 'url').trim();
  if (!/^https?:\/\//i.test(url)) {
    if (/^[\w.-]+\.[a-z]{2,}(\/.*)?$/i.test(url)) url = `https://${url}`;
    else return fail("That doesn't look like a valid URL.");
  }
  return ok(`Opening ${url} — on your desktop this launches your default browser.`);
};

const webSearch: Handler = async (a) => {
  const q = str(a, 'query');
  return ok(`Google search ready: https://www.google.com/search?q=${enc(q)} — on your desktop it opens automatically.`);
};

const webYoutube: Handler = async (a) => {
  const q = str(a, 'query');
  return ok(`YouTube search ready: https://www.youtube.com/results?search_query=${enc(q)} — on your desktop it opens automatically.`);
};

/* ── Info (network) ── */
const infoTime: Handler = async () =>
  ok(new Date().toLocaleString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }));

const infoWeather: Handler = async (a) => {
  const city = enc(str(a, 'city', '') || '');
  const data = await fetchJson<{ current_condition: Array<{ temp_C: string; FeelsLikeC: string; humidity: string; weatherDesc: Array<{ value: string }>; windspeedKmph: string }> }>(`https://wttr.in/${city}?format=j1`);
  if (!data?.current_condition?.[0]) return fail('Weather service unreachable.');
  const c = data.current_condition[0];
  return ok(`Weather: ${c.weatherDesc[0].value}, ${c.temp_C}°C (feels like ${c.FeelsLikeC}°C), humidity ${c.humidity}%, wind ${c.windspeedKmph} km/h${city ? ` — ${decodeURIComponent(city)}` : ''}`);
};

const infoNews: Handler = async () => {
  const xml = await fetchText('https://feeds.bbci.co.uk/news/world/rss.xml');
  if (!xml) return fail('News service unreachable.');
  const titles = [...xml.matchAll(/<title>(<!\[CDATA\[)?(.*?)(\]\]>)?<\/title>/g)].map((m) => m[2]).slice(1, 9);
  return ok(`Top headlines:\n${titles.map((t, i) => `${i + 1}. ${t}`).join('\n')}`);
};

const infoWiki: Handler = async (a) => {
  const q = enc(str(a, 'query').trim().replace(/\s+/g, '_'));
  const data = await fetchJson<{ extract: string; title: string }>(`https://en.wikipedia.org/api/rest_v1/page/summary/${q}`);
  if (!data?.extract) return fail(`No Wikipedia entry found for "${str(a, 'query')}".`);
  return ok(`${data.title} — ${data.extract.slice(0, 900)}`);
};

const infoIp: Handler = async () => {
  const data = await fetchJson<{ ip: string }>('https://api.ipify.org?format=json');
  return data?.ip ? ok(`Your public IP: ${data.ip}`) : fail('Network unreachable.');
};

const infoCurrency: Handler = async (a) => {
  const from = str(a, 'from', 'USD').toUpperCase().slice(0, 3);
  const to = str(a, 'to', 'INR').toUpperCase().slice(0, 3);
  const amount = num(a, 'amount', 1);
  const data = await fetchJson<{ rates: Record<string, number> }>(`https://open.er-api.com/v6/latest/${from}`);
  if (!data?.rates?.[to]) return fail(`Couldn't fetch ${from}→${to} rate.`);
  const rate = data.rates[to];
  return ok(`${amount} ${from} = ${(amount * rate).toFixed(2)} ${to} (live rate ${rate.toFixed(4)})`);
};

/* ── Dev ── */
const devGitStatus: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const branch = await execCmd('git', ['-C', p, 'branch', '--show-current']);
  if (branch.code !== 0) return fail('Not a git repository (or git is not installed).');
  const st = await execCmd('git', ['-C', p, 'status', '--porcelain']);
  const lines = st.stdout.split('\n').filter(Boolean);
  return ok(`Repository: ${p}\nBranch: ${branch.stdout.trim() || 'detached'}\nChanges: ${lines.length}\n${lines.slice(0, 20).map((l) => `• ${l}`).join('\n')}`);
};

const un = (id: string, needs: 'mac' | 'win'): ExecResult => toolUnavailable(id, needs);
const unsupported = (id: string) => async (): Promise<ExecResult> => un(id, 'mac');

export const LINUX_HANDLERS: Record<string, Handler> = {
  'system.info': systemInfo,
  'files.list': filesList,
  'files.read': filesRead,
  'files.write': filesWrite,
  'files.mkdir': filesMkdir,
  'files.copy': filesCopy,
  'files.move': filesMove,
  'files.info': filesInfo,
  'files.recent': filesRecent,
  'notes.add': notesAdd,
  'notes.list': notesList,
  'tasks.create': tasksCreate,
  'tasks.list': tasksList,
  'reminders.create': remindersCreate,
  'reminders.list': remindersList,
  'web.open': webOpen,
  'web.search': webSearch,
  'web.youtube': webYoutube,
  'info.time': infoTime,
  'info.weather': infoWeather,
  'info.news': infoNews,
  'info.wiki': infoWiki,
  'info.ip': infoIp,
  'info.currency': infoCurrency,
  'dev.git_status': devGitStatus,
};

/** Desktop-only tools exposed as graceful "needs macOS/Windows" on Linux. */
export const LINUX_STUBS: Record<string, Handler> = Object.fromEntries(
  ['apps.launch', 'apps.quit', 'apps.force_quit', 'apps.list_running', 'apps.activate', 'apps.frontmost', 'apps.install', 'system.volume', 'system.mute', 'system.unmute', 'system.brightness', 'system.dark_mode', 'system.lock', 'system.sleep', 'system.restart', 'system.shutdown', 'system.battery', 'system.wifi', 'system.screensaver', 'system.empty_trash', 'files.search', 'files.delete', 'files.zip', 'files.unzip', 'files.reveal', 'files.open_terminal', 'clipboard.get', 'clipboard.set', 'media.play_pause', 'media.next', 'media.previous', 'media.now_playing', 'media.play_search', 'window.snap_left', 'window.snap_right', 'window.hide_others', 'window.close_front', 'email.draft', 'whatsapp.compose', 'imessage.send', 'calendar.create', 'text.speak', 'dev.open_vscode'].map((id) => [id, unsupported(id)])
);
