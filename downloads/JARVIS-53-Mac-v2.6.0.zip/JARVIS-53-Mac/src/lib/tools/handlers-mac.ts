/**
 * JARVIS 53 — macOS native automation handlers.
 * All osascript invocations use execFile with argv arrays; user text is
 * AppleScript-escaped (escApple) — shell injection is impossible by construction.
 */
import {
  execCmd, execShell, execWithInput, spawnDetached, escApple, resolvePath,
  isPathSafe, safeToken, enc, fetchJson, fetchText, fmtBytes, toolUnavailable, HOME,
} from '../os';
import type { ExecResult } from '../os';
import { promises as fs } from 'fs';
import path from 'path';
import os from 'os';

type Args = Record<string, unknown>;
type Handler = (a: Args) => Promise<ExecResult>;

const osa = (script: string, timeoutMs = 15000) => execCmd('osascript', ['-e', script], timeoutMs);
const ok = (stdout: string): ExecResult => ({ code: 0, stdout, stderr: '' });
const fail = (stderr: string): ExecResult => ({ code: 1, stdout: '', stderr });

const str = (a: Args, k: string, d = ''): string => (a[k] === undefined || a[k] === null ? d : String(a[k]));
const num = (a: Args, k: string, d = 0): number => {
  const n = Number(a[k]);
  return Number.isFinite(n) ? n : d;
};

function appName(a: Args): string {
  return safeToken(str(a, 'app'));
}

async function appPath(name: string): Promise<string | null> {
  const r = await execCmd('mdfind', [`kMDItemKind == 'Application' && kMDItemDisplayName == '${name}*.app'c`], 6000);
  const p = r.stdout.split('\n').find((l) => l.endsWith('.app'));
  return p ?? null;
}

/* ── App Control ── */
const appsLaunch: Handler = async (a) => {
  const app = appName(a);
  if (!app) return fail('No application name given.');
  const r = await execCmd('open', ['-a', app]);
  if (r.code !== 0) {
    const alt = await appPath(app);
    if (alt) {
      const r2 = await execCmd('open', [alt]);
      return r2.code === 0 ? ok(`Launched ${app}.`) : r2;
    }
    return fail(`Couldn't find an app named "${app}". ${r.stderr.trim() || 'Is it installed?'}`);
  }
  return ok(`${app} is launching, sir.`);
};

const appsQuit: Handler = async (a) => {
  const app = appName(a);
  const r = await osa(`tell application "${escApple(app)}" to quit`);
  return r.code === 0 ? ok(`${app} closed gracefully.`) : fail(`Couldn't quit ${app}. Is it running?`);
};

const appsForceQuit: Handler = async (a) => {
  const app = appName(a);
  const r = await execCmd('pkill', ['-9', '-f', app]);
  return r.code === 0 ? ok(`${app} was force-quit.`) : fail(`No running process matched "${app}".`);
};

const appsListRunning: Handler = async () => {
  const r = await osa(`tell application "System Events" to get name of every process whose background only is false`);
  if (r.code !== 0) return fail('Unable to enumerate running apps (grant Automation permission for System Events).');
  const names = r.stdout.split(', ').filter(Boolean).sort((x, y) => x.localeCompare(y));
  return ok(`Running apps (${names.length}): ${names.join(', ')}`);
};

const appsActivate: Handler = async (a) => {
  const app = appName(a);
  const r = await execCmd('open', ['-a', app]);
  return r.code === 0 ? ok(`${app} is now in focus.`) : fail(`Couldn't focus ${app}.`);
};

const appsFrontmost: Handler = async () => {
  const r = await osa(`tell application "System Events" to get name of first process whose frontmost is true`);
  return r.code === 0 ? ok(`Active app: ${r.stdout.trim()}`) : fail('Unable to read frontmost app.');
};

const appsInstall: Handler = async (a) => {
  const pkg = safeToken(str(a, 'app'));
  if (!pkg) return fail('No package name given.');
  const brew = await execCmd('which', ['brew'], 4000);
  if (brew.code !== 0) return fail('Homebrew is not installed. Install it from https://brew.sh then try again.');
  const cask = await execShell(`brew install --cask ${JSON.stringify(pkg)} 2>&1 || brew install ${JSON.stringify(pkg)} 2>&1`, 300000);
  return cask.code === 0 ? ok(`Installed ${pkg} via Homebrew.`) : fail(cask.stdout.slice(-400) || cask.stderr.slice(-400) || `Failed to install ${pkg}.`);
};

/* ── System ── */
const systemVolume: Handler = async (a) => {
  const level = Math.max(0, Math.min(100, Math.round(num(a, 'level', 40))));
  const r = await osa(`set volume output volume ${level}`);
  return r.code === 0 ? ok(`Volume set to ${level}%.`) : fail('Unable to set volume.');
};

const systemMute: Handler = async () => {
  const r = await osa(`set volume output muted true`);
  return r.code === 0 ? ok('Muted.') : fail('Unable to mute.');
};

const systemUnmute: Handler = async () => {
  const r = await osa(`set volume output muted false`);
  return r.code === 0 ? ok('Sound restored.') : fail('Unable to unmute.');
};

const systemDarkMode: Handler = async (a) => {
  const mode = (str(a, 'mode', 'toggle') || 'toggle').toLowerCase();
  let target = '';
  if (mode === 'toggle') {
    const cur = await osa(`tell application "System Events" to tell appearance preferences to get dark mode`);
    target = cur.stdout.trim() === 'true' ? 'false' : 'true';
  } else target = mode === 'dark' ? 'true' : 'false';
  const r = await osa(`tell application "System Events" to tell appearance preferences to set dark mode to ${target}`);
  return r.code === 0 ? ok(`Switched to ${target === 'true' ? 'Dark' : 'Light'} mode.`) : fail('Unable to change appearance (check System Events permission).');
};

const systemLock: Handler = async () => {
  spawnDetached('/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession', ['-suspend']);
  return ok('Screen locked.');
};

const systemSleep: Handler = async () => {
  await execCmd('pmset', ['sleepnow']);
  return ok('Going to sleep. Goodnight, sir.');
};

const systemRestart: Handler = async () => {
  const r = await osa(`tell application "System Events" to restart`);
  return r.code === 0 ? ok('Restarting now.') : fail('Restart was blocked.');
};

const systemShutdown: Handler = async () => {
  const r = await osa(`tell application "System Events" to shut down`);
  return r.code === 0 ? ok('Shutting down.') : fail('Shutdown was blocked.');
};

const systemBattery: Handler = async () => {
  const r = await execCmd('pmset', ['-g', 'batt']);
  if (r.code !== 0) return fail('Battery info unavailable (desktop Mac?).');
  const m = r.stdout.match(/(\d+)%/);
  const charging = /AC Power|charging/i.test(r.stdout);
  return m ? ok(`Battery at ${m[1]}%, ${charging ? 'charging on AC power' : 'on battery'}.`) : ok(r.stdout.trim());
};

const systemWifi: Handler = async () => {
  for (const itf of ['en0', 'en1']) {
    const r = await execCmd('networksetup', ['-getairportnetwork', itf]);
    if (r.code === 0 && !/not associated|not found/i.test(r.stdout)) {
      const m = r.stdout.match(/:\s*(.+)$/);
      return ok(`Connected to Wi-Fi: ${m ? m[1].trim() : r.stdout.trim()}`);
    }
  }
  return ok('Wi-Fi appears to be off or not associated.');
};

const systemScreensaver: Handler = async () => {
  const r = await osa(`tell application "System Events" to start current screen saver`);
  return r.code === 0 ? ok('Screensaver started.') : fail('Unable to start screensaver.');
};

const systemEmptyTrash: Handler = async () => {
  const r = await osa(`tell application "Finder" to empty trash`);
  return r.code === 0 ? ok('Trash emptied.') : fail('Unable to empty Trash.');
};

const systemInfo: Handler = async () => {
  const up = os.uptime();
  const d = Math.floor(up / 86400), h = Math.floor((up % 86400) / 3600), m = Math.floor((up % 3600) / 60);
  const total = os.totalmem(), free = os.freemem();
  const df = await execShell('df -h / | tail -1');
  const disk = df.stdout.trim().split(/\s+/);
  const cpus = os.cpus();
  return ok(
    `System Report — ${os.type()} ${os.release()} (${os.arch()})\n` +
      `CPU: ${cpus[0]?.model.trim() ?? 'Unknown'} × ${cpus.length}\n` +
      `Memory: ${fmtBytes(total - free)} used of ${fmtBytes(total)} (${Math.round(((total - free) / total) * 100)}%)\n` +
      `Disk (/): ${disk[2] ?? '?'} used of ${disk[1] ?? '?'} (${disk[4] ?? '?'})\n` +
      `Uptime: ${d}d ${h}h ${m}m`
  );
};

/* ── Files ── */
const filesList: Handler = async (a) => {
  const dir = resolvePath(str(a, 'path', '~'));
  const guard = isPathSafe(dir);
  if (!guard.safe) return fail(guard.reason!);
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const items = await Promise.all(
      entries.slice(0, 60).map(async (e) => {
        if (e.name.startsWith('.')) return null;
        let size = '';
        try {
          const st = await fs.stat(path.join(dir, e.name));
          size = e.isDirectory() ? 'folder' : fmtBytes(st.size);
        } catch { /* ignore */ }
        return `${e.isDirectory() ? '📁' : '📄'} ${e.name}${size ? ` — ${size}` : ''}`;
      })
    );
    const clean = items.filter(Boolean);
    return ok(clean.length ? `${dir}\n\n${clean.join('\n')}` : `${dir} is empty.`);
  } catch (e) {
    return fail(`Can't list ${dir}: ${(e as Error).message}`);
  }
};

const filesRead: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  try {
    const st = await fs.stat(p);
    if (st.size > 200_000) return fail('File too large to display (read the first section via Preview instead).');
    const content = await fs.readFile(p, 'utf8');
    return ok(`${p}\n\n${content.slice(0, 8000)}`);
  } catch (e) {
    return fail(`Can't read ${p}: ${(e as Error).message}`);
  }
};

const filesWrite: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const content = str(a, 'content');
  const append = a.append === true || a.append === 'true';
  try {
    await fs.mkdir(path.dirname(p), { recursive: true });
    await fs.appendFile(p, append ? `\n${content}` : content, append ? 'utf8' : undefined as never).catch(async () => {
      if (append) await fs.appendFile(p, `\n${content}`, 'utf8');
      else await fs.writeFile(p, content, 'utf8');
    });
    return ok(`${append ? 'Appended to' : 'Wrote'} ${p} (${fmtBytes(Buffer.byteLength(content))}).`);
  } catch (e) {
    return fail(`Write failed: ${(e as Error).message}`);
  }
};

const filesSearch: Handler = async (a) => {
  const q = str(a, 'query').trim();
  if (!q) return fail('Empty search query.');
  const folder = a.folder ? resolvePath(str(a, 'folder')) : null;
  if (folder) {
    const guard = isPathSafe(folder);
    if (!guard.safe) return fail(guard.reason!);
  }
  const nameQ = folder ? `kMDItemDisplayName == '*${q.replace(/'/g, '')}*'cd` : `-name ${q}`;
  const args = folder ? ['mdfind', '-onlyin', folder, nameQ] : ['mdfind', nameQ];
  const r = await execCmd(args[0], args.slice(1), 12000);
  const results = r.stdout.split('\n').filter(Boolean).slice(0, 25);
  return ok(results.length ? `Found ${results.length} match${results.length > 1 ? 'es' : ''}:\n${results.join('\n')}` : `No files matching "${q}"${folder ? ` in ${folder}` : ''}.`);
};

const filesMkdir: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  await fs.mkdir(p, { recursive: true });
  return ok(`Created folder ${p}.`);
};

const filesCopy: Handler = async (a) => {
  const from = resolvePath(str(a, 'from'));
  const to = resolvePath(str(a, 'to'));
  for (const p of [from, to]) {
    const guard = isPathSafe(p);
    if (!guard.safe) return fail(guard.reason!);
  }
  await fs.copyFile(from, to).catch(async () => {
    await execCmd('cp', ['-R', from, to]);
  });
  return ok(`Copied → ${to}`);
};

const filesMove: Handler = async (a) => {
  const from = resolvePath(str(a, 'from'));
  const to = resolvePath(str(a, 'to'));
  for (const p of [from, to]) {
    const guard = isPathSafe(p);
    if (!guard.safe) return fail(guard.reason!);
  }
  await fs.rename(from, to).catch(async () => {
    await execCmd('mv', [from, to]);
  });
  return ok(`Moved → ${to}`);
};

const filesDelete: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const r = await osa(`tell application "Finder" to delete POSIX file "${escApple(p)}"`);
  return r.code === 0 ? ok(`Moved ${p} to Trash (recoverable).`) : fail(`Delete failed: ${r.stderr.trim()}`);
};

const filesZip: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const out = `${p}.zip`;
  const r = await execCmd('ditto', ['-c', '-k', '--sequesterRsrc', '--keepParent', p, out], 120000);
  return r.code === 0 ? ok(`Compressed → ${out}`) : fail(`Zip failed: ${r.stderr.trim()}`);
};

const filesUnzip: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const dest = p.replace(/\.zip$/i, '');
  await fs.mkdir(dest, { recursive: true });
  const r = await execCmd('ditto', ['-x', '-k', p, dest], 120000);
  return r.code === 0 ? ok(`Extracted → ${dest}`) : fail(`Unzip failed: ${r.stderr.trim()}`);
};

const filesInfo: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  try {
    const st = await fs.stat(p);
    return ok(`${p}\nType: ${st.isDirectory() ? 'Folder' : 'File'}\nSize: ${fmtBytes(st.size)}\nModified: ${st.mtime.toLocaleString()}\nCreated: ${st.birthtime.toLocaleString()}`);
  } catch (e) {
    return fail(`Can't stat ${p}: ${(e as Error).message}`);
  }
};

const filesReveal: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const r = await execCmd('open', ['-R', p]);
  return r.code === 0 ? ok(`Revealed in Finder: ${p}`) : fail('Reveal failed — does the path exist?');
};

const filesOpenTerminal: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const r = await execCmd('open', ['-a', 'Terminal', p]);
  if (r.code !== 0) {
    const r2 = await execCmd('open', ['-a', 'iTerm', p]);
    return r2.code === 0 ? ok(`Opened iTerm at ${p}`) : fail('Terminal not found.');
  }
  return ok(`Terminal opened at ${p}`);
};

const filesRecent: Handler = async () => {
  const dir = path.join(HOME, 'Downloads');
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const withTime = await Promise.all(
      entries.filter((e) => !e.name.startsWith('.')).map(async (e) => {
        const st = await fs.stat(path.join(dir, e.name)).catch(() => null);
        return st ? { name: e.name, mtime: st.mtime, size: st.size } : null;
      })
    );
    const sorted = withTime.filter(Boolean).sort((x, y) => y!.mtime.getTime() - x!.mtime.getTime()).slice(0, 15);
    return ok(sorted.length ? `Newest in Downloads:\n${sorted.map((f) => `• ${f!.name} — ${fmtBytes(f!.size)} (${f!.mtime.toLocaleDateString()})`).join('\n')}` : 'Downloads is empty.');
  } catch (e) {
    return fail(`Can't read Downloads: ${(e as Error).message}`);
  }
};

/* ── Clipboard ── */
const clipboardGet: Handler = async () => {
  const r = await execCmd('pbpaste', []);
  return ok(r.stdout ? `Clipboard: ${r.stdout.slice(0, 1500)}` : 'Clipboard is empty.');
};

const clipboardSet: Handler = async (a) => {
  const text = str(a, 'text');
  const r = await execWithInput('pbcopy', [], text);
  return r.code === 0 ? ok('Copied to clipboard.') : fail('Clipboard copy failed.');
};

/* ── Media ── */
async function mediaCmd(script: string): Promise<ExecResult> {
  const r = await osa(script, 8000);
  if (r.code === 0) return r;
  return { code: 1, stdout: r.stdout, stderr: r.stderr || 'No media app responded.' };
}

const mediaPlayPause: Handler = async () => {
  const spot = await mediaCmd(`tell application "System Events" to (name of processes) contains "Spotify"`);
  if (spot.stdout.trim() === 'true') {
    const r = await mediaCmd(`tell application "Spotify" to playpause`);
    if (r.code === 0) return ok('Toggled playback on Spotify.');
  }
  const music = await mediaCmd(`tell application "System Events" to (name of processes) contains "Music"`);
  if (music.stdout.trim() === 'true') {
    const r = await mediaCmd(`tell application "Music" to playpause`);
    if (r.code === 0) return ok('Toggled playback in Music.');
  }
  return fail('No music app is running. Try: "play <song> on Spotify".');
};

const mediaNext: Handler = async () => {
  const spot = await osa(`tell application "System Events" to (name of processes) contains "Spotify"`, 5000);
  const target = spot.stdout.trim() === 'true' ? 'Spotify' : 'Music';
  const r = await mediaCmd(`tell application "${target}" to next track`);
  return r.code === 0 ? ok(`Skipped forward in ${target}.`) : fail('No music app running.');
};

const mediaPrevious: Handler = async () => {
  const spot = await osa(`tell application "System Events" to (name of processes) contains "Spotify"`, 5000);
  const target = spot.stdout.trim() === 'true' ? 'Spotify' : 'Music';
  const r = await mediaCmd(`tell application "${target}" to previous track`);
  return r.code === 0 ? ok(`Skipped back in ${target}.`) : fail('No music app running.');
};

const mediaNowPlaying: Handler = async () => {
  const spot = await osa(`tell application "System Events" to (name of processes) contains "Spotify"`, 5000);
  if (spot.stdout.trim() === 'true') {
    const r = await osa(`tell application "Spotify" to name of current track & " — " & artist of current track`);
    if (r.code === 0) return ok(`Now playing on Spotify: ${r.stdout.trim()}`);
  }
  const music = await osa(`tell application "System Events" to (name of processes) contains "Music"`, 5000);
  if (music.stdout.trim() === 'true') {
    const r = await osa(`tell application "Music" to name of current track & " — " & artist of current track`);
    if (r.code === 0) return ok(`Now playing in Music: ${r.stdout.trim()}`);
  }
  return fail('Nothing is playing right now.');
};

const mediaPlaySearch: Handler = async (a) => {
  const query = str(a, 'query').trim();
  const service = (str(a, 'service', 'spotify') || 'spotify').toLowerCase().replace(/\s/g, '_');
  if (!query) return fail('What should I play?');
  if (service === 'youtube') {
    const url = `https://www.youtube.com/results?search_query=${enc(query)}`;
    await execCmd('open', [url]);
    return ok(`Opened YouTube search for "${query}".`);
  }
  if (service === 'apple_music' || service === 'music') {
    const url = `https://music.apple.com/us/search?term=${enc(query)}`;
    await execCmd('open', [url]);
    return ok(`Opened Apple Music search for "${query}".`);
  }
  const r = await osa(`tell application "Spotify" to play track "spotify:search:${escApple(query)}"`, 10000);
  if (r.code === 0) return ok(`Playing "${query}" on Spotify.`);
  await execCmd('open', [`spotify:search:${enc(query)}`]);
  return ok(`Requested Spotify to play "${query}".`);
};

/* ── Windows/WM ── */
const windowSnapLeft: Handler = async () => {
  const script = `
tell application "Finder" to set _b to bounds of window of desktop
set _w to (item 3 of _b) as integer
set _h to (item 4 of _b) as integer
tell application "System Events" to tell (first process whose frontmost is true)
  set position of front window to {0, 25}
  set size of front window to {(_w div 2), (_h - 25)}
end tell`;
  const r = await osa(script);
  return r.code === 0 ? ok('Snapped front window to the left half.') : fail('Could not move the window (check Accessibility permission).');
};

const windowSnapRight: Handler = async () => {
  const script = `
tell application "Finder" to set _b to bounds of window of desktop
set _w to (item 3 of _b) as integer
set _h to (item 4 of _b) as integer
tell application "System Events" to tell (first process whose frontmost is true)
  set position of front window to {(_w div 2), 25}
  set size of front window to {(_w div 2), (_h - 25)}
end tell`;
  const r = await osa(script);
  return r.code === 0 ? ok('Snapped front window to the right half.') : fail('Could not move the window (check Accessibility permission).');
};

const windowHideOthers: Handler = async () => {
  const r = await osa(`tell application "System Events" to keystroke "h" using {command down, option down}`);
  return r.code === 0 ? ok('Everything else hidden. Focus mode engaged.') : fail('Unable to send shortcut (check Accessibility permission).');
};

const windowCloseFront: Handler = async () => {
  const r = await osa(`tell application "System Events" to keystroke "w" using {command down}`);
  return r.code === 0 ? ok('Closed the front window/tab.') : fail('Unable to send shortcut.');
};

/* ── Comms ── */
const emailDraft: Handler = async (a) => {
  const to = safeToken(str(a, 'to'));
  const subject = str(a, 'subject', '(no subject)');
  const body = str(a, 'body');
  if (!to.includes('@')) return fail('That doesn\'t look like a valid email address.');
  const script = `
tell application "Mail"
  set _m to make new outgoing message with properties {visible:true, subject:"${escApple(subject)}", content:"${escApple(body)}\\n"}
  tell _m to make new to recipient at end of to recipients with properties {address:"${escApple(to)}"}
  activate
end tell`;
  const r = await osa(script, 12000);
  if (r.code === 0) return ok(`Draft prepared in Mail for ${to} — review and hit send. I never send email without you.`);
  // Fallback: mailto link
  await execCmd('open', [`mailto:${encodeURIComponent(to)}?subject=${enc(subject)}&body=${enc(body)}`]);
  return ok(`Opened a mail compose window for ${to}.`);
};

const whatsappCompose: Handler = async (a) => {
  const phone = str(a, 'phone').replace(/[^\d+]/g, '');
  const message = str(a, 'message');
  if (!/^\+?\d{8,15}$/.test(phone)) return fail('Phone must be an international number, e.g. +919876543210.');
  const url = `https://wa.me/${phone.replace(/^\+/, '')}?text=${enc(message)}`;
  await execCmd('open', [url]);
  return ok(`WhatsApp opened for ${phone} — message loaded, ready for your review.`);
};

const imessageSend: Handler = async (a) => {
  const to = safeToken(str(a, 'to'));
  const message = str(a, 'message');
  const script = `
tell application "Messages"
  set _svc to 1st service whose service type is iMessage
  set _b to buddy "${escApple(to)}" of _svc
  send "${escApple(message)}" to _b
end tell`;
  const r = await osa(script, 12000);
  return r.code === 0 ? ok(`iMessage sent to ${to}.`) : fail(`iMessage failed — recipient may not be in Messages: ${r.stderr.trim().slice(0, 200)}`);
};

/* ── Productivity ── */
const notesAdd: Handler = async (a) => {
  const title = str(a, 'title', 'JARVIS Note');
  const body = str(a, 'body');
  const script = `
tell application "Notes"
  make new note with properties {name:"${escApple(title)}", body:"<div><b>${escApple(title)}</b></div><div>${escApple(body).replace(/\n/g, '<br>')}</div>"}
end tell`;
  const r = await osa(script, 12000);
  return r.code === 0 ? ok(`Note "${title}" saved to Apple Notes.`) : fail(`Notes failed: ${r.stderr.trim().slice(0, 200)}`);
};

const notesList: Handler = async () => {
  const r = await osa(`tell application "Notes" to get name of every note`, 12000);
  if (r.code !== 0) return fail('Unable to read Apple Notes.');
  const names = r.stdout.split(', ').filter(Boolean).slice(-15).reverse();
  return ok(names.length ? `Your ${names.length} most recent notes:\n${names.map((n) => `• ${n}`).join('\n')}` : 'No notes found.');
};

const remindersCreate: Handler = async (a) => {
  const title = str(a, 'title');
  const when = str(a, 'when');
  let dueClause = '';
  if (when) {
    dueClause = `, due date:(current date) + ${JSON.stringify(when).length}`; // placeholder replaced below
  }
  // Simple relative parsing: "in N hours/minutes" or none
  const relMatch = when.match(/in\s+(\d+)\s*(hour|minute|min|h|m)/i);
  if (when && relMatch) {
    const n = Number(relMatch[1]);
    const unit = /h/i.test(relMatch[2]) ? 'hours' : 'minutes';
    dueClause = `, due date:((current date) + (${n} * ${unit === 'hours' ? 'hours' : 'minutes'}))`;
  } else if (when) {
    dueClause = ''; // natural dates beyond relative aren't parsed; keep note-only
  }
  const script = `
tell application "Reminders"
  make new reminder with properties {name:"${escApple(title)}"${dueClause}}
end tell`;
  const r = await osa(script, 12000);
  return r.code === 0 ? ok(`Reminder "${title}" created${when ? ` (${when})` : ''}.`) : fail(`Reminders failed: ${r.stderr.trim().slice(0, 200)}`);
};

const remindersList: Handler = async () => {
  const r = await osa(`tell application "Reminders" to get name of reminders whose completed is false`, 12000);
  if (r.code !== 0) return fail('Unable to read Reminders.');
  const names = r.stdout.split(', ').filter(Boolean).slice(0, 20);
  return ok(names.length ? `Open reminders:\n${names.map((n) => `• ${n}`).join('\n')}` : 'No open reminders. Clean slate!');
};

const calendarCreate: Handler = async (a) => {
  const title = str(a, 'title');
  const dateStr = str(a, 'date');
  const timeStr = str(a, 'time', '09:00');
  const minutes = Math.max(5, num(a, 'minutes', 60));
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return fail('Date must be YYYY-MM-DD.');
  if (!/^\d{2}:\d{2}$/.test(timeStr)) return fail('Time must be HH:MM (24h).');
  const script = `
set _y to ${Number(dateStr.slice(0, 4))}
set _mo to ${Number(dateStr.slice(5, 7))}
set _d to ${Number(dateStr.slice(8, 10))}
set _h to ${Number(timeStr.slice(0, 2))}
set _mi to ${Number(timeStr.slice(3, 5))}
set _start to current date
set year of _start to _y
set month of _start to _mo
set day of _start to _d
set time of _start to (_h * 3600 + _mi * 60)
set _end to _start + (${minutes} * 60)
tell application "Calendar"
  tell (first calendar whose writable is true)
    make new event with properties {summary:"${escApple(title)}", start date:_start, end date:_end}
  end tell
end tell`;
  const r = await osa(script, 15000);
  return r.code === 0 ? ok(`Event "${title}" created on ${dateStr} at ${timeStr}.`) : fail(`Calendar failed: ${r.stderr.trim().slice(0, 200)}`);
};

async function vaultFile(kind: 'tasks' | 'notes'): Promise<string> {
  const dir = path.join(HOME, 'Documents', 'JARVIS53');
  await fs.mkdir(dir, { recursive: true });
  return path.join(dir, `${kind}.txt`);
}

const tasksCreate: Handler = async (a) => {
  const title = str(a, 'title');
  const r = await osa(`tell application "Reminders" to make new reminder with properties {name:"${escApple(title)}"}`, 10000);
  if (r.code === 0) return ok(`Task "${title}" added to Reminders.`);
  const f = await vaultFile('tasks');
  await fs.appendFile(f, `[ ] ${title} — ${new Date().toLocaleString()}\n`, 'utf8');
  return ok(`Task "${title}" saved to your JARVIS task vault.`);
};

const tasksList: Handler = async () => {
  const r = await osa(`tell application "Reminders" to get name of reminders whose completed is false`, 10000);
  if (r.code === 0 && r.stdout.trim()) {
    const names = r.stdout.split(', ').filter(Boolean).slice(0, 20);
    return ok(`Open tasks:\n${names.map((n) => `• ${n}`).join('\n')}`);
  }
  const f = await vaultFile('tasks');
  const content = await fs.readFile(f, 'utf8').catch(() => '');
  const lines = content.split('\n').filter((l) => l.startsWith('[ ]')).slice(-20);
  return lines.length ? ok(`Open tasks:\n${lines.join('\n')}`) : ok('No open tasks.');
};

/* ── Web ── */
const webOpen: Handler = async (a) => {
  let url = str(a, 'url').trim();
  if (!/^https?:\/\//i.test(url)) {
    if (/^[\w.-]+\.[a-z]{2,}(\/.*)?$/i.test(url)) url = `https://${url}`;
    else return fail('That doesn\'t look like a valid URL.');
  }
  await execCmd('open', [url]);
  return ok(`Opened ${url}`);
};

const webSearch: Handler = async (a) => {
  const q = str(a, 'query');
  await execCmd('open', [`https://www.google.com/search?q=${enc(q)}`]);
  return ok(`Searched Google for "${q}".`);
};

const webYoutube: Handler = async (a) => {
  const q = str(a, 'query');
  await execCmd('open', [`https://www.youtube.com/results?search_query=${enc(q)}`]);
  return ok(`Searching YouTube for "${q}".`);
};

/* ── Info (network, cross-platform) ── */
const infoTime: Handler = async () => ok(new Date().toLocaleString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }));

const infoWeather: Handler = async (a) => {
  const city = enc(str(a, 'city', '') || '');
  const data = await fetchJson<{ current_condition: Array<{ temp_C: string; FeelsLikeC: string; humidity: string; weatherDesc: Array<{ value: string }>; cloudcover: string; windspeedKmph: string }> }>(
    `https://wttr.in/${city}?format=j1`
  );
  if (!data?.current_condition?.[0]) return fail('Weather service unreachable.');
  const c = data.current_condition[0];
  return ok(`Weather: ${c.weatherDesc[0].value}, ${c.temp_C}°C (feels like ${c.FeelsLikeC}°C), humidity ${c.humidity}%, wind ${c.windspeedKmph} km/h${city ? ` — ${decodeURIComponent(city)}` : ''}`);
};

const infoNews: Handler = async () => {
  const xml = await fetchText('https://feeds.bbci.co.uk/news/world/rss.xml');
  if (!xml) return fail('News service unreachable.');
  const titles = [...xml.matchAll(/<title>(<!\[CDATA\[)?(.*?)(\]\]>)?<\/title>/g)].map((m) => m[2]).slice(1, 9);
  return ok(`Top headlines:\n${titles.map((t, i) => `${i + 1}. ${t}`).join('\n')}`);
};

const infoWiki: Handler = async (a) => {
  const q = enc(str(a, 'query').trim().replace(/\s+/g, '_'));
  const data = await fetchJson<{ extract: string; title: string }>(`https://en.wikipedia.org/api/rest_v1/page/summary/${q}`);
  if (!data?.extract) return fail(`No Wikipedia entry found for "${str(a, 'query')}".`);
  return ok(`${data.title} — ${data.extract.slice(0, 900)}`);
};

const infoIp: Handler = async () => {
  const data = await fetchJson<{ ip: string }>('https://api.ipify.org?format=json');
  return data?.ip ? ok(`Your public IP: ${data.ip}`) : fail('Network unreachable.');
};

const infoCurrency: Handler = async (a) => {
  const from = str(a, 'from', 'USD').toUpperCase().slice(0, 3);
  const to = str(a, 'to', 'INR').toUpperCase().slice(0, 3);
  const amount = num(a, 'amount', 1);
  const data = await fetchJson<{ result: string; rates: Record<string, number> }>(`https://open.er-api.com/v6/latest/${from}`);
  if (!data?.rates?.[to]) return fail(`Couldn't fetch ${from}→${to} rate.`);
  const rate = data.rates[to];
  return ok(`${amount} ${from} = ${(amount * rate).toFixed(2)} ${to} (live rate ${rate.toFixed(4)})`);
};

/* ── Text ── */
const textSpeak: Handler = async (a) => {
  const text = str(a, 'text').slice(0, 500);
  const r = await execCmd('say', [text]);
  return r.code === 0 ? ok(`Spoken: "${text.slice(0, 80)}${text.length > 80 ? '…' : ''}"`) : fail('Speech synthesis failed.');
};

/* ── Dev ── */
const devOpenVscode: Handler = async (a) => {
  const p = resolvePath(str(a, 'path', '~'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  let r = await execCmd('open', ['-a', 'Visual Studio Code', p]);
  if (r.code !== 0) r = await execCmd('code', [p]);
  return r.code === 0 ? ok(`VS Code opened at ${p}`) : fail('VS Code not found — install it from https://code.visualstudio.com');
};

const devGitStatus: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const branch = await execCmd('git', ['-C', p, 'branch', '--show-current']);
  if (branch.code !== 0) return fail('Not a git repository.');
  const st = await execCmd('git', ['-C', p, 'status', '--porcelain']);
  const lines = st.stdout.split('\n').filter(Boolean);
  return ok(`Repository: ${p}\nBranch: ${branch.stdout.trim() || 'detached'}\nChanges: ${lines.length}\n${lines.slice(0, 20).map((l) => `• ${l}`).join('\n')}`);
};

export const MAC_HANDLERS: Record<string, Handler> = {
  'apps.launch': appsLaunch,
  'apps.quit': appsQuit,
  'apps.force_quit': appsForceQuit,
  'apps.list_running': appsListRunning,
  'apps.activate': appsActivate,
  'apps.frontmost': appsFrontmost,
  'apps.install': appsInstall,
  'system.volume': systemVolume,
  'system.mute': systemMute,
  'system.unmute': systemUnmute,
  'system.dark_mode': systemDarkMode,
  'system.lock': systemLock,
  'system.sleep': systemSleep,
  'system.restart': systemRestart,
  'system.shutdown': systemShutdown,
  'system.battery': systemBattery,
  'system.wifi': systemWifi,
  'system.screensaver': systemScreensaver,
  'system.empty_trash': systemEmptyTrash,
  'system.info': systemInfo,
  'files.list': filesList,
  'files.read': filesRead,
  'files.write': filesWrite,
  'files.search': filesSearch,
  'files.mkdir': filesMkdir,
  'files.copy': filesCopy,
  'files.move': filesMove,
  'files.delete': filesDelete,
  'files.zip': filesZip,
  'files.unzip': filesUnzip,
  'files.info': filesInfo,
  'files.reveal': filesReveal,
  'files.open_terminal': filesOpenTerminal,
  'files.recent': filesRecent,
  'clipboard.get': clipboardGet,
  'clipboard.set': clipboardSet,
  'media.play_pause': mediaPlayPause,
  'media.next': mediaNext,
  'media.previous': mediaPrevious,
  'media.now_playing': mediaNowPlaying,
  'media.play_search': mediaPlaySearch,
  'window.snap_left': windowSnapLeft,
  'window.snap_right': windowSnapRight,
  'window.hide_others': windowHideOthers,
  'window.close_front': windowCloseFront,
  'email.draft': emailDraft,
  'whatsapp.compose': whatsappCompose,
  'imessage.send': imessageSend,
  'notes.add': notesAdd,
  'notes.list': notesList,
  'reminders.create': remindersCreate,
  'reminders.list': remindersList,
  'calendar.create': calendarCreate,
  'tasks.create': tasksCreate,
  'tasks.list': tasksList,
  'web.open': webOpen,
  'web.search': webSearch,
  'web.youtube': webYoutube,
  'info.time': infoTime,
  'info.weather': infoWeather,
  'info.news': infoNews,
  'info.wiki': infoWiki,
  'info.ip': infoIp,
  'info.currency': infoCurrency,
  'text.speak': textSpeak,
  'dev.open_vscode': devOpenVscode,
  'dev.git_status': devGitStatus,
};

export const MAC_UNSUPPORTED: Record<string, ExecResult> = {
  'system.brightness': toolUnavailable('system.brightness', 'win'),
};
