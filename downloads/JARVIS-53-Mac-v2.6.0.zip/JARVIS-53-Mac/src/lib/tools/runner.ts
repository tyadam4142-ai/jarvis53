/**
 * JARVIS 53 — Tool Runner + Safety Engine.
 * Multi-tier risk classification, argument validation, path-traversal protection
 * and platform dispatch. Medium/high risk actions require human confirmation
 * unless the caller explicitly passes `confirmed`.
 */
import { TOOL_MAP, type ToolDef, type Risk } from './registry';
import { MAC_HANDLERS, MAC_UNSUPPORTED } from './handlers-mac';
import { WIN_HANDLERS, WIN_UNSUPPORTED } from './handlers-win';
import { LINUX_HANDLERS, LINUX_STUBS } from './handlers-linux';
import { PLATFORM } from '../os';
import type { ExecResult } from '../os';
import { logUsage } from '../data';

export interface ToolOutcome {
  tool: string;
  label: string;
  risk: Risk;
  status: 'done' | 'error' | 'confirm_required' | 'unsupported';
  output: string;
  args: Record<string, unknown>;
  available: boolean;
}

const RISK_ORDER: Record<Risk, number> = { low: 0, medium: 1, high: 2 };

export function describeTool(id: string): ToolDef | null {
  return TOOL_MAP[id] ?? null;
}

/** Validate provided args against the registry definition. */
function validateArgs(def: ToolDef, args: Record<string, unknown>): { ok: boolean; error?: string; clean: Record<string, unknown> } {
  const clean: Record<string, unknown> = {};
  for (const spec of def.args) {
    const v = args?.[spec.name];
    if (v === undefined || v === null || v === '') {
      if (spec.required) return { ok: false, error: `Missing required argument "${spec.name}" (${spec.desc}).`, clean };
      continue;
    }
    if (spec.type === 'number') {
      const n = Number(v);
      if (!Number.isFinite(n)) return { ok: false, error: `Argument "${spec.name}" must be a number.`, clean };
      clean[spec.name] = n;
    } else if (spec.type === 'boolean') {
      clean[spec.name] = v === true || v === 'true';
    } else {
      if (String(v).length > 20000) return { ok: false, error: `Argument "${spec.name}" is too long.`, clean };
      clean[spec.name] = String(v);
    }
  }
  return { ok: true, clean };
}

export interface RunOptions {
  confirmed?: boolean; // human approved a medium/high risk action
  phone?: string | null;
  source?: 'ai' | 'quick' | 'commandbar' | 'diagnostics' | 'workflow';
}

/**
 * Execute a tool through the full safety pipeline.
 * Never throws — always returns a ToolOutcome.
 */
export async function runTool(toolId: string, rawArgs: Record<string, unknown> = {}, opts: RunOptions = {}): Promise<ToolOutcome> {
  const def = TOOL_MAP[toolId];
  const base = (o: Partial<ToolOutcome>): ToolOutcome => ({
    tool: toolId,
    label: def?.name ?? toolId,
    risk: def?.risk ?? 'medium',
    status: 'error',
    output: '',
    args: rawArgs,
    available: true,
    ...o,
  });

  if (!def) return base({ status: 'error', output: `Unknown capability "${toolId}".` });

  // Argument validation
  const v = validateArgs(def, rawArgs);
  if (!v.ok) return base({ status: 'error', output: v.error! });
  const args = v.clean;

  // Platform availability
  const native =
    PLATFORM === 'mac'
      ? MAC_HANDLERS[toolId]
      : PLATFORM === 'win'
        ? WIN_HANDLERS[toolId]
        : LINUX_HANDLERS[toolId] ?? LINUX_STUBS[toolId];
  const unsupported =
    PLATFORM === 'mac' ? MAC_UNSUPPORTED[toolId] : PLATFORM === 'win' ? WIN_UNSUPPORTED[toolId] : undefined;
  const available = Boolean(native) && !unsupported;
  if (!available && (PLATFORM === 'linux' || unsupported)) {
    const msg =
      PLATFORM === 'linux'
        ? `"${def.name}" is a native desktop automation — it comes alive on macOS and Windows installations of JARVIS 53.`
        : (unsupported as ExecResult).stderr;
    return base({ status: 'unsupported', output: msg, available: false });
  }

  // Risk gate
  if (RISK_ORDER[def.risk] > 0 && !opts.confirmed) {
    return base({
      status: 'confirm_required',
      output: `${def.name} is a ${def.risk}-risk action and needs your explicit approval.`,
      available: true,
    });
  }

  // Execute
  try {
    const result = await native!(args);
    const success = result.code === 0;
    const output = (success ? result.stdout : result.stderr || result.stdout || 'No output.').trim() || 'Done.';
    void logUsage(opts.phone, 'tool', `${toolId}${opts.source ? ` (${opts.source})` : ''}`);
    return base({ status: success ? 'done' : 'error', output: output.slice(0, 3000) });
  } catch (e) {
    return base({ status: 'error', output: `Execution failed: ${(e as Error).message}` });
  }
}

/** Human-readable label for confirm dialogs. */
export function riskPhrase(def: ToolDef, args: Record<string, unknown>): string {
  if (def.confirm) return def.confirm;
  return `run "${def.name}"${args && Object.keys(args).length ? ` with ${JSON.stringify(args)}` : ''}`;
}
