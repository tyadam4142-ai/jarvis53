/**
 * JARVIS 53 — request guard (Next.js 16 "proxy").
 *  1. Only loopback hostnames are served (blocks DNS-rebinding).
 *  2. Admin pages/APIs do not exist unless JARVIS_ADMIN_MODE=1 (customer installs never set it).
 *  3. State-changing API calls must come from this app's own origin (blocks other websites
 *     from silently driving your PC through http://127.0.0.1:3000).
 */
import { NextResponse, type NextRequest } from 'next/server';

const LOOPBACK = new Set(['127.0.0.1', 'localhost', '[::1]']);

export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const host = (req.headers.get('host') ?? '').toLowerCase();
  const hostname = host.replace(/:\d+$/, '');
  const extra = (process.env.JARVIS_ALLOWED_HOSTS ?? '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  if (!LOOPBACK.has(hostname) && !extra.includes(hostname)) {
    return new NextResponse('Forbidden host', { status: 403 });
  }

  const isAdminPath = pathname === '/admin' || pathname.startsWith('/admin/') || pathname.startsWith('/api/admin');
  if (isAdminPath && process.env.JARVIS_ADMIN_MODE !== '1') {
    return new NextResponse('Not found', { status: 404 });
  }

  const unsafe = !['GET', 'HEAD', 'OPTIONS'].includes(req.method);
  if (unsafe && pathname.startsWith('/api/') && pathname !== '/api/voice/command') {
    const origin = req.headers.get('origin');
    const site = req.headers.get('sec-fetch-site');
    let ok = false;
    if (origin) {
      try { ok = new URL(origin).host.toLowerCase() === host; } catch { ok = false; }
    } else if (site) {
      ok = site === 'same-origin' || site === 'none';
    }
    if (!ok) return NextResponse.json({ error: 'Cross-origin request blocked.' }, { status: 403 });
  }

  const res = NextResponse.next();
  res.headers.set('X-Frame-Options', 'DENY');
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('Referrer-Policy', 'no-referrer');
  return res;
}

export const config = { matcher: ['/((?!_next/static|_next/image|.*\\.(?:svg|png|jpg|jpeg|ico|webp)$).*)'] };
