# J53 All Access v2.6.0 — Deployment guide

## Website
Upload the static site files to your hosting provider and configure the custom domain `this.jarvis53.dynamicrobotics53.com` with the DNS target provided by that host. DNS, hosting, and HTTPS have not been changed from this workspace. Enable HTTPS after domain verification.

## Desktop apps
- macOS: unzip the Mac bundle, then run `start-mac.command`.
- Windows: unzip the Windows bundle, then run `start-windows.bat`.
- Requires Node.js 20.9+ and an internet connection for the first dependency install/build.
- Configure OpenRouter, NVIDIA NIM, and/or Google Gemini keys under Admin → AI Keys. Keep keys out of website code and chat.

## Multi-provider AI failover
All generative features can rotate across OpenRouter, NVIDIA NIM, and Google Gemini. Add keys in the local Admin → AI Keys dashboard and select the matching provider. Environment variables support multiple comma-separated keys: `OPENROUTER_API_KEYS`, `NVIDIA_API_KEYS`, and `GEMINI_API_KEYS`; model overrides are `OPENROUTER_MODEL`, `NVIDIA_MODEL`, and `GEMINI_MODEL`. Keys are stored server-side only. If a provider fails or rate-limits, JARVIS tries another configured cloud key/provider. If all cloud routes fail, the app shows a clear error rather than returning a local-brain answer. Cloud inference may use provider API credits and is not guaranteed free.

## Billing
J53 All Access is the sole subscription: ₹553 monthly or ₹5,530 annually, with the same features in either cycle. The app collects a payment transaction reference and the local admin must verify it manually. The app does not charge a payment method or confirm a transfer automatically. Provider AI usage may cost extra.

## Access/admin scope
Customer activation records and API keys are stored locally in each installation. An approval on your computer does not approve a user on another computer. This desktop package keeps admin OFF (/admin does not exist here) — it is for daily customer use.

**Owner: want the admin portal on your website link instead of a local install?** Deploy `JARVIS-53-WebApp-v2.7.0.zip` (from the website's Download section) on your server — it ships with the database connected and admin enabled at `https://your-domain/admin`. Full steps in its DEPLOY-WEB.md.

## Test before publishing
From each app folder, run `npm install` and `npm run build`, then launch the app and verify a local command, a general AI question, a multi-step request, provider rotation, invalid-key handling, a rate-limit case, and an all-providers-unavailable state. Confirm that every generative request either receives a cloud response or clearly reports failure—never a local-brain answer.
