#!/bin/bash
# JARVIS 53 — system diagnostic for macOS
cd "$(dirname "$0")" || exit 1
CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'; GOLD='\033[0;33m'; NC='\033[0m'
echo ""
echo -e "${CYAN}════════ JARVIS 53 · SYSTEM DOCTOR ════════${NC}"
echo ""

# Node
if command -v node >/dev/null 2>&1; then
  V=$(node -v); MAJOR=$(node -e 'console.log(process.versions.node.split(".")[0])')
  if [ "$MAJOR" -ge 18 ]; then echo -e "${GREEN}[✓] Node.js $V${NC}"; else echo -e "${RED}[X] Node.js $V — upgrade to 18+ from nodejs.org${NC}"; fi
else
  echo -e "${RED}[X] Node.js missing — install the LTS from nodejs.org${NC}"
fi

# npm
command -v npm >/dev/null 2>&1 && echo -e "${GREEN}[✓] npm $(npm -v)${NC}" || echo -e "${RED}[X] npm missing${NC}"

# Dependencies
[ -d node_modules ] && echo -e "${GREEN}[✓] Dependencies installed${NC}" || echo -e "${GOLD}[!] Dependencies not installed yet — run start-mac.command${NC}"

# Build
[ -f .next/BUILD_ID ] && echo -e "${GREEN}[✓] Production build present${NC}" || echo -e "${GOLD}[!] No build yet — start-mac.command creates it${NC}"

# Database
[ -f db/custom.db ] && echo -e "${GREEN}[✓] Database file present${NC}" || echo -e "${GOLD}[!] Database not initialized yet${NC}"

# Port 3000
if lsof -ti tcp:3000 >/dev/null 2>&1; then
  echo -e "${GOLD}[!] Port 3000 is busy — JARVIS may already be running, or run stop-mac.command first${NC}"
else
  echo -e "${GREEN}[✓] Port 3000 is free${NC}"
fi

# Disk
FREE=$(df -h . | tail -1 | awk '{print $4}')
echo -e "${GREEN}[✓] Free disk space: $FREE${NC}"

# Permissions hint
echo ""
echo -e "${CYAN}TIP:${NC} On first automation, macOS asks for Automation/Accessibility permission."
echo "     Allow it: System Settings → Privacy & Security → Automation."
echo ""
