#!/bin/bash
set -e
cd "$(dirname "$0")/.." || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required for system-wide push-to-talk. Install Python 3.10+ from https://www.python.org/downloads/macos/ and run this installer again."
  open "https://www.python.org/downloads/macos/" 2>/dev/null || true
  exit 1
fi
PY_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
python3 - <<'PY' || { echo "Python 3.10+ is required."; exit 1; }
import sys
raise SystemExit(0 if sys.version_info >= (3, 10) else 1)
PY

if [ ! -x native/.venv/bin/python ]; then
  python3 -m venv native/.venv
fi
native/.venv/bin/python -m pip install --upgrade pip
native/.venv/bin/python -m pip install -r native/requirements.txt

echo "\nDownloading/preparing the local English speech model (base.en). This happens once."
native/.venv/bin/python - <<'PY'
from faster_whisper import WhisperModel
WhisperModel('base.en', device='cpu', compute_type='int8')
print('Local speech model is ready.')
PY
chmod +x native/global_voice_bridge.py
cat <<'TXT'

GLOBAL VOICE SETUP COMPLETE
1. Open System Settings → Privacy & Security → Microphone and allow Terminal/Python.
2. Open System Settings → Privacy & Security → Input Monitoring and allow Terminal/Python.
3. Restart JARVIS using start-mac.command.
4. Hold Right Option (⌥) or Right Command (⌘) while speaking in any app, then release to run the command.
   (F8 is intentionally not used on macOS — the system maps it to Play/Pause media.)

Prefer a different key? Set JARVIS_HOTKEY in .env style, e.g.:
   JARVIS_HOTKEY="right_command"    (options: right_option, right_command, right_ctrl, caps_lock, f1..f12)

If the keyboard listener does not see the key, check your keyboard's Fn/F-key setting.
Audio transcription runs locally. The recognized text is sent to your local JARVIS server;
JARVIS's selected AI provider may be online according to the configured plan.
TXT
