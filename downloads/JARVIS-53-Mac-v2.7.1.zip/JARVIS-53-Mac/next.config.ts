import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // "standalone" output is for Docker images; the J53 launcher runs `next start`
  // from this folder, where the default output is more reliable.
  reactStrictMode: false,
  // Keep Turbopack's workspace root pinned to this project instead of a parent
  // directory that may contain unrelated package-lock.json files.
  turbopack: { root: process.cwd() },
};

export default nextConfig;
