'use client';

/**
 * JARVIS 53 — Master Admin Portal (standalone route).
 * Direct link: http://127.0.0.1:3000/admin  (or https://your-host/admin)
 * PIN-gated, completely separate from the customer HUD — customers never see this.
 * Bookmark it on your phone/laptop: same PIN, same dashboard, dedicated URL.
 */
import { useEffect } from 'react';
import { Palette } from 'lucide-react';
import Admin from '@/components/jarvis/Admin';
import Customize from '@/components/jarvis/Customize';
import { useJarvis, loadAppearance, applyAppearance } from '@/components/jarvis/store';

function AdminTopBar() {
  const setCustomizeOpen = useJarvis((s) => s.setCustomizeOpen);
  return (
    <header className="relative z-10 border-b border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.6)] backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-2.5 sm:px-5">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full border border-[rgba(var(--j53-gold-rgb),0.45)] shadow-[0_0_16px_rgba(var(--j53-gold-rgb),0.25)]">
            <div className="h-3.5 w-3.5 rounded-full bg-[radial-gradient(circle,#fff_0%,var(--j53-gold)_60%,transparent_100%)]" />
          </div>
          <div>
            <p className="j53-display text-[13px] font-bold tracking-[0.2em] text-[var(--j53-text)]">
              JARVIS <span className="text-[var(--j53-gold)]">53</span>
            </p>
            <p className="j53-label" style={{ fontSize: 7.5 }}>
              master command · restricted
            </p>
          </div>
        </div>
        <button
          className="j53-pill cursor-pointer"
          style={{ cursor: 'pointer', color: 'var(--j53-gold)', borderColor: 'rgba(var(--j53-gold-rgb),0.35)' }}
          onClick={() => setCustomizeOpen(true)}
          aria-label="Open appearance lab"
          type="button"
        >
          <Palette className="h-3 w-3" /> <span className="hidden sm:inline">Customize</span>
        </button>
        <span className="j53-pill font-mono" style={{ color: 'var(--j53-gold)', fontSize: 8 }}>
          ● ADMIN CHANNEL
        </span>
      </div>
    </header>
  );
}

export default function AdminPage() {
  // Ensure the HUD phase never routes this window into the customer boot flow.
  useEffect(() => {
    const s = useJarvis.getState();
    if (s.phase !== 'app') s.setPhase('app');
    const saved = loadAppearance();
    applyAppearance(saved);
    useJarvis.setState({ appearance: saved });
  }, []);

  return (
    <div className="j53-root">
      <div className="flex min-h-screen flex-col">
        <AdminTopBar />
        <main className="relative z-10 mx-auto w-full max-w-6xl flex-1 px-3 py-5 sm:px-5">
          <Admin />
        </main>
        <footer className="relative z-10 border-t border-[rgba(var(--j53-accent-rgb),0.08)] bg-[rgba(var(--j53-bg-rgb),0.55)] py-3">
          <p className="j53-label text-center">
            Master portal · PIN-protected ·{' '}
            <a href="/" className="text-[var(--j53-accent)]/70 transition-colors hover:text-[var(--j53-accent)]">
              back to customer console
            </a>
          </p>
        </footer>
      </div>
      <Customize />
    </div>
  );
}
