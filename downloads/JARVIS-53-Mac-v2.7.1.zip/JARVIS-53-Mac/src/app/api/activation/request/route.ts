import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSetting, logUsage, DEFAULT_MASTER_PIN } from '@/lib/data';
import { DEFAULT_PLAN, subscriptionPrice } from '@/lib/tools/registry';

function normalizePhone(raw: string): string | null {
  const cleaned = raw.replace(/[^\d+]/g, '');
  if (!/^\+?\d{8,15}$/.test(cleaned)) return null;
  return cleaned.startsWith('+') ? cleaned : `+${cleaned}`;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const phone = normalizePhone(String(body.phone ?? ''));
    if (!phone) return NextResponse.json({ error: 'Enter a valid international phone number (e.g. +919876543210).' }, { status: 400 });
    const paymentRef = String(body.paymentRef ?? '').trim().slice(0, 200);
    if (paymentRef.length < 4) return NextResponse.json({ error: 'A UPI or bank transaction reference is required for manual verification.' }, { status: 400 });
    const billingCycle = body.billingCycle === 'annual' ? 'annual' : 'monthly';
    const name = String(body.name ?? '').trim().slice(0, 80) || null;
    const existing = await db.customer.findUnique({ where: { phone } });

    // Never auto-approve a paid plan. An already-active account remains active and cannot be charged twice through this screen.
    if (existing?.status === 'active' && (!existing.subscriptionEndsAt || existing.subscriptionEndsAt.getTime() > Date.now())) {
      return NextResponse.json({ status: 'active', plan: DEFAULT_PLAN, name: existing.name, phone: existing.phone, message: 'This account already has active access. Do not pay again before the current term expires.' });
    }

    const data = { name: name ?? existing?.name ?? null, plan: DEFAULT_PLAN, billingCycle, paymentRef, paymentStatus: 'pending', lastSeenAt: new Date(), status: 'pending' };
    const customer = existing
      ? await db.customer.update({ where: { phone }, data })
      : await db.customer.create({ data: { phone, ...data } });
    void logUsage(phone, 'activation', `plan=${customer.plan}; cycle=${billingCycle}; payment-status=pending; transaction reference submitted; status=${customer.status}`);
    return NextResponse.json({
      status: customer.status,
      plan: DEFAULT_PLAN,
      billingCycle: customer.billingCycle,
      paymentStatus: customer.paymentStatus,
      name: customer.name,
      phone: customer.phone,
      message: 'Payment reference received. An administrator must verify the transaction before access is activated.',
    });
  } catch (e) {
    return NextResponse.json({ error: `Subscription request failed: ${(e as Error).message}` }, { status: 500 });
  }
}

export async function GET() {
  const upiId = await getSetting('paymentUpiId', process.env.JARVIS_UPI_ID || '');
  const paymentInstructions = await getSetting('paymentInstructions', process.env.JARVIS_PAYMENT_INSTRUCTIONS || 'Contact Dynamic Robotics for official payment instructions before paying.');
  return NextResponse.json({
    plans: [DEFAULT_PLAN], defaultPlan: DEFAULT_PLAN,
    monthlyPrice: subscriptionPrice('monthly'), annualPrice: subscriptionPrice('annual'), currency: 'INR',
    upiId, paymentInstructions,
  });
}
