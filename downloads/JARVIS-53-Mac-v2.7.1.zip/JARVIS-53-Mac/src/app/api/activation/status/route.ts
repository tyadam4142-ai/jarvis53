import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  const phone = req.nextUrl.searchParams.get('phone')?.replace(/[^\d+]/g, '');
  if (!phone) return NextResponse.json({ error: 'phone required' }, { status: 400 });

  const customer = await db.customer.findUnique({ where: { phone } });
  if (!customer) return NextResponse.json({ status: 'unknown' });

  let effectiveStatus = customer.status;
  if (customer.status === 'active' && customer.subscriptionEndsAt && customer.subscriptionEndsAt.getTime() <= Date.now()) {
    effectiveStatus = 'expired';
    await db.customer.update({ where: { phone }, data: { status: 'expired' } }).catch(() => undefined);
  } else if (customer.status === 'active') {
    await db.customer.update({ where: { phone }, data: { lastSeenAt: new Date() } }).catch(() => undefined);
  }

  const announcement = await db.announcement.findFirst({ where: { active: true }, orderBy: { createdAt: 'desc' } });

  return NextResponse.json({
    status: effectiveStatus,
    plan: customer.plan === 'free' ? 'all-access' : customer.plan,
    billingCycle: customer.billingCycle ?? 'monthly',
    subscriptionEndsAt: customer.subscriptionEndsAt?.toISOString() ?? null,
    name: customer.name,
    announcement: announcement ? { id: announcement.id, title: announcement.title, body: announcement.body, level: announcement.level } : null,
  });
}
