import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { guard } from '@/lib/admin-auth';

export async function GET(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const announcements = await db.announcement.findMany({ orderBy: { createdAt: 'desc' }, take: 50 });
  return NextResponse.json({ announcements });
}

export async function POST(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const title = String(body.title ?? '').slice(0, 120);
    const text = String(body.body ?? '').slice(0, 1000);
    const level = ['info', 'success', 'warning'].includes(String(body.level)) ? String(body.level) : 'info';
    if (!title || !text) return NextResponse.json({ error: 'title and body required' }, { status: 400 });
    const announcement = await db.announcement.create({ data: { title, body: text, level } });
    return NextResponse.json({ announcement });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const id = Number(req.nextUrl.searchParams.get('id'));
  if (!Number.isFinite(id)) return NextResponse.json({ error: 'id required' }, { status: 400 });
  await db.announcement.delete({ where: { id } }).catch(() => undefined);
  return NextResponse.json({ ok: true });
}
