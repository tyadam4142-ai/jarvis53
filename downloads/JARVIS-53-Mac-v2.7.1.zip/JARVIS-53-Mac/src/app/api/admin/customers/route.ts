import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { guard } from '@/lib/admin-auth';

export async function GET(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  // Return the minimum subscription fields needed for manual payment verification.
  const customers = await db.customer.findMany({
    select: { id: true, phone: true, name: true, plan: true, billingCycle: true, paymentRef: true, paymentStatus: true, subscriptionEndsAt: true, status: true, createdAt: true, approvedAt: true, lastSeenAt: true, notes: true },
    orderBy: { createdAt: 'desc' },
    take: 500,
  });
  return NextResponse.json({ customers });
}

/** Actions: approve | decline | suspend | reactivate | delete | update */
export async function POST(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const action = String(body.action ?? '');
    const id = Number(body.id);
    if (!Number.isFinite(id)) return NextResponse.json({ error: 'id required' }, { status: 400 });

    const existing = await db.customer.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Customer not found' }, { status: 404 });

    switch (action) {
      case 'approve': {
        if (!existing.paymentRef || existing.paymentRef.trim().length < 4) return NextResponse.json({ error: 'Cannot activate: no transaction reference is on file. Verify the payment reference first.' }, { status: 400 });
        if (existing.status === 'active' && existing.subscriptionEndsAt && existing.subscriptionEndsAt.getTime() > Date.now()) return NextResponse.json({ error: 'This subscription is already active. Do not approve the same payment twice.' }, { status: 409 });
        const now = new Date();
        const startsAt = existing.subscriptionEndsAt && existing.subscriptionEndsAt.getTime() > now.getTime() ? existing.subscriptionEndsAt : now;
        const end = new Date(startsAt);
        if (existing.billingCycle === 'annual') {
          const month = end.getMonth();
          const day = end.getDate();
          end.setDate(1);
          end.setFullYear(end.getFullYear() + 1);
          end.setMonth(month);
          const lastDay = new Date(end.getFullYear(), end.getMonth() + 1, 0).getDate();
          end.setDate(Math.min(day, lastDay));
        } else {
          const month = end.getMonth();
          const day = end.getDate();
          end.setDate(1);
          end.setMonth(month + 1);
          const lastDay = new Date(end.getFullYear(), end.getMonth() + 1, 0).getDate();
          end.setDate(Math.min(day, lastDay));
        }
        await db.customer.update({ where: { id }, data: { status: 'active', plan: 'all-access', paymentStatus: 'verified', approvedAt: now, subscriptionEndsAt: end } });
        break;
      }
      case 'decline':
        await db.customer.update({ where: { id }, data: { status: 'declined', paymentStatus: 'rejected' } });
        break;
      case 'suspend':
        await db.customer.update({ where: { id }, data: { status: 'suspended' } });
        break;
      case 'reactivate':
        await db.customer.update({ where: { id }, data: { status: 'active' } });
        break;
      case 'delete':
        await db.customer.delete({ where: { id } });
        break;
      case 'update': {
        const data: Record<string, string | null> = {};
        if (typeof body.notes === 'string') data.notes = body.notes.slice(0, 1000) || null;
        if (typeof body.paymentRef === 'string') data.paymentRef = body.paymentRef.trim().slice(0, 200) || null;
        if (body.billingCycle === 'monthly' || body.billingCycle === 'annual') data.billingCycle = body.billingCycle;
        data.plan = 'all-access';
        if (typeof body.name === 'string') data.name = body.name.slice(0, 80) || null;
        await db.customer.update({ where: { id }, data });
        break;
      }
      default:
        return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
