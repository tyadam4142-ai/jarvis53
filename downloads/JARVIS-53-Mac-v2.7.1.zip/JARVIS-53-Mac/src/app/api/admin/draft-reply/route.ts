import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { guard } from '@/lib/admin-auth';
import { draftTicketReply } from '@/lib/ai/provider';

/** AI drafts a reply for a support ticket — admin reviews, edits, sends. */
export async function POST(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const ticketId = Number(body.ticketId);
    if (!Number.isFinite(ticketId)) return NextResponse.json({ error: 'ticketId required' }, { status: 400 });
    const ticket = await db.ticket.findUnique({ where: { id: ticketId }, include: { replies: { orderBy: { createdAt: 'asc' } } } });
    if (!ticket) return NextResponse.json({ error: 'Ticket not found' }, { status: 404 });
    const draft = await draftTicketReply(
      { subject: ticket.subject, phone: ticket.phone },
      ticket.replies.map((r) => ({ author: r.author, body: r.body }))
    );
    return NextResponse.json({ draft });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
