import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { guard } from '@/lib/admin-auth';

/** Customer roster CSV export. */
export async function GET(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const customers = await db.customer.findMany({ orderBy: { createdAt: 'desc' } });
  const rows = [
    ['id', 'phone', 'name', 'plan', 'billingCycle', 'paymentRef', 'paymentStatus', 'subscriptionEndsAt', 'status', 'createdAt', 'approvedAt', 'lastSeenAt', 'notes'],
    ...customers.map((c) => [
      String(c.id),
      c.phone,
      c.name ?? '',
      c.plan === 'free' ? 'all-access' : c.plan,
      c.billingCycle ?? 'monthly',
      c.paymentRef ?? '',
      c.paymentStatus ?? 'pending',
      c.subscriptionEndsAt?.toISOString() ?? '',
      c.status,
      c.createdAt.toISOString(),
      c.approvedAt?.toISOString() ?? '',
      c.lastSeenAt?.toISOString() ?? '',
      (c.notes ?? '').replace(/[\r\n]+/g, ' '),
    ]),
  ];
  const csv = rows.map((r) => r.map((f) => `"${f.replace(/"/g, '""')}"`).join(',')).join('\n');
  return new NextResponse(csv, {
    headers: {
      'content-type': 'text/csv; charset=utf-8',
      'content-disposition': `attachment; filename="jarvis53-customers-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
