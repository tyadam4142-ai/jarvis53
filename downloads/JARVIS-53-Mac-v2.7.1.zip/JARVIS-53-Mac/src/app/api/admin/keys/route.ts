import { NextRequest, NextResponse } from 'next/server';
import { guard } from '@/lib/admin-auth';
import { poolStatus, addKey, removeKey, type AIProvider } from '@/lib/ai/keys';

const VALID_PROVIDERS: AIProvider[] = ['openrouter', 'nvidia', 'gemini'];

export async function GET(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const keys = await poolStatus();
  return NextResponse.json({ keys, providers: VALID_PROVIDERS }, { headers: { 'Cache-Control': 'no-store' } });
}

export async function POST(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const action = String(body.action ?? '');
    const provider = String(body.provider ?? 'openrouter') as AIProvider;
    if (!VALID_PROVIDERS.includes(provider)) {
      return NextResponse.json({ error: 'Choose OpenRouter, NVIDIA NIM, or Google Gemini.' }, { status: 400 });
    }
    if (action === 'add') {
      const okAdd = await addKey(provider, String(body.key ?? ''));
      if (!okAdd) return NextResponse.json({ error: 'This key is too short or is already registered for that provider.' }, { status: 400 });
      return NextResponse.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } });
    }
    if (action === 'remove') {
      const okRemove = await removeKey(provider, String(body.keyId ?? ''));
      if (!okRemove) return NextResponse.json({ error: 'This key is supplied by the environment or was not found. Remove environment keys from .env.' }, { status: 400 });
      return NextResponse.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } });
    }
    return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
