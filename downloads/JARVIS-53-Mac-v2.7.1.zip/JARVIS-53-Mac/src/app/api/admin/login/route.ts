import { NextRequest, NextResponse } from 'next/server';
import { getMasterPin, tokenFor, adminCookieName, pinIsUsable, safeEqual, loginThrottled, loginFailed, loginOk } from '@/lib/admin-auth';
import { logUsage } from '@/lib/data';

export async function POST(req: NextRequest) {
  try {
    if (process.env.JARVIS_ADMIN_MODE !== '1') return NextResponse.json({ error: 'Not found' }, { status: 404 });
    const key = 'admin';
    if (loginThrottled(key)) {
      return NextResponse.json({ ok: false, error: 'Too many attempts. Wait 5 minutes.' }, { status: 429 });
    }
    const body = await req.json();
    const pin = String(body.pin ?? '').trim();
    const master = await getMasterPin();
    if (!pinIsUsable(master)) {
      return NextResponse.json({ ok: false, error: 'Admin is locked. Set JARVIS_ADMIN_PIN (6+ characters, not a common code) in .env and restart.' }, { status: 403 });
    }
    if (!safeEqual(pin, master)) {
      loginFailed(key);
      return NextResponse.json({ ok: false, error: 'Invalid admin PIN.' }, { status: 401 });
    }
    loginOk(key);
    const res = NextResponse.json({ ok: true, pinIsDefault: false });
    res.cookies.set(adminCookieName(), tokenFor(master), { httpOnly: true, sameSite: 'strict', path: '/', maxAge: 60 * 60 * 4 });
    void logUsage(null, 'admin', 'master-login');
    return res;
  } catch (e) {
    return NextResponse.json({ ok: false, error: (e as Error).message }, { status: 500 });
  }
}
