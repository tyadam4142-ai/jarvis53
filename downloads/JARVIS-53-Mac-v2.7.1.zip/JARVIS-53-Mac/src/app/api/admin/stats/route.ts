import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { guard } from '@/lib/admin-auth';
import { poolCount } from '@/lib/ai/keys';
import { aiStatus } from '@/lib/ai/provider';

export async function GET(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

  const [customers, usage7d, topTools, chats, ticketsOpen, pool, ai] = await Promise.all([
    db.customer.findMany(),
    db.usageLog.findMany({ where: { createdAt: { gte: new Date(Date.now() - 7 * 86400000) } } }),
    db.usageLog.groupBy({ by: ['detail'], where: { kind: 'tool' }, _count: { detail: true }, orderBy: { _count: { detail: 'desc' } }, take: 8 }),
    db.usageLog.count({ where: { kind: 'chat', createdAt: { gte: new Date(Date.now() - 86400000) } } }),
    db.ticket.count({ where: { status: { not: 'closed' } } }),
    poolCount(),
    aiStatus(),
  ]);

  const byStatus = { pending: 0, active: 0, declined: 0, suspended: 0, expired: 0 };
  for (const c of customers) {
    if (c.status in byStatus) byStatus[c.status as keyof typeof byStatus] += 1;
  }

  // 7-day activity series
  const days: Array<{ day: string; label: string; chats: number; tools: number }> = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    const next = new Date(d.getTime() + 86400000);
    const inDay = usage7d.filter((u) => u.createdAt >= d && u.createdAt < next);
    days.push({
      day: d.toISOString().slice(0, 10),
      label: d.toLocaleDateString(undefined, { weekday: 'short' }),
      chats: inDay.filter((u) => u.kind === 'chat').length,
      tools: inDay.filter((u) => u.kind === 'tool').length,
    });
  }

  const recent = await db.usageLog.findMany({ orderBy: { createdAt: 'desc' }, take: 12 });

  return NextResponse.json({
    totals: {
      customers: customers.length,
      ...byStatus,
      chats24h: chats,
      toolsRun7d: usage7d.filter((u) => u.kind === 'tool').length,
      openTickets: ticketsOpen,
    },
    days,
    topTools: topTools.map((t) => ({ tool: t.detail ?? '—', count: t._count.detail })),
    recent: recent.map((r) => ({ kind: r.kind, detail: r.detail, phone: r.phone, at: r.createdAt })),
    keyPool: pool,
    aiProvider: ai.provider,
  });
}
