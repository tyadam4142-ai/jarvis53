import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { guard } from '@/lib/admin-auth';

export async function GET(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const tickets = await db.ticket.findMany({
    include: { replies: { orderBy: { createdAt: 'asc' } } },
    orderBy: { updatedAt: 'desc' },
    take: 100,
  });
  return NextResponse.json({ tickets });
}

/** Admin reply or status change. Body: {action:'reply', ticketId, body} | {action:'status', ticketId, status} */
export async function POST(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const action = String(body.action ?? 'reply');
    const ticketId = Number(body.ticketId);
    if (!Number.isFinite(ticketId)) return NextResponse.json({ error: 'ticketId required' }, { status: 400 });

    if (action === 'reply') {
      const text = String(body.body ?? '').trim();
      if (!text) return NextResponse.json({ error: 'Reply body required' }, { status: 400 });
      await db.ticketReply.create({ data: { ticketId, author: 'admin', body: text } });
      await db.ticket.update({ where: { id: ticketId }, data: { status: 'waiting' } });
      return NextResponse.json({ ok: true });
    }
    if (action === 'status') {
      const status = String(body.status ?? 'open');
      if (!['open', 'waiting', 'closed'].includes(status)) return NextResponse.json({ error: 'bad status' }, { status: 400 });
      await db.ticket.update({ where: { id: ticketId }, data: { status } });
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
