import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  const announcement = await db.announcement.findFirst({ where: { active: true }, orderBy: { createdAt: 'desc' } });
  return NextResponse.json({ announcement });
}
