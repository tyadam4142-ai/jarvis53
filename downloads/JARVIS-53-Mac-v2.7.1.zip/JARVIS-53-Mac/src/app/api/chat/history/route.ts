import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

function normalizePhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const phone = raw.replace(/[^\d+]/g, '');
  return /^\+?\d{8,15}$/.test(phone) ? (phone.startsWith('+') ? phone : `+${phone}`) : null;
}

/** Load the tail of this customer's conversation so the HUD restores instantly. */
export async function GET(req: NextRequest) {
  try {
    const phone = normalizePhone(req.nextUrl.searchParams.get('phone'));
    const limitRaw = Number(req.nextUrl.searchParams.get('limit') ?? '60');
    const limit = Number.isFinite(limitRaw) ? Math.min(120, Math.max(10, Math.trunc(limitRaw))) : 60;

    const rows = await db.chatMessage.findMany({
      where: phone ? { phone } : {},
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
    const messages = rows.reverse().map((r) => ({
      id: r.id,
      role: r.role === 'user' ? 'user' : 'jarvis',
      text: r.content,
      provider: r.provider ?? undefined,
      model: r.model ?? undefined,
      ts: r.createdAt.getTime(),
    }));
    return NextResponse.json({ messages });
  } catch {
    return NextResponse.json({ messages: [] });
  }
}

/** Persist one finished exchange (user utterance or JARVIS reply). */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const phone = normalizePhone(body.phone);
    const id = typeof body.id === 'string' && body.id.length >= 4 ? body.id.slice(0, 64) : null;
    const role = body.role === 'user' ? 'user' : 'jarvis';
    const content = String(body.content ?? '').slice(0, 8000);
    if (!id || !content.trim()) return NextResponse.json({ ok: false, error: 'invalid message' }, { status: 400 });
    const provider = typeof body.provider === 'string' ? body.provider.slice(0, 40) : null;
    const model = typeof body.model === 'string' ? body.model.slice(0, 120) : null;
    await db.chatMessage.upsert({
      where: { id },
      update: { content, provider, model },
      create: { id, phone, role, content, provider, model },
    });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false }, { status: 200 });
  }
}

/** Wipe the conversation (user pressed "Clear"). */
export async function DELETE(req: NextRequest) {
  try {
    const phone = normalizePhone(req.nextUrl.searchParams.get('phone'));
    await db.chatMessage.deleteMany({ where: phone ? { phone } : {} });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false }, { status: 200 });
  }
}
