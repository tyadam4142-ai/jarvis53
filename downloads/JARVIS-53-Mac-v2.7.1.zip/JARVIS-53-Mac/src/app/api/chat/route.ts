import { NextRequest, NextResponse } from 'next/server';
import { jarvisThink } from '@/lib/ai/provider';
import { runTool, type ToolOutcome } from '@/lib/tools/runner';
import { logUsage } from '@/lib/data';
import { db } from '@/lib/db';

function normalizePhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const phone = raw.replace(/[^\d+]/g, '');
  return /^\+?\d{8,15}$/.test(phone) ? (phone.startsWith('+') ? phone : `+${phone}`) : null;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const text = String(body.text ?? '').trim().slice(0, 4000);
    const suppliedPhone = body.phone ? normalizePhone(body.phone) : null;
    const history = Array.isArray(body.history)
      ? body.history
          .filter((m: { role?: unknown; content?: unknown }) =>
            (m?.role === 'user' || m?.role === 'assistant') && typeof m?.content === 'string'
          )
          .slice(-8)
          .map((m: { role: 'user' | 'assistant'; content: string }) => ({ role: m.role, content: m.content.slice(0, 4000) }))
      : [];
    if (!text) return NextResponse.json({ error: 'Please enter a message.' }, { status: 400 });
    if (body.phone && !suppliedPhone) return NextResponse.json({ error: 'The activation phone number is invalid. Reopen JARVIS and activate again.' }, { status: 400 });

    // Use the database's approved plan, not a plan name that the browser can freely claim.
    const customer = suppliedPhone
      ? await db.customer.findUnique({ where: { phone: suppliedPhone } })
      : await db.customer.findFirst({ where: { status: 'active' }, orderBy: { lastSeenAt: 'desc' } });
    if (suppliedPhone && (!customer || customer.status !== 'active')) {
      return NextResponse.json({ error: 'This JARVIS account is not active yet. Complete the activation approval first.' }, { status: 403 });
    }
    const plan = customer?.plan ?? process.env.JARVIS_DEFAULT_PLAN ?? 'all-access';
    const result = await jarvisThink(history, text, plan);

    // Never execute model-proposed actions when its configured route failed.
    const actions: ToolOutcome[] = [];
    if (result.provider !== 'unavailable') {
      for (const action of result.actions) {
        const outcome = await runTool(action.tool, action.args ?? {}, { phone: suppliedPhone, source: 'ai' });
        actions.push(outcome);
      }
    }

    void logUsage(suppliedPhone, 'chat', `${plan}:${result.provider}:${result.model ?? 'local'}:${text.slice(0, 100)}`);
    return NextResponse.json({
      say: result.say,
      actions,
      provider: result.provider,
      model: result.model,
      routeNote: result.routeNote,
      plan,
    });
  } catch (e) {
    const message = e instanceof Error ? e.message : 'Unknown error';
    return NextResponse.json({ error: `JARVIS could not complete that request: ${message.slice(0, 350)}` }, { status: 500 });
  }
}
