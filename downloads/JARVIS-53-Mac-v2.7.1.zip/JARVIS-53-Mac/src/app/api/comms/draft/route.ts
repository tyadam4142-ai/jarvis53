import { NextRequest, NextResponse } from 'next/server';
import { draftMessage } from '@/lib/ai/provider';
import { logUsage } from '@/lib/data';

/**
 * POST /api/comms/draft — AI-draft a WhatsApp message or email for the Comms deck.
 * Body: { channel: 'whatsapp'|'email', brief, recipient?, tone? }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const channel = body.channel === 'whatsapp' ? 'whatsapp' : 'email';
    const brief = String(body.brief ?? '').trim().slice(0, 2000);
    if (!brief) {
      return NextResponse.json({ error: 'Tell JARVIS what the message should say (a short brief).' }, { status: 400 });
    }
    const recipient = body.recipient ? String(body.recipient).slice(0, 200) : null;
    const tone = body.tone ? String(body.tone).slice(0, 60) : null;

    const draft = await draftMessage({ channel, brief, recipient, tone });
    void logUsage(null, 'comms_draft', `${channel} via ${tone ?? 'default'}`);
    return NextResponse.json(draft);
  } catch (e) {
    return NextResponse.json({ error: `Draft failed: ${(e as Error).message}` }, { status: 500 });
  }
}
