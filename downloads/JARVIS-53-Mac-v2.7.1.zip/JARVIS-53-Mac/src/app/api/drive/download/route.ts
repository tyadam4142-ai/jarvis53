import { NextRequest, NextResponse } from 'next/server';
import { driveBucket, zipDrive } from '@/lib/drive';

/**
 * GET /api/drive/download[?phone=...]
 * Streams the entire JARVIS Drive as a zip (zero-dependency zip writer,
 * works on every platform).
 */
export async function GET(req: NextRequest) {
  try {
    const bucket = driveBucket(req.nextUrl.searchParams.get('phone'));
    const zip = await zipDrive(bucket);
    if (!zip) {
      return new NextResponse('Your JARVIS Drive is empty — nothing to download yet.', { status: 404 });
    }
    const stamp = new Date().toISOString().slice(0, 10);
    return new NextResponse(new Uint8Array(zip), {
      status: 200,
      headers: {
        'content-type': 'application/zip',
        'content-length': String(zip.length),
        'content-disposition': `attachment; filename="JARVIS-Drive-${stamp}.zip"`,
        'cache-control': 'no-store',
      },
    });
  } catch (e) {
    return new NextResponse(`Download failed: ${(e as Error).message}`, { status: 500 });
  }
}
