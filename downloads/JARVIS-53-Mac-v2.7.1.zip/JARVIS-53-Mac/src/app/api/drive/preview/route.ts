import { NextRequest, NextResponse } from 'next/server';
import { driveBucket, readDriveFile, contentTypeFor } from '@/lib/drive';

/**
 * GET /api/drive/preview?name=site.html[&phone=...]
 * Serves a Drive file with the right content type so Studio can render it
 * live inside a sandboxed iframe (scripts run, but they can never touch
 * JARVIS itself: no same-origin access, no top navigation).
 */
export async function GET(req: NextRequest) {
  const name = req.nextUrl.searchParams.get('name') ?? '';
  const phone = req.nextUrl.searchParams.get('phone');
  if (!name) return new NextResponse('Missing file name.', { status: 400 });
  try {
    const bucket = driveBucket(phone);
    const file = await readDriveFile(bucket, name, 3_000_000);
    const headers = new Headers({
      'content-type': contentTypeFor(name),
      'x-content-type-options': 'nosniff',
      'x-frame-options': 'SAMEORIGIN',
      'cache-control': 'no-store',
      'content-security-policy':
        "default-src 'self' data: blob: 'unsafe-inline'; frame-ancestors 'self'; form-action 'none'; base-uri 'none'",
    });
    return new NextResponse(file.content, { status: 200, headers });
  } catch (e) {
    return new NextResponse(`Drive preview error: ${(e as Error).message}`, { status: 404 });
  }
}
