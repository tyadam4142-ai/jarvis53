import { NextRequest, NextResponse } from 'next/server';
import { driveBucket, listDrive, writeDriveFile, deleteDrivePath, MAX_FILE_BYTES } from '@/lib/drive';

/**
 * JARVIS Drive REST surface (Studio → Drive + chat tool cards).
 * GET    /api/drive            → list files
 * POST   /api/drive            → { name, content, append? } → create/update
 * DELETE /api/drive?name=x     → delete a file/folder
 */

function bucketFrom(req: NextRequest, body?: unknown): string {
  const raw = body && typeof body === 'object' ? (body as { phone?: unknown }).phone : req.nextUrl.searchParams.get('phone');
  return driveBucket(typeof raw === 'string' ? raw : null);
}

export async function GET(req: NextRequest) {
  try {
    const bucket = bucketFrom(req);
    const entries = await listDrive(bucket);
    return NextResponse.json({ bucket, entries });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as { name?: unknown; content?: unknown; append?: unknown; phone?: unknown };
    const name = String(body.name ?? '').trim();
    const content = String(body.content ?? '');
    const append = body.append === true;
    if (!name) return NextResponse.json({ error: 'A file name is required.' }, { status: 400 });
    if (Buffer.byteLength(content, 'utf8') > MAX_FILE_BYTES) {
      return NextResponse.json({ error: 'File exceeds the 3 MB Drive limit.' }, { status: 413 });
    }
    const bucket = bucketFrom(req, body);
    const res = await writeDriveFile(bucket, name, content, append);
    return NextResponse.json({ ok: true, name: res.rel, size: res.size, previewUrl: `/api/drive/preview?name=${encodeURIComponent(res.rel)}${body.phone ? `&phone=${encodeURIComponent(String(body.phone))}` : ''}` });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const name = req.nextUrl.searchParams.get('name') ?? '';
    if (!name) return NextResponse.json({ error: 'A file name is required.' }, { status: 400 });
    const bucket = bucketFrom(req);
    const res = await deleteDrivePath(bucket, name);
    return NextResponse.json({ ok: true, name: res.rel });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 400 });
  }
}
