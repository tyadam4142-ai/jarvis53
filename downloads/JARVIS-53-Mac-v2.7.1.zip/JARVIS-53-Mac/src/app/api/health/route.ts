import { NextResponse } from 'next/server';
import os from 'os';
import { PLATFORM, PLATFORM_LABEL } from '@/lib/os';
import { aiStatus } from '@/lib/ai/provider';
import { TOOL_MAP, TOOLS } from '@/lib/tools/registry';
import { LINUX_HANDLERS } from '@/lib/tools/handlers-linux';

export async function GET() {
  const ai = await aiStatus();
  const nativeTools =
    PLATFORM === 'mac'
      ? TOOLS.filter((t) => t.os.includes('mac')).length
      : PLATFORM === 'win'
        ? TOOLS.filter((t) => t.os.includes('win')).length
        : Object.keys(LINUX_HANDLERS).length;
  return NextResponse.json({
    ok: true,
    product: 'JARVIS 53',
    version: '2.7.1',
    vendor: 'Dynamic Robotics',
    platform: PLATFORM,
    platformLabel: PLATFORM_LABEL,
    host: os.hostname(),
    uptimeSec: Math.round(os.uptime()),
    aiProvider: ai.provider,
    keyPool: ai.keys,
    toolCount: TOOLS.length,
    nativeTools,
    toolRegistrySize: Object.keys(TOOL_MAP).length,
    time: new Date().toISOString(),
  });
}
