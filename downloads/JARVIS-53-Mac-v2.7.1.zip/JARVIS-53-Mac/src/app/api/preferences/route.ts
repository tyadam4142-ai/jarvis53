import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

function normalizePhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const phone = raw.replace(/[^\d+]/g, '');
  return /^\+?\d{8,15}$/.test(phone) ? (phone.startsWith('+') ? phone : `+${phone}`) : null;
}

/** Per-customer HUD preferences, so the look & feel follows the account across devices. */
export async function GET(req: NextRequest) {
  try {
    const phone = normalizePhone(req.nextUrl.searchParams.get('phone'));
    if (!phone) return NextResponse.json({ data: null });
    const row = await db.preference.findUnique({ where: { phone } });
    if (!row) return NextResponse.json({ data: null });
    try {
      return NextResponse.json({ data: JSON.parse(row.data) });
    } catch {
      return NextResponse.json({ data: null });
    }
  } catch {
    return NextResponse.json({ data: null });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const phone = normalizePhone(body.phone);
    if (!phone || typeof body.data !== 'object' || body.data === null) {
      return NextResponse.json({ ok: false }, { status: 400 });
    }
    const data = JSON.stringify(body.data).slice(0, 12000);
    await db.preference.upsert({ where: { phone }, update: { data }, create: { phone, data } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false }, { status: 200 });
  }
}
