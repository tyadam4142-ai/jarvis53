import { NextRequest, NextResponse } from 'next/server';
import { conciergeReply } from '@/lib/ai/provider';
import { db } from '@/lib/db';
import { logUsage } from '@/lib/data';

/** AI Concierge — automated customer service. */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const message = String(body.message ?? '').slice(0, 2000);
    const phone = body.phone ? String(body.phone).replace(/[^\d+]/g, '') : null;
    const history = Array.isArray(body.history) ? body.history.slice(-8) : [];
    if (!message.trim()) return NextResponse.json({ error: 'Empty message' }, { status: 400 });

    const result = await conciergeReply(history, message);
    void logUsage(phone, 'support', message.slice(0, 120));

    let ticketId: number | null = null;
    if (result.needsHuman && phone) {
      const ticket = await db.ticket.create({
        data: {
          phone,
          subject: message.slice(0, 70),
          replies: { create: [{ author: 'customer', body: message }] },
        },
      });
      ticketId = ticket.id;
    }

    return NextResponse.json({ text: result.text, needsHuman: result.needsHuman, ticketId, provider: result.provider });
  } catch (e) {
    return NextResponse.json({ error: `Concierge error: ${(e as Error).message}` }, { status: 500 });
  }
}
