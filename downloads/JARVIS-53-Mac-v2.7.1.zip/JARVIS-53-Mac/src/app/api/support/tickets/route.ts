import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/** Customer's own tickets. */
export async function GET(req: NextRequest) {
  const phone = req.nextUrl.searchParams.get('phone')?.replace(/[^\d+]/g, '');
  if (!phone) return NextResponse.json({ tickets: [] });
  const tickets = await db.ticket.findMany({
    where: { phone },
    include: { replies: { orderBy: { createdAt: 'asc' } } },
    orderBy: { updatedAt: 'desc' },
    take: 20,
  });
  return NextResponse.json({ tickets });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const phone = String(body.phone ?? '').replace(/[^\d+]/g, '');
    const subject = String(body.subject ?? '').slice(0, 120);
    const message = String(body.message ?? '').slice(0, 4000);
    if (!phone || !subject) return NextResponse.json({ error: 'phone and subject required' }, { status: 400 });
    const ticket = await db.ticket.create({
      data: { phone, subject, replies: message ? { create: [{ author: 'customer', body: message }] } : undefined },
    });
    return NextResponse.json({ ticket });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
