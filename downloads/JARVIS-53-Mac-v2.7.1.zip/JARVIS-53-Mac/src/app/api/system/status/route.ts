import { NextResponse } from 'next/server';
import os from 'os';
import { PLATFORM, PLATFORM_LABEL, fmtBytes } from '@/lib/os';
import { runTool } from '@/lib/tools/runner';

/** Lightweight diagnostics for the HUD side-panels. Never throws. */
export async function GET() {
  const mem = { total: os.totalmem(), free: os.freemem() };
  const base = {
    platform: PLATFORM,
    platformLabel: PLATFORM_LABEL,
    host: os.hostname(),
    uptimeSec: Math.round(os.uptime()),
    cpuCount: os.cpus().length,
    cpuModel: os.cpus()[0]?.model?.trim() ?? 'Unknown CPU',
    loadPct: Math.min(100, Math.round((os.loadavg()[0] / Math.max(1, os.cpus().length)) * 100)),
    memPct: Math.round(((mem.total - mem.free) / mem.total) * 100),
    memUsed: fmtBytes(mem.total - mem.free),
    memTotal: fmtBytes(mem.total),
  };

  // Best-effort native probes with a hard 6s budget
  const probe = async (toolId: string) => {
    try {
      const r = await Promise.race([
        runTool(toolId, {}, { confirmed: true, source: 'diagnostics' }),
        new Promise<null>((res) => setTimeout(() => res(null), 6000)),
      ]);
      return r && r.status === 'done' ? r.output : null;
    } catch {
      return null;
    }
  };

  const [battery, wifi] = PLATFORM === 'linux' ? [null, null] : await Promise.all([probe('system.battery'), probe('system.wifi')]);

  return NextResponse.json({ ...base, battery, wifi, time: new Date().toISOString() });
}
