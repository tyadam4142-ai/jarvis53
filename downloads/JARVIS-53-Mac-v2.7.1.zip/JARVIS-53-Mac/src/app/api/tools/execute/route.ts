import { NextRequest, NextResponse } from 'next/server';
import { runTool } from '@/lib/tools/runner';

/**
 * Direct tool execution (Quick Actions, Cmd+K palette, confirmed AI actions).
 * Body: { toolId, args?, confirmed?, phone? }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const toolId = String(body.toolId ?? '');
    const args = (body.args ?? {}) as Record<string, unknown>;
    const confirmed = body.confirmed === true;
    const phone = body.phone ? String(body.phone).replace(/[^\d+]/g, '') : null;

    const outcome = await runTool(toolId, args, { confirmed, phone, source: 'quick' });
    return NextResponse.json(outcome);
  } catch (e) {
    return NextResponse.json({ error: `Execution error: ${(e as Error).message}` }, { status: 500 });
  }
}
