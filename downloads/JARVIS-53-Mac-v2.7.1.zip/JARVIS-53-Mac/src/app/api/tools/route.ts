import { NextRequest, NextResponse } from 'next/server';
import { TOOLS } from '@/lib/tools/registry';
import { PLATFORM } from '@/lib/os';

export async function GET() {
  return NextResponse.json({
    platform: PLATFORM,
    tools: TOOLS.map((t) => ({
      ...t,
      available: PLATFORM === 'mac' ? t.os.includes('mac') : PLATFORM === 'win' ? t.os.includes('win') : false,
    })),
  });
}
