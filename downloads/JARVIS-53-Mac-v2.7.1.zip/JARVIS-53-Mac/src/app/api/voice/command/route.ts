import { NextRequest, NextResponse } from 'next/server';
import { timingSafeEqual } from 'crypto';
import { jarvisThink } from '@/lib/ai/provider';
import { runTool, type ToolOutcome } from '@/lib/tools/runner';
import { logUsage } from '@/lib/data';
import { db } from '@/lib/db';

function safeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

/**
 * Loopback-only endpoint for the optional native global push-to-talk companion.
 * It requires a per-launch bearer token and is never meant to be deployed publicly.
 */
export async function POST(req: NextRequest) {
  try {
    const expectedToken = process.env.JARVIS_BRIDGE_TOKEN ?? '';
    const suppliedToken = (req.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '').trim();
    const host = (req.headers.get('host') ?? '').split(':')[0].toLowerCase();
    if (!['127.0.0.1', 'localhost', '[::1]'].includes(host)) {
      return NextResponse.json({ error: 'This endpoint is local-only.' }, { status: 403 });
    }
    if (!expectedToken || !suppliedToken || !safeEqual(expectedToken, suppliedToken)) {
      return NextResponse.json({ error: 'Global voice companion is not authorized. Restart JARVIS and its companion.' }, { status: 401 });
    }

    const body = await req.json();
    const text = String(body.text ?? '').trim().slice(0, 4000);
    if (!text) return NextResponse.json({ error: 'No speech was transcribed.' }, { status: 400 });

    const customer = await db.customer.findFirst({ where: { status: 'active' }, orderBy: { lastSeenAt: 'desc' } });
    const plan = customer?.plan ?? process.env.JARVIS_DEFAULT_PLAN ?? 'all-access';
    const result = await jarvisThink([], text, plan);
    const actions: ToolOutcome[] = [];
    if (result.provider !== 'unavailable') {
      for (const action of result.actions) {
        actions.push(await runTool(action.tool, action.args ?? {}, { phone: customer?.phone ?? null, source: 'ai' }));
      }
    }
    void logUsage(customer?.phone, 'voice', `${plan}:${result.provider}:${text.slice(0, 100)}`);
    return NextResponse.json({ say: result.say, actions, provider: result.provider, model: result.model, routeNote: result.routeNote });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown local voice error';
    return NextResponse.json({ error: `Voice command failed: ${message.slice(0, 300)}` }, { status: 500 });
  }
}
