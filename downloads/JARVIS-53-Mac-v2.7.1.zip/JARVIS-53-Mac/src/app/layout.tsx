import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import SwRegister from "@/components/jarvis/SwRegister";

export const metadata: Metadata = {
  title: "J53 All Access — JARVIS 53 | Dynamic Robotics",
  description:
    "J53 All Access is a voice-first desktop assistant with local computer actions, multi-provider cloud AI failover, system-wide push-to-talk, and risk-aware automation. By Dynamic Robotics.",
  keywords: ["JARVIS", "AI assistant", "macOS automation", "Windows automation", "Dynamic Robotics", "voice control"],
  icons: { icon: "/favicon.svg" },
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "J53 All Access" },
  openGraph: {
    title: "JARVIS 53 — Your Personal AI System",
    description: "Local computer actions, multi-provider cloud AI failover, and system-wide push-to-talk for macOS and Windows.",
    siteName: "Dynamic Robotics",
    type: "website",
    url: "https://jarvis53.dynamicrobotics53.com/",
  },
};

export const viewport: Viewport = {
  themeColor: "#04070f",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        {children}
        <Toaster />
        <SwRegister />
      </body>
    </html>
  );
}
