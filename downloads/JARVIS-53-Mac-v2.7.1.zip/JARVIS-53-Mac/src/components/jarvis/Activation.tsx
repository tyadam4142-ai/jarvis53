'use client';

/** J53 All Access subscription and manual payment verification gate. */
import { useCallback, useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Copy, CreditCard, ShieldCheck } from 'lucide-react';
import { useJarvis } from './store';

type BillingCycle = 'monthly' | 'annual';
type ActivationInfo = { monthlyPrice?: number; annualPrice?: number; upiId?: string; paymentInstructions?: string };
const money = (n: number) => `₹${n.toLocaleString('en-IN')}`;

export default function Activation() {
  const setPhase = useJarvis((s) => s.setPhase);
  const setCustomer = useJarvis((s) => s.setCustomer);
  const setAnnouncement = useJarvis((s) => s.setAnnouncement);
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [billingCycle, setBillingCycle] = useState<BillingCycle>('monthly');
  const [paymentRef, setPaymentRef] = useState('');
  const [info, setInfo] = useState<ActivationInfo>({ monthlyPrice: 553, annualPrice: 5530, upiId: '', paymentInstructions: 'Contact Dynamic Robotics for official payment instructions before paying.' });
  const [state, setState] = useState<'form' | 'pending' | 'granted'>('form');
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const poll = useCallback((num: string) => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/activation/status?phone=${encodeURIComponent(num)}`, { cache: 'no-store' });
        const data = await res.json();
        if (data.announcement) setAnnouncement(data.announcement);
        if (data.status === 'active') {
          if (pollRef.current) clearInterval(pollRef.current);
          localStorage.setItem('j53_phone', num);
          setCustomer({ phone: num, plan: data.plan ?? 'all-access', name: data.name ?? null });
          setState('granted');
          setTimeout(() => setPhase('app'), 1100);
        } else if (data.status === 'expired') {
          if (pollRef.current) clearInterval(pollRef.current);
          setError('Your All Access subscription has expired. Choose a billing cycle and submit your new payment reference to renew.');
          setPaymentRef('');
          setState('form');
        } else if (data.status === 'suspended' || data.status === 'declined') {
          if (pollRef.current) clearInterval(pollRef.current);
          setError(data.status === 'suspended' ? 'This subscription is paused. Contact the administrator.' : 'The request was declined. Check the payment reference and contact the administrator before submitting again.');
          setState('form');
        }
      } catch { /* keep polling while the local service starts */ }
    }, 2200);
  }, [setAnnouncement, setCustomer, setPhase]);

  useEffect(() => {
    fetch('/api/activation/request', { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => setInfo((old) => ({ ...old, ...d })))
      .catch(() => undefined);
    const saved = typeof window !== 'undefined' ? localStorage.getItem('j53_phone') : null;
    if (saved) { setPhone(saved); setState('pending'); poll(saved); }
  }, [poll]);

  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current); }, []);

  async function requestAccess(e?: React.FormEvent) {
    e?.preventDefault();
    setError(null);
    if (paymentRef.trim().length < 4) { setError('Enter the UPI or bank transaction reference so the administrator can verify your payment.'); return; }
    try {
      const res = await fetch('/api/activation/request', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ phone, name, plan: 'all-access', billingCycle, paymentRef: paymentRef.trim() }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error ?? 'Subscription request failed.'); return; }
      if (data.status === 'active') {
        localStorage.setItem('j53_phone', phone);
        setCustomer({ phone, plan: data.plan ?? 'all-access', name: data.name ?? null });
        setState('granted'); setTimeout(() => setPhase('app'), 1100);
      } else { setState('pending'); poll(phone); }
    } catch { setError('Cannot reach the local JARVIS service. Make sure the launcher is running.'); }
  }

  const price = billingCycle === 'annual' ? (info.annualPrice ?? 5530) : (info.monthlyPrice ?? 553);
  const upiId = String(info.upiId ?? '').trim();
  const instructions = String(info.paymentInstructions ?? '').trim();

  return (
    <div className="relative z-10 flex min-h-screen items-center justify-center px-4 py-10">
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="w-full max-w-lg">
        <div className="mb-6 flex flex-col items-center gap-2">
          <img src="/j53-logo.svg" alt="J53 — JARVIS 53" className="h-28 w-28 drop-shadow-[0_0_30px_rgba(229,178,75,0.22)]" />
          <h1 className="j53-display mt-1 text-2xl font-bold tracking-[0.22em] text-[var(--j53-text)]">J53 <span className="text-[var(--j53-accent)]">ALL ACCESS</span></h1>
          <p className="j53-label">one plan · every capability · dynamic robotics</p>
        </div>
        <div className="j53-panel j53-glow p-6 sm:p-7">
          {state === 'form' && (
            <form onSubmit={requestAccess} className="space-y-4">
              <div className="rounded-xl border border-[rgba(var(--j53-gold-rgb),0.28)] bg-[rgba(var(--j53-gold-rgb),0.06)] p-4">
                <div className="flex items-center gap-2 text-[var(--j53-gold)]"><CreditCard className="h-4 w-4"/><p className="text-sm font-semibold">J53 All Access</p><span className="ml-auto rounded-full border border-[rgba(var(--j53-gold-rgb),0.35)] px-2 py-0.5 text-[9px] tracking-widest">ALL-IN-ONE</span></div>
                <div className="mt-2 flex items-baseline gap-1"><span className="j53-display text-3xl font-bold text-[var(--j53-text)]">{money(price)}</span><span className="text-xs text-[var(--j53-muted)]">/{billingCycle === 'monthly' ? 'month' : 'year'}</span></div>
                <p className="mt-1 text-xs leading-5 text-[var(--j53-muted)]">Includes voice controls, desktop automations, Productivity Studio and multi-provider AI routing. Annual billing is equivalent to ten monthly payments.</p>
              </div>
              <div className="grid grid-cols-2 gap-2 rounded-lg border border-[rgba(var(--j53-accent-rgb),0.18)] bg-[rgba(var(--j53-accent-rgb),0.04)] p-1" role="group" aria-label="Billing cycle">
                {(['monthly','annual'] as const).map((cycle) => <button key={cycle} type="button" onClick={() => setBillingCycle(cycle)} aria-pressed={billingCycle === cycle} className={`rounded-md py-2 text-xs font-semibold tracking-wider transition-colors ${billingCycle === cycle ? 'bg-[rgba(var(--j53-accent-rgb),0.18)] text-[var(--j53-accent)]' : 'text-[var(--j53-muted)] hover:text-[var(--j53-text)]'}`}>{cycle === 'monthly' ? 'MONTHLY · ₹553' : 'ANNUAL · ₹5,530'}</button>)}
              </div>
              <div><label className="j53-label mb-1.5 block" htmlFor="j53-name">Name (optional)</label><input id="j53-name" className="j53-input" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} /></div>
              <div><label className="j53-label mb-1.5 block" htmlFor="j53-phone">Phone number (international)</label><input id="j53-phone" className="j53-input" placeholder="+91 98765 43210" value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" autoComplete="tel" required /></div>
              <div className="rounded-lg border border-[rgba(var(--j53-accent-rgb),0.14)] p-3.5">
                <p className="j53-label mb-1.5">PAYMENT INSTRUCTIONS</p>
                <p className="text-xs leading-5 text-[var(--j53-muted)]">{instructions || 'Contact Dynamic Robotics for the official payment method before paying.'}</p>
                {upiId && <div className="mt-2 flex flex-wrap items-center gap-2"><span className="text-xs text-[var(--j53-muted)]">UPI ID</span><code className="rounded bg-black/30 px-2 py-1 text-xs text-[var(--j53-gold)]">{upiId}</code><button type="button" className="j53-btn !px-2 !py-1 !text-[9px]" onClick={async () => { try { await navigator.clipboard.writeText(upiId); setCopied(true); setTimeout(() => setCopied(false), 1300); } catch { setError('Clipboard access was blocked. Select and copy the UPI ID manually.'); } }}>{copied ? <Check className="h-3 w-3"/> : <Copy className="h-3 w-3"/>}{copied ? 'Copied' : 'Copy UPI'}</button></div>}
              </div>
              <div><label className="j53-label mb-1.5 block" htmlFor="j53-payment-ref">Payment transaction reference</label><input id="j53-payment-ref" className="j53-input" placeholder="UPI UTR / transaction ID" value={paymentRef} onChange={(e) => setPaymentRef(e.target.value.slice(0, 200))} required minLength={4} maxLength={200} autoComplete="off" /><p className="mt-1 text-[10px] leading-4 text-[var(--j53-muted)]">Submit only after paying. Your administrator verifies the reference manually. Do not enter card numbers, PINs or OTPs.</p></div>
              {error && <p role="alert" className="text-sm text-[var(--j53-red)]">{error}</p>}
              <button type="submit" className="j53-btn j53-glow w-full"><ShieldCheck className="h-4 w-4"/> Request All Access</button>
              <p className="text-center text-xs leading-5 text-[var(--j53-muted)]">Access unlocks after manual verification. Third-party AI providers may separately charge API usage.</p>
            </form>
          )}
          {state === 'pending' && <div className="flex flex-col items-center gap-5 py-8 text-center"><div className="relative h-20 w-20"><div className="j53-radar-ring absolute inset-0 rounded-full border border-[var(--j53-accent)]/50"/><div className="absolute inset-0 flex items-center justify-center"><div className="h-4 w-4 rounded-full bg-[var(--j53-accent)] shadow-[0_0_18px_rgba(var(--j53-accent-rgb),0.8)]"/></div></div><div><p className="j53-display text-sm tracking-[0.2em] text-[var(--j53-accent)]">PAYMENT REVIEW</p><p className="mt-2 text-sm leading-6 text-[var(--j53-muted)]">Your All Access request for <span className="text-[var(--j53-text)]">{phone}</span> is waiting for administrator verification. This screen refreshes automatically after approval.</p></div><button className="j53-btn" onClick={() => { if (pollRef.current) clearInterval(pollRef.current); setState('form'); }} type="button">Edit request</button></div>}
          {state === 'granted' && <div className="flex flex-col items-center gap-4 py-10 text-center"><motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', stiffness: 200 }}><p className="j53-display text-xl font-bold tracking-[0.3em] text-[var(--j53-green)]">ALL ACCESS GRANTED</p></motion.div><p className="text-sm text-[var(--j53-muted)]">Launching J53…</p></div>}
        </div>
        <p className="j53-label mt-6 text-center"><a href="https://dynamicrobotics53.com" target="_blank" rel="noreferrer" className="text-[var(--j53-accent)]/70 transition-colors hover:text-[var(--j53-accent)]">a product by dynamicrobotics53.com</a></p>
      </motion.div>
    </div>
  );
}
