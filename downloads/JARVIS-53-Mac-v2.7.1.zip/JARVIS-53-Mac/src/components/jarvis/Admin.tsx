'use client';

/**
 * JARVIS 53 — Master Admin Portal.
 * PIN-gated command center: dashboard, activation desk, AI support inbox,
 * multi-provider cloud AI key pool, broadcast channel, settings.
 */
import { useCallback, useEffect, useState } from 'react';
import {
  Activity, Ban, BarChart3, CheckCircle2, Download, KeyRound, Lock,
  LogOut, MailCheck, Megaphone, Pencil, Plus, RefreshCw, Send, Settings2, ShieldCheck,
  Sparkles, Trash2, Users, XCircle,
} from 'lucide-react';

/* ─────────────────────────── types ─────────────────────────── */
interface Customer {
  id: number;
  phone: string;
  name: string | null;
  plan: string;
  billingCycle: string;
  paymentRef: string | null;
  paymentStatus: string;
  subscriptionEndsAt: string | null;
  status: string;
  createdAt: string;
  approvedAt: string | null;
  lastSeenAt: string | null;
  notes: string | null;
}
interface Stats {
  totals: { customers: number; pending: number; active: number; declined: number; suspended: number; chats24h: number; toolsRun7d: number; openTickets: number };
  days: Array<{ label: string; chats: number; tools: number }>;
  topTools: Array<{ tool: string; count: number }>;
  recent: Array<{ kind: string; detail: string | null; phone: string | null; at: string }>;
  keyPool: { total: number; healthy: number };
  aiProvider: string;
}
interface AdminTicket {
  id: number;
  phone: string;
  subject: string;
  status: string;
  createdAt: string;
  replies: Array<{ id: number; author: string; body: string; createdAt: string }>;
}
interface PoolKeyView {
  id: string;
  provider: 'openrouter' | 'nvidia' | 'gemini';
  source: 'admin' | 'env';
  masked: string;
  addedAt: string;
  lastUsedAt: string | null;
  failures: number;
  calls: number;
  healthy: boolean;
}
interface AnnouncementRow {
  id: number;
  title: string;
  body: string;
  level: string;
  active: boolean;
  createdAt: string;
}

const STATUS_COLORS: Record<string, string> = {
  active: 'var(--j53-green)',
  pending: 'var(--j53-gold)',
  declined: 'var(--j53-red)',
  suspended: 'var(--j53-red)',
};

async function jfetch<T>(url: string, body?: unknown, method?: string): Promise<T> {
  const m = method ?? (body !== undefined ? 'POST' : 'GET');
  const res = await fetch(url, body !== undefined ? { method: m, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : { method: m, cache: 'no-store' });
  return (await res.json()) as T;
}

/* ─────────────────────────── PIN gate ─────────────────────────── */
function PinGate({ onOk }: { onOk: () => void }) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [hint, setHint] = useState(false);

  useEffect(() => {
    fetch('/api/activation/request', { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => setHint(Boolean(d.pinIsDefault)))
      .catch(() => undefined);
  }, []);

  async function login() {
    setError(null);
    const res = await fetch('/api/admin/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ pin }) });
    const data = await res.json();
    if (data.ok) onOk();
    else setError(data.error ?? 'Invalid PIN.');
  }

  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <div className="j53-panel j53-glow w-full max-w-sm p-7 text-center">
        <Lock className="mx-auto mb-4 h-8 w-8 text-[var(--j53-accent)]" />
        <h2 className="j53-display text-lg tracking-[0.2em] text-[var(--j53-text)]">MASTER ACCESS</h2>
        <p className="j53-label mt-1">admin command center</p>
        <input
          className="j53-input mt-5 text-center font-mono text-lg tracking-[0.5em]"
          placeholder="••••"
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 12))}
          onKeyDown={(e) => e.key === 'Enter' && login()}
          inputMode="numeric"
          autoFocus
          aria-label="Master PIN"
        />
        {error && <p className="mt-3 text-sm text-[var(--j53-red)]">{error}</p>}
        <button className="j53-btn mt-4 w-full" onClick={login} type="button">
          Authenticate
        </button>
        {hint && <p className="mt-3 text-[11px] leading-4 text-[var(--j53-muted)]">Admin is locked until a strong PIN is set in <span className="font-mono text-[var(--j53-gold)]">.env</span> (JARVIS_ADMIN_PIN).</p>}
      </div>
    </div>
  );
}

/* ─────────────────────────── Dashboard ─────────────────────────── */
function Dashboard({ stats }: { stats: Stats | null }) {
  if (!stats) return <p className="j53-label">loading telemetry…</p>;
  const maxVal = Math.max(1, ...stats.days.map((d) => d.chats + d.tools));
  const cards = [
    { label: 'Customers', value: stats.totals.customers, sub: `${stats.totals.active} active · ${stats.totals.pending} pending`, icon: <Users className="h-4 w-4" />, color: 'var(--j53-accent)' },
    { label: 'Membership', value: 'ALL ACCESS', sub: 'One plan · monthly or annual', icon: <ShieldCheck className="h-4 w-4" />, color: 'var(--j53-gold)' },
    { label: 'Chats (24h)', value: stats.totals.chats24h, sub: `${stats.totals.toolsRun7d} tools run this week`, icon: <Activity className="h-4 w-4" />, color: 'var(--j53-green)' },
    { label: 'Open Tickets', value: stats.totals.openTickets, sub: `${stats.keyPool.healthy}/${stats.keyPool.total} keys healthy`, icon: <MailCheck className="h-4 w-4" />, color: 'var(--j53-red)' },
  ];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="j53-panel p-4">
            <div className="flex items-center justify-between">
              <span className="j53-label">{c.label}</span>
              <span style={{ color: c.color }}>{c.icon}</span>
            </div>
            <p className="j53-display mt-2 text-2xl font-bold text-[var(--j53-text)]">{c.value}</p>
            <p className="mt-0.5 text-[11px] text-[var(--j53-muted)]">{c.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-3 lg:grid-cols-3">
        <div className="j53-panel p-4 lg:col-span-2">
          <p className="j53-label mb-4">activity — last 7 days</p>
          <div className="flex h-40 items-end gap-3">
            {stats.days.map((d) => (
              <div key={d.label} className="flex flex-1 flex-col items-center gap-1.5">
                <div className="flex h-32 w-full items-end justify-center gap-1">
                  <div className="j53-bar w-3" style={{ height: `${(d.chats / maxVal) * 100}%` }} title={`${d.chats} chats`} />
                  <div className="j53-bar j53-bar--gold w-3" style={{ height: `${(d.tools / maxVal) * 100}%` }} title={`${d.tools} tools`} />
                </div>
                <span className="j53-label" style={{ fontSize: 8 }}>
                  {d.label}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-2 flex gap-4">
            <span className="j53-label">
              <span className="mr-1 inline-block h-2 w-2 rounded-sm bg-[var(--j53-accent)]" /> chats
            </span>
            <span className="j53-label">
              <span className="mr-1 inline-block h-2 w-2 rounded-sm bg-[var(--j53-gold)]" /> tools
            </span>
          </div>
        </div>

        <div className="j53-panel p-4">
          <p className="j53-label mb-3">top automations</p>
          <div className="space-y-2">
            {stats.topTools.length === 0 && <p className="text-xs text-[var(--j53-muted)]">No tool runs yet.</p>}
            {stats.topTools.map((t) => (
              <div key={t.tool} className="flex items-center justify-between gap-2">
                <span className="truncate font-mono text-[11.5px] text-[var(--j53-accent)]">{t.tool?.split(' ')[0]}</span>
                <span className="font-mono text-[11px] text-[var(--j53-muted)]">×{t.count}</span>
              </div>
            ))}
          </div>
          <p className="j53-label mb-2 mt-5">latest events</p>
          <div className="j53-scroll max-h-32 space-y-1.5 overflow-y-auto pr-1">
            {stats.recent.slice(0, 8).map((r, i) => (
              <p key={i} className="truncate text-[11px] text-[var(--j53-muted)]">
                <span className="text-[var(--j53-accent)]/70">{r.kind}</span> · {r.detail ?? ''} · {new Date(r.at).toLocaleTimeString()}
              </p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────── Customers ─────────────────────────── */
function Customers() {
  const [rows, setRows] = useState<Customer[]>([]);
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<Customer | null>(null);

  const load = useCallback(async () => {
    const data = await jfetch<{ customers: Customer[] }>('/api/admin/customers');
    setRows(data.customers ?? []);
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  async function act(id: number, action: string) {
    await jfetch('/api/admin/customers', { id, action });
    void load();
  }
  async function saveEdit() {
    if (!editing) return;
    await jfetch('/api/admin/customers', {
      id: editing.id,
      action: 'update',
      notes: editing.notes ?? '',
      name: editing.name ?? '',
      paymentRef: editing.paymentRef ?? '',
      billingCycle: editing.billingCycle === 'annual' ? 'annual' : 'monthly',
    });
    setEditing(null);
    void load();
  }

  const filtered = rows.filter((r) => `${r.phone} ${r.name ?? ''} ${r.status} ${r.paymentRef ?? ''} ${r.billingCycle}`.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <input className="j53-input max-w-xs flex-1" placeholder="Search phone / name / status…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search customers" />
        <button className="j53-btn" onClick={() => void load()} type="button">
          <RefreshCw className="h-3.5 w-3.5" /> Refresh
        </button>
        <a className="j53-btn" href="/api/admin/export" download type="button">
          <Download className="h-3.5 w-3.5" /> Export CSV
        </a>
      </div>

      {editing && (
        <div className="j53-panel space-y-3 p-4">
          <p className="j53-label">editing {editing.phone}</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className="j53-label mb-1 block">Name</label><input className="j53-input" value={editing.name ?? ''} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
            <div><label className="j53-label mb-1 block">Billing cycle</label><select className="j53-input" value={editing.billingCycle === 'annual' ? 'annual' : 'monthly'} onChange={(e) => setEditing({ ...editing, billingCycle: e.target.value })}><option value="monthly">Monthly — ₹553</option><option value="annual">Annual — ₹5,530</option></select></div>
            <div><label className="j53-label mb-1 block">Payment reference (UPI / bank)</label><input className="j53-input font-mono" value={editing.paymentRef ?? ''} onChange={(e) => setEditing({ ...editing, paymentRef: e.target.value })} /></div>
            <div><label className="j53-label mb-1 block">Internal notes</label><input className="j53-input" value={editing.notes ?? ''} onChange={(e) => setEditing({ ...editing, notes: e.target.value })} /></div>
          </div>
          <div className="flex gap-2">
            <button className="j53-btn" onClick={saveEdit} type="button">
              Save changes
            </button>
            <button className="j53-btn" onClick={() => setEditing(null)} type="button">
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="j53-panel j53-scroll overflow-x-auto p-1">
        <table className="w-full min-w-[980px] text-left text-[13px]">
          <thead>
            <tr className="border-b border-[rgba(var(--j53-accent-rgb),0.12)]">
              {['Customer', 'Subscription', 'Billing cycle', 'Payment reference', 'Status / expiry', 'Joined', 'Last seen', 'Actions'].map((h) => (
                <th key={h} className="j53-label px-3 py-2.5">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-6 text-center text-[var(--j53-muted)]">
                  No customers yet — they appear here the moment someone requests access in the app.
                </td>
              </tr>
            )}
            {filtered.map((c) => (
              <tr key={c.id} className="border-b border-[rgba(var(--j53-accent-rgb),0.06)] transition-colors hover:bg-[rgba(var(--j53-accent-rgb),0.03)]">
                <td className="px-3 py-2.5">
                  <p className="font-mono text-[var(--j53-text)]">{c.phone}</p>
                  <p className="text-[11px] text-[var(--j53-muted)]">{c.name ?? '—'}</p>
                </td>
                <td className="px-3 py-2.5 text-[var(--j53-text-2)]">J53 All Access</td>
                <td className="px-3 py-2.5 text-[var(--j53-text-2)]">{c.billingCycle === 'annual' ? 'Annual · ₹5,530' : 'Monthly · ₹553'}</td>
                <td className="max-w-[190px] truncate px-3 py-2.5 font-mono text-[11px] text-[var(--j53-muted)]" title={c.paymentRef ?? ''}>{c.paymentRef ?? 'Awaiting reference'}</td>
                <td className="px-3 py-2.5">
                  <div className="space-y-1"><span className="j53-pill" style={{ fontSize: 8.5, color: STATUS_COLORS[c.status] ?? 'var(--j53-muted)' }}>{c.status.toUpperCase()}</span>{c.subscriptionEndsAt && <p className="text-[10px] text-[var(--j53-muted)]">until {new Date(c.subscriptionEndsAt).toLocaleDateString()}</p>}</div>
                </td>
                <td className="px-3 py-2.5 text-[11.5px] text-[var(--j53-muted)]">{new Date(c.createdAt).toLocaleDateString()}</td>
                <td className="px-3 py-2.5 text-[11.5px] text-[var(--j53-muted)]">{c.lastSeenAt ? new Date(c.lastSeenAt).toLocaleString() : '—'}</td>
                <td className="px-3 py-2.5">
                  <div className="flex flex-wrap gap-1.5">
                    {c.status !== 'active' && (
                      <button className="j53-btn" style={{ padding: '4px 9px', fontSize: 9 }} onClick={() => act(c.id, 'approve')} title="Approve access" type="button">
                        <CheckCircle2 className="h-3 w-3" /> Verify & Activate
                      </button>
                    )}
                    {c.status === 'pending' && (
                      <button className="j53-btn j53-btn--danger" style={{ padding: '4px 9px', fontSize: 9 }} onClick={() => act(c.id, 'decline')} type="button">
                        <XCircle className="h-3 w-3" /> Decline
                      </button>
                    )}
                    {c.status === 'active' && (
                      <button className="j53-btn j53-btn--danger" style={{ padding: '4px 9px', fontSize: 9 }} onClick={() => act(c.id, 'suspend')} title="Suspend access" type="button">
                        <Ban className="h-3 w-3" />
                      </button>
                    )}
                    {(c.status === 'suspended' || c.status === 'declined') && (
                      <button className="j53-btn" style={{ padding: '4px 9px', fontSize: 9 }} onClick={() => act(c.id, 'reactivate')} type="button">
                        Reactivate
                      </button>
                    )}
                    <button className="j53-btn" style={{ padding: '4px 9px', fontSize: 9 }} onClick={() => setEditing(c)} title="Edit customer details" type="button">
                      <Pencil className="h-3 w-3" />
                    </button>
                    <button className="j53-btn j53-btn--danger" style={{ padding: '4px 9px', fontSize: 9 }} onClick={() => act(c.id, 'delete')} title="Delete record" type="button">
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ─────────────────────────── Support inbox ─────────────────────────── */
function SupportInbox() {
  const [tickets, setTickets] = useState<AdminTicket[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [draft, setDraft] = useState('');
  const [drafting, setDrafting] = useState(false);
  const [reply, setReply] = useState('');

  const load = useCallback(async () => {
    const data = await jfetch<{ tickets: AdminTicket[] }>('/api/admin/tickets');
    setTickets(data.tickets ?? []);
    if (data.tickets?.length && selectedId === null) setSelectedId(data.tickets[0].id);
  }, [selectedId]);
  useEffect(() => {
    void load();
     
  }, []);

  const selected = tickets.find((t) => t.id === selectedId) ?? null;

  async function aiDraft() {
    if (!selected) return;
    setDrafting(true);
    const data = await jfetch<{ draft?: string; error?: string }>('/api/admin/draft-reply', { ticketId: selected.id });
    setDrafting(false);
    setDraft(data.draft ?? data.error ?? '');
  }
  async function sendReply(text: string) {
    if (!selected || !text.trim()) return;
    await jfetch('/api/admin/tickets', { action: 'reply', ticketId: selected.id, body: text });
    setDraft('');
    setReply('');
    void load();
  }

  return (
    <div className="grid gap-3 lg:grid-cols-[300px_1fr]">
      <div className="j53-panel j53-scroll max-h-[62vh] overflow-y-auto p-2">
        <p className="j53-label px-2 py-1.5">tickets ({tickets.length})</p>
        {tickets.length === 0 && <p className="px-2 py-4 text-xs text-[var(--j53-muted)]">No tickets. The concierge handles everything — tickets appear when a human is requested.</p>}
        {tickets.map((t) => (
          <button
            key={t.id}
            className={`mb-1 w-full rounded-lg px-3 py-2.5 text-left transition-colors ${selectedId === t.id ? 'bg-[rgba(var(--j53-accent-rgb),0.1)]' : 'hover:bg-[rgba(var(--j53-accent-rgb),0.05)]'}`}
            onClick={() => setSelectedId(t.id)}
            type="button"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="truncate text-[13px] text-[var(--j53-text)]">{t.subject}</span>
              <span className="j53-pill" style={{ fontSize: 7.5, color: t.status === 'closed' ? 'var(--j53-muted)' : t.status === 'waiting' ? 'var(--j53-green)' : 'var(--j53-gold)' }}>
                {t.status.toUpperCase()}
              </span>
            </div>
            <p className="mt-0.5 font-mono text-[11px] text-[var(--j53-muted)]">{t.phone}</p>
          </button>
        ))}
      </div>

      <div className="j53-panel flex min-h-[62vh] flex-col p-4">
        {!selected ? (
          <p className="m-auto text-sm text-[var(--j53-muted)]">Select a ticket.</p>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[rgba(var(--j53-accent-rgb),0.1)] pb-3">
              <div>
                <p className="text-[15px] font-semibold text-[var(--j53-text)]">{selected.subject}</p>
                <p className="font-mono text-[11.5px] text-[var(--j53-muted)]">
                  {selected.phone} · opened {new Date(selected.createdAt).toLocaleString()}
                </p>
              </div>
              <div className="flex gap-2">
                <button className="j53-btn" style={{ padding: '6px 12px' }} onClick={() => jfetch('/api/admin/tickets', { action: 'status', ticketId: selected.id, status: 'closed' }).then(load)} type="button">
                  Close
                </button>
                <button className="j53-btn" style={{ padding: '6px 12px' }} onClick={() => jfetch('/api/admin/tickets', { action: 'status', ticketId: selected.id, status: 'open' }).then(load)} type="button">
                  Reopen
                </button>
              </div>
            </div>

            <div className="j53-scroll min-h-0 flex-1 space-y-2.5 overflow-y-auto py-3">
              {selected.replies.map((r) => (
                <div key={r.id} className={`max-w-[85%] rounded-xl px-3.5 py-2.5 text-[13px] leading-5 whitespace-pre-wrap ${r.author === 'customer' ? 'border border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.03)] text-[var(--j53-text-2)]' : r.author === 'ai' ? 'border border-[rgba(var(--j53-green-rgb),0.2)] bg-[rgba(var(--j53-green-rgb),0.05)] text-[var(--j53-text-2)]' : 'border border-[rgba(var(--j53-accent-rgb),0.25)] bg-[rgba(var(--j53-accent-rgb),0.07)] text-[var(--j53-text)]'}`}>
                  <span className="j53-label mb-1 block" style={{ fontSize: 8 }}>
                    {r.author === 'customer' ? 'CUSTOMER' : r.author === 'ai' ? 'AI DRAFT/CONCIERGE' : 'ADMIN (YOU)'} · {new Date(r.createdAt).toLocaleString()}
                  </span>
                  {r.body}
                </div>
              ))}
            </div>

            <div className="space-y-2 border-t border-[rgba(var(--j53-accent-rgb),0.1)] pt-3">
              <button className="j53-btn" onClick={aiDraft} disabled={drafting} type="button">
                {drafting ? <span className="j53-spinner" /> : <Sparkles className="h-3.5 w-3.5" />} AI Draft Reply
              </button>
              {draft && (
                <div>
                  <label className="j53-label mb-1 block">AI draft — edit before sending</label>
                  <textarea className="j53-input min-h-[90px]" value={draft} onChange={(e) => setDraft(e.target.value)} />
                  <button className="j53-btn j53-btn--gold mt-2" onClick={() => sendReply(draft)} type="button">
                    <Send className="h-3.5 w-3.5" /> Send draft to customer
                  </button>
                </div>
              )}
              <div className="flex gap-2">
                <input className="j53-input flex-1" placeholder="Write a custom reply…" value={reply} onChange={(e) => setReply(e.target.value)} aria-label="Custom reply" />
                <button className="j53-btn" onClick={() => sendReply(reply)} disabled={!reply.trim()} type="button">
                  <Send className="h-3.5 w-3.5" /> Send
                </button>
              </div>
              <p className="text-[11px] text-[var(--j53-muted)]">Replies appear instantly in the customer&apos;s Support → My tickets panel.</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ─────────────────────────── Key pool ─────────────────────────── */
function KeyPool() {
  const [keys, setKeys] = useState<PoolKeyView[]>([]);
  const [provider, setProvider] = useState<'openrouter' | 'nvidia' | 'gemini'>('openrouter');
  const [newKey, setNewKey] = useState('');
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const data = await jfetch<{ keys: PoolKeyView[] }>('/api/admin/keys');
    setKeys(data.keys ?? []);
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="max-w-3xl space-y-4">
      <div className="j53-panel p-5">
        <div className="flex items-center gap-2">
          <KeyRound className="h-4 w-4 text-[var(--j53-gold)]" />
          <p className="j53-display text-[13px] tracking-[0.16em] text-[var(--j53-text)]">MULTI-PROVIDER CLOUD AI KEY POOL</p>
        </div>
        <p className="mt-2 text-[13px] leading-5 text-[var(--j53-muted)]">
          Add keys from OpenRouter, NVIDIA NIM, and Google Gemini. JARVIS rotates across configured providers and keys, and retries another route after errors or rate limits. Generative requests never fall back to the local answer brain; exact computer commands can still run locally. Raw keys never appear in the key list; identifiers are opaque and all secret values remain hidden.
        </p>
        <div className="mt-4 grid gap-2 sm:grid-cols-[180px_1fr_auto]">
          <select
            className="j53-input"
            value={provider}
            onChange={(e) => setProvider(e.target.value as 'openrouter' | 'nvidia' | 'gemini')}
            aria-label="API key provider"
          >
            <option value="openrouter">OpenRouter</option>
            <option value="nvidia">NVIDIA NIM</option>
            <option value="gemini">Google Gemini</option>
          </select>
          <input
            className="j53-input min-w-0 font-mono"
            placeholder={provider === 'openrouter' ? 'OpenRouter API key…' : provider === 'nvidia' ? 'NVIDIA API key…' : 'Gemini API key…'}
            value={newKey}
            onChange={(e) => setNewKey(e.target.value)}
            aria-label={`New ${provider} API key`}
            type="password"
            autoComplete="off"
          />
          <button
            className="j53-btn"
            onClick={async () => {
              setError(null);
              const data = await jfetch<{ ok?: boolean; error?: string }>('/api/admin/keys', { action: 'add', provider, key: newKey });
              if (data.error) setError(data.error);
              else setNewKey('');
              void load();
            }}
            type="button"
          >
            <Plus className="h-3.5 w-3.5" /> Add key
          </button>
        </div>
        {error && <p className="mt-2 text-sm text-[var(--j53-red)]">{error}</p>}
        <div className="mt-4 space-y-2">
          {keys.length === 0 && <p className="text-xs text-[var(--j53-muted)]">No cloud API keys configured. Add an OpenRouter, NVIDIA NIM, or Gemini key to enable AI answers. JARVIS will never replace a failed AI answer with the local answer brain.</p>}
          {keys.map((k) => (
            <div key={`${k.provider}:${k.source}:${k.id}`} className="flex items-center justify-between gap-3 rounded-lg border border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.55)] px-3.5 py-2.5">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="truncate font-mono text-[12.5px] text-[var(--j53-text)]">{k.masked}</p>
                  <span className="j53-pill" style={{ fontSize: 8 }}>{k.provider === 'nvidia' ? 'NVIDIA NIM' : k.provider === 'gemini' ? 'GOOGLE GEMINI' : 'OPENROUTER'}</span>
                  {k.source === 'env' && <span className="j53-pill" style={{ fontSize: 8 }}>ENV</span>}
                </div>
                <p className="text-[11px] text-[var(--j53-muted)]">
                  {k.calls} calls · {k.failures} failures · {k.lastUsedAt ? `last used ${new Date(k.lastUsedAt).toLocaleTimeString()}` : 'not used yet'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="j53-pill" style={{ fontSize: 8, color: k.healthy ? 'var(--j53-green)' : 'var(--j53-red)' }}>
                  {k.healthy ? 'AVAILABLE' : 'COOLDOWN'}
                </span>
                <button
                  className="j53-btn j53-btn--danger"
                  style={{ padding: '4px 9px' }}
                  onClick={async () => {
                    const data = await jfetch<{ error?: string }>('/api/admin/keys', { action: 'remove', provider: k.provider, keyId: k.id });
                    if (data.error) setError(data.error);
                    void load();
                  }}
                  disabled={k.source === 'env'}
                  title={k.source === 'env' ? 'Remove this key from the .env file to disable it' : 'Remove this stored API key'}
                  type="button"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────── Broadcast ─────────────────────────── */
function Broadcast() {
  const [rows, setRows] = useState<AnnouncementRow[]>([]);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [level, setLevel] = useState('info');

  const load = useCallback(async () => {
    const data = await jfetch<{ announcements: AnnouncementRow[] }>('/api/admin/announcements');
    setRows(data.announcements ?? []);
  }, []);
  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="max-w-3xl space-y-4">
      <div className="j53-panel p-5">
        <div className="flex items-center gap-2">
          <Megaphone className="h-4 w-4 text-[var(--j53-accent)]" />
          <p className="j53-display text-[13px] tracking-[0.16em] text-[var(--j53-text)]">BROADCAST TO EVERY HUD</p>
        </div>
        <p className="mt-2 text-[13px] text-[var(--j53-muted)]">Pushes a live banner into all customer consoles (maintenance notes, new features, holiday hours…).</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_160px]">
          <input className="j53-input" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} aria-label="Announcement title" />
          <select className="j53-input" value={level} onChange={(e) => setLevel(e.target.value)} aria-label="Announcement level">
            <option value="info">Info</option>
            <option value="success">Success</option>
            <option value="warning">Warning</option>
          </select>
          <textarea className="j53-input sm:col-span-2" placeholder="Message body…" value={body} onChange={(e) => setBody(e.target.value)} aria-label="Announcement body" />
        </div>
        <button
          className="j53-btn mt-3"
          onClick={async () => {
            if (!title.trim() || !body.trim()) return;
            await jfetch('/api/admin/announcements', { title, body, level });
            setTitle('');
            setBody('');
            void load();
          }}
          type="button"
        >
          <Send className="h-3.5 w-3.5" /> Publish broadcast
        </button>
      </div>

      <div className="space-y-2">
        {rows.map((a) => (
          <div key={a.id} className="j53-panel flex items-start justify-between gap-3 p-4">
            <div>
              <p className="text-[14px] font-semibold text-[var(--j53-text)]">{a.title}</p>
              <p className="mt-1 text-[13px] text-[var(--j53-text-2)]">{a.body}</p>
              <p className="j53-label mt-1.5" style={{ fontSize: 8 }}>
                {a.level.toUpperCase()} · {new Date(a.createdAt).toLocaleString()}
              </p>
            </div>
            <button
              className="j53-btn j53-btn--danger"
              style={{ padding: '5px 10px' }}
              onClick={async () => {
                await fetch(`/api/admin/announcements?id=${a.id}`, { method: 'DELETE' });
                void load();
              }}
              type="button"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─────────────────────────── Settings ─────────────────────────── */
function SettingsTab() {
  const [pinIsDefault, setPinIsDefault] = useState(true);
  const [newPin, setNewPin] = useState('');
  const [paymentUpiId, setPaymentUpiId] = useState('');
  const [paymentInstructions, setPaymentInstructions] = useState('Contact Dynamic Robotics for official payment instructions before paying.');
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    jfetch<{ pinIsDefault: boolean; paymentUpiId?: string; paymentInstructions?: string }>('/api/admin/settings', undefined, 'GET').then((d) => {
      setPinIsDefault(Boolean(d.pinIsDefault));
      setPaymentUpiId(d.paymentUpiId ?? '');
      setPaymentInstructions(d.paymentInstructions ?? 'Contact Dynamic Robotics for official payment instructions before paying.');
    }).catch(() => undefined);
  }, []);

  return (
    <div className="max-w-3xl space-y-4">
      <div className="j53-panel p-5">
        <p className="j53-display text-[13px] tracking-[0.16em] text-[var(--j53-text)]">SECURITY</p>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <input className="j53-input max-w-[200px] font-mono tracking-[0.3em]" placeholder="New PIN (6–12 digits)" value={newPin} onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 8))} aria-label="New master PIN" />
          <button className="j53-btn" onClick={async () => { const data = await jfetch<{ ok?: boolean; error?: string; message?: string }>('/api/admin/settings', { action: 'setPin', pin: newPin }); setMsg(data.message ?? data.error ?? null); if (data.ok) { setNewPin(''); setPinIsDefault(false); } }} type="button"><ShieldCheck className="h-3.5 w-3.5" /> Update master PIN</button>
          {pinIsDefault && <span className="j53-pill j53-pill--warn" style={{ fontSize: 8 }}>WEAK PIN — SET A STRONG ONE</span>}
        </div>
        {msg && <p className="mt-2 text-sm text-[var(--j53-green)]" role="status">{msg}</p>}
      </div>

      <div className="j53-panel space-y-4 p-5">
        <div><p className="j53-display text-[13px] tracking-[0.16em] text-[var(--j53-text)]">J53 ALL ACCESS · PAYMENT DETAILS</p><p className="mt-1 text-xs leading-5 text-[var(--j53-muted)]">Customers see these details before submitting their payment reference. Keep them accurate. The app does not automatically charge cards or verify transfers; check the actual payment account before using Verify & Activate.</p></div>
        <div><label className="j53-label mb-1.5 block" htmlFor="j53-upi">Receiving UPI ID (optional)</label><input id="j53-upi" className="j53-input" value={paymentUpiId} onChange={(e) => setPaymentUpiId(e.target.value.slice(0, 120))} placeholder="your-business@bank" autoComplete="off" /></div>
        <div><label className="j53-label mb-1.5 block" htmlFor="j53-payment-instructions">Payment instructions</label><textarea id="j53-payment-instructions" className="j53-input min-h-24 resize-y" value={paymentInstructions} onChange={(e) => setPaymentInstructions(e.target.value.slice(0, 700))} maxLength={700} placeholder="State the approved payment method and what reference the customer should enter." /></div>
        <button className="j53-btn j53-btn--gold" onClick={async () => { const data = await jfetch<{ ok?: boolean; error?: string }>('/api/admin/settings', { action: 'setPaymentDetails', paymentUpiId, paymentInstructions }); setMsg(data.ok ? 'Payment details saved.' : data.error ?? 'Could not save payment details.'); }} type="button"><ShieldCheck className="h-3.5 w-3.5"/> Save payment details</button>
      </div>

      <div className="j53-panel p-5">
        <p className="j53-display text-[13px] tracking-[0.16em] text-[var(--j53-text)]">DEPLOYMENT NOTES</p>
        <ul className="mt-3 list-disc space-y-1.5 pl-5 text-[13px] leading-5 text-[var(--j53-muted)]">
          <li>Add OpenRouter, NVIDIA NIM, or Google Gemini keys in AI Keys. Generative requests use cloud providers only; exact computer commands remain local.</li>
          <li>There is one paid membership: J53 All Access, ₹553 monthly or ₹5,530 annually. Review every payment reference in your actual payment account before activating.</li>
          <li>Customer records, key pool, and approval actions live in this installation&apos;s local database. A separate hosted activation backend is required to administer subscriptions across remote customer installations.</li>
          <li>Change the factory admin PIN and never expose the loopback-bound local server to the public internet.</li>
        </ul>
      </div>
    </div>
  );
}

/* ─────────────────────────── Admin shell ─────────────────────────── */
export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState<'dashboard' | 'customers' | 'support' | 'keys' | 'broadcast' | 'settings'>('dashboard');
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    if (authed && tab === 'dashboard') {
      jfetch<Stats>('/api/admin/stats', undefined, 'GET').then(setStats).catch(() => undefined);
    }
  }, [authed, tab]);

  const TABS = [
    ['dashboard', 'Dashboard', <BarChart3 key="1" className="h-3.5 w-3.5" />],
    ['customers', 'Customers', <Users key="2" className="h-3.5 w-3.5" />],
    ['support', 'Support Inbox', <MailCheck key="3" className="h-3.5 w-3.5" />],
    ['keys', 'Key Pool', <KeyRound key="4" className="h-3.5 w-3.5" />],
    ['broadcast', 'Broadcast', <Megaphone key="5" className="h-3.5 w-3.5" />],
    ['settings', 'Settings', <Settings2 key="6" className="h-3.5 w-3.5" />],
  ] as const;

  if (!authed) return <PinGate onOk={() => setAuthed(true)} />;

  return (
    <div className="mx-auto w-full max-w-6xl">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1.5">
          {TABS.map(([id, label, icon]) => (
            <button key={id} className={`j53-btn ${tab === id ? 'j53-glow' : ''}`} style={{ padding: '7px 12px' }} onClick={() => setTab(id)} type="button">
              {icon} {label}
            </button>
          ))}
        </div>
        <button
          className="j53-btn"
          onClick={async () => {
            await fetch('/api/admin/logout', { method: 'POST' });
            setAuthed(false);
          }}
          type="button"
        >
          <LogOut className="h-3.5 w-3.5" /> Lock portal
        </button>
      </div>

      {tab === 'dashboard' && <Dashboard stats={stats} />}
      {tab === 'customers' && <Customers />}
      {tab === 'support' && <SupportInbox />}
      {tab === 'keys' && <KeyPool />}
      {tab === 'broadcast' && <Broadcast />}
      {tab === 'settings' && <SettingsTab />}
    </div>
  );
}
