'use client';

/**
 * JARVIS 53 — Arc Reactor.
 * Canvas-rendered, GPU-friendly, reacts to orb mode and live mic level.
 * idle → slow accent breathing · listening → level-driven pulse · thinking → gold
 * acceleration · speaking → green waveform rings.
 *
 * Canvas cannot parse CSS `var()` colors — theme colors are resolved through
 * getComputedStyle and refreshed periodically so theme/accent changes apply live.
 */
import { useEffect, useRef } from 'react';
import { useJarvis } from './store';

interface Palette {
  accent: string;
  accentSoft: string; // "rgba(r,g,b,"
  gold: string;
  green: string;
}

function readPalette(): Palette {
  if (typeof window === 'undefined') {
    return { accent: '#e5b24b', accentSoft: 'rgba(229,178,75,', gold: '#ffc857', green: '#3af0b6' };
  }
  const cs = getComputedStyle(document.documentElement);
  const pick = (name: string, fallback: string) => (cs.getPropertyValue(name) || '').trim() || fallback;
  const triplet = (name: string, fallback: string) => {
    const v = pick(name, fallback);
    return /^\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*$/.test(v) ? v.replace(/\s/g, '') : fallback;
  };
  const accentRgb = triplet('--j53-accent-rgb', '229,178,75');
  return {
    accent: pick('--j53-accent', '#e5b24b'),
    accentSoft: `rgba(${accentRgb},`,
    gold: pick('--j53-gold', '#ffc857'),
    green: pick('--j53-green', '#3af0b6'),
  };
}

export default function ArcReactor({ size = 220 }: { size?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const orbMode = useJarvis((s) => s.orbMode);
  const micLevel = useJarvis((s) => s.micLevel);
  const stateRef = useRef({ mode: orbMode, level: micLevel, t: 0 });

  useEffect(() => {
    stateRef.current.mode = orbMode;
  }, [orbMode]);
  useEffect(() => {
    stateRef.current.level = micLevel;
  }, [micLevel]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(2, typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1);
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    ctx.scale(dpr, dpr);

    const cx = size / 2;
    const cy = size / 2;
    let raf = 0;
    let palette = readPalette();
    let paletteAt = 0;

    const draw = (time: number) => {
      // Refresh resolved theme colors ~2×/second (cheap; reacts to theme/accent changes).
      if (time - paletteAt > 500) {
        palette = readPalette();
        paletteAt = time;
      }
      const s = stateRef.current;
      const t = time / 1000;
      const mode = s.mode;
      const main = mode === 'thinking' ? palette.gold : mode === 'speaking' ? palette.green : mode === 'listening' ? '#4DF3FF' : palette.accent;
      const soft = mode === 'thinking' ? `rgba(255,200,87,` : mode === 'speaking' ? `rgba(58,240,182,` : mode === 'listening' ? 'rgba(77,243,255,' : palette.accentSoft;
      const level = mode === 'listening' ? Math.min(1, s.level * 1.6) : 0;
      const pulse = mode === 'idle' ? (Math.sin(t * 1.4) + 1) / 2 : mode === 'thinking' ? (Math.sin(t * 7) + 1) / 2 : 0.65 + level * 0.35;

      ctx.clearRect(0, 0, size, size);

      /* outer glow halo */
      const halo = ctx.createRadialGradient(cx, cy, size * 0.1, cx, cy, size * 0.52);
      halo.addColorStop(0, `${soft}${0.16 + pulse * 0.12})`);
      halo.addColorStop(1, `${soft}0)`);
      ctx.fillStyle = halo;
      ctx.beginPath();
      ctx.arc(cx, cy, size * 0.52, 0, Math.PI * 2);
      ctx.fill();

      /* rotating dashed ring (outer) */
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(t * 0.35);
      ctx.strokeStyle = `${soft}0.5)`;
      ctx.lineWidth = 1.4;
      ctx.setLineDash([2, 9]);
      ctx.beginPath();
      ctx.arc(0, 0, size * 0.44, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      /* counter-rotating tick ring */
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-t * 0.6);
      for (let i = 0; i < 60; i++) {
        const a = (i / 60) * Math.PI * 2;
        const len = i % 5 === 0 ? 7 : 3;
        ctx.strokeStyle = `${soft}${i % 5 === 0 ? 0.75 : 0.3})`;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * size * 0.38, Math.sin(a) * size * 0.38);
        ctx.lineTo(Math.cos(a) * (size * 0.38 - len), Math.sin(a) * (size * 0.38 - len));
        ctx.stroke();
      }
      ctx.restore();

      /* orbiting nodes */
      ctx.save();
      ctx.translate(cx, cy);
      for (let i = 0; i < 8; i++) {
        const a = t * 0.8 + (i / 8) * Math.PI * 2;
        const r = size * 0.34 + Math.sin(t * 2 + i) * 3;
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        ctx.fillStyle = i % 4 === 0 ? palette.gold : main;
        ctx.shadowColor = main;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(x, y, i % 4 === 0 ? 2.6 : 1.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
      ctx.restore();

      /* inner triangle ring */
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(t * 0.25);
      ctx.strokeStyle = `${soft}0.6)`;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (let i = 0; i <= 3; i++) {
        const a = (i / 3) * Math.PI * 2 - Math.PI / 2;
        const r = size * 0.21 + (mode === 'listening' ? level * 4 : 0);
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.stroke();
      ctx.restore();

      /* level ring (listening) */
      if (mode === 'listening') {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.arc(0, 0, size * 0.27, -Math.PI / 2, -Math.PI / 2 + level * Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      /* core */
      const coreR = size * (0.11 + pulse * 0.02 + level * 0.05);
      const core = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreR * 2.4);
      core.addColorStop(0, '#FFFFFF');
      core.addColorStop(0.28, main);
      core.addColorStop(1, `${soft}0)`);
      ctx.fillStyle = core;
      ctx.beginPath();
      ctx.arc(cx, cy, coreR * 2.4, 0, Math.PI * 2);
      ctx.fill();

      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [size]);

  return (
    <canvas
      ref={canvasRef}
      style={{ width: size, height: size }}
      aria-label={`JARVIS core — ${orbMode}`}
      role="img"
    />
  );
}
