'use client';

/**
 * JARVIS 53 — ⌘K command palette.
 * Full tool registry search, guided argument forms, risk-aware execution.
 */
import { useEffect, useMemo, useState } from 'react';
import { useJarvis } from './store';
import { TOOLS, type ToolDef } from '@/lib/tools/registry';
import { Search, ShieldAlert, Zap } from 'lucide-react';

function riskColor(risk: string): string {
  return risk === 'high' ? 'var(--j53-red)' : risk === 'medium' ? 'var(--j53-gold)' : 'var(--j53-green)';
}

export default function CommandBar() {
  const open = useJarvis((s) => s.cmdOpen);
  const setOpen = useJarvis((s) => s.setCmdOpen);
  const executeQuick = useJarvis((s) => s.executeQuick);
  const send = useJarvis((s) => s.send);
  const busy = useJarvis((s) => s.busy);

  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<ToolDef | null>(null);
  const [args, setArgs] = useState<Record<string, string>>({});
  const [result, setResult] = useState<string | null>(null);
  const [running, setRunning] = useState(false);

  const platform = useJarvis((s) => s.health?.platform);
  const isMac = platform === 'mac';
  const isWin = platform === 'win';

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen(!open);
      }
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', down);
    return () => window.removeEventListener('keydown', down);
  }, [open, setOpen]);

  useEffect(() => {
    if (open) {
      setQuery('');
      setSelected(null);
      setResult(null);
      setArgs({});
    }
  }, [open]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = TOOLS.filter((t) => (isMac || isWin ? true : true));
    if (!q) return base.slice(0, 12);
    return base.filter((t) => `${t.id} ${t.name} ${t.desc} ${t.category}`.toLowerCase().includes(q)).slice(0, 14);
  }, [query, isMac, isWin]);

  async function run(def: ToolDef, cleanedArgs: Record<string, unknown>, confirmed: boolean) {
    setRunning(true);
    const res = await executeQuick(def.id, cleanedArgs, confirmed);
    setRunning(false);
    if (res) {
      if (res.status === 'confirm_required') {
        setResult('This action needs confirmation — approve it in the console tool card, or run it through JARVIS.');
        return;
      }
      setResult(res.output || `${res.label}: ${res.status}`);
      if (res.status === 'done') {
        setTimeout(() => setOpen(false), 1600);
      }
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-[rgba(var(--j53-bg-rgb),0.82)] px-4 pt-[12vh] backdrop-blur-sm" onClick={() => setOpen(false)}>
      <div className="j53-panel j53-glow w-full max-w-xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        {!selected ? (
          <>
            <div className="flex items-center gap-3 border-b border-[rgba(var(--j53-accent-rgb),0.12)] px-4 py-3.5">
              <Search className="h-4 w-4 text-[var(--j53-accent)]" />
              <input
                autoFocus
                className="w-full bg-transparent font-mono text-[14px] text-[var(--j53-text)] outline-none placeholder:text-[var(--j53-muted)]"
                placeholder="Search 65 automations — apps, files, media, system…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && filtered[0]) {
                    const def = filtered[0];
                    const required = def.args.filter((a) => a.required);
                    if (required.length) setSelected(def);
                    else run(def, {}, def.risk !== 'low');
                  }
                }}
                aria-label="Search automations"
              />
              <span className="j53-pill" style={{ fontSize: 8 }}>
                ESC
              </span>
            </div>
            <div className="j53-scroll max-h-[46vh] overflow-y-auto p-2">
              {result && <p className="mb-2 whitespace-pre-wrap rounded-md border border-[rgba(var(--j53-accent-rgb),0.2)] bg-[rgba(var(--j53-accent-rgb),0.05)] p-3 text-[12.5px] text-[var(--j53-text-2)]">{result}</p>}
              {filtered.map((t) => {
                const unavailable = platform && !t.os.includes(platform as 'mac' | 'win');
                return (
                  <button
                    key={t.id}
                    className="group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors hover:bg-[rgba(var(--j53-accent-rgb),0.06)]"
                    onClick={() => {
                      const required = t.args.filter((a) => a.required);
                      if (required.length) setSelected(t);
                      else run(t, {}, t.risk !== 'low');
                    }}
                    disabled={busy || running}
                    type="button"
                  >
                    <Zap className="h-3.5 w-3.5 shrink-0 text-[var(--j53-accent)]" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-mono text-[12.5px] text-[var(--j53-text)]">{t.id}</span>
                      <span className="block truncate text-[12px] text-[var(--j53-muted)]">
                        {t.name} — {t.desc}
                      </span>
                    </span>
                    {unavailable && (
                      <span className="j53-pill" style={{ fontSize: 8 }}>
                        OTHER OS
                      </span>
                    )}
                    <span className="j53-pill" style={{ fontSize: 8, color: riskColor(t.risk) }}>
                      {t.risk.toUpperCase()}
                    </span>
                  </button>
                );
              })}
              {filtered.length === 0 && <p className="p-4 text-center text-sm text-[var(--j53-muted)]">No automation matches &ldquo;{query}&rdquo;. Try plain English in the console — the AI understands intent.</p>}
            </div>
          </>
        ) : (
          <div className="p-5">
            <div className="mb-3 flex items-center gap-2">
              <span className="font-mono text-[13px] text-[var(--j53-accent)]">{selected.id}</span>
              <span className="j53-pill" style={{ fontSize: 8, color: riskColor(selected.risk) }}>
                {selected.risk.toUpperCase()} RISK
              </span>
            </div>
            <p className="mb-4 text-[13px] text-[var(--j53-muted)]">{selected.desc}</p>
            {selected.risk !== 'low' && (
              <p className="mb-3 flex items-start gap-2 rounded-md border border-[rgba(var(--j53-gold-rgb),0.3)] bg-[rgba(var(--j53-gold-rgb),0.06)] p-2.5 text-[12px] leading-5 text-[var(--j53-gold)]">
                <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {selected.risk === 'high' ? 'High-risk automation — it will run immediately on approval.' : 'This modifies your system — confirm to proceed.'}
              </p>
            )}
            <div className="space-y-3">
              {selected.args.map((a) => (
                <div key={a.name}>
                  <label className="j53-label mb-1 block" htmlFor={`cb-${a.name}`}>
                    {a.name} {a.required ? '' : '(optional)'} — {a.desc}
                  </label>
                  <input
                    id={`cb-${a.name}`}
                    className="j53-input"
                    placeholder={a.example ?? ''}
                    value={args[a.name] ?? ''}
                    onChange={(e) => setArgs((prev) => ({ ...prev, [a.name]: e.target.value }))}
                    autoFocus={a.required}
                  />
                </div>
              ))}
            </div>
            {result && <p className="j53-scroll mt-3 max-h-32 overflow-y-auto whitespace-pre-wrap rounded-md border border-[rgba(var(--j53-accent-rgb),0.2)] bg-[rgba(var(--j53-accent-rgb),0.05)] p-3 text-[12.5px] text-[var(--j53-text-2)]">{result}</p>}
            <div className="mt-4 flex gap-2">
              <button
                className="j53-btn flex-1"
                disabled={running}
                onClick={() => {
                  const cleaned: Record<string, unknown> = {};
                  for (const a of selected.args) {
                    if (args[a.name] !== undefined && args[a.name] !== '') {
                      cleaned[a.name] = a.type === 'number' ? Number(args[a.name]) : a.type === 'boolean' ? args[a.name] === 'true' : args[a.name];
                    }
                  }
                  run(selected, cleaned, selected.risk !== 'low');
                }}
                type="button"
              >
                {running ? <span className="j53-spinner" /> : <ShieldAlert className="h-3.5 w-3.5" />} {selected.risk === 'low' ? 'Execute' : 'Approve & Execute'}
              </button>
              <button className="j53-btn" onClick={() => setSelected(null)} type="button">
                Back
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
