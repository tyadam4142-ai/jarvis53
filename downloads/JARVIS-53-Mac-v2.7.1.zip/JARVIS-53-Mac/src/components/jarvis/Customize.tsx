'use client';

/**
 * JARVIS 53 — Appearance Lab (Customize drawer).
 * Full live theming: 6 palettes, custom accent, glow level, fonts,
 * density and HUD effects. Everything persists to localStorage and
 * applies to <html> instantly via the store's appearance engine.
 */
import { useEffect } from 'react';
import { useJarvis, type ThemeId, type GlowLevel, type FontMode, type Density } from './store';
import { Check, Palette, RotateCcw, X } from 'lucide-react';

const THEMES: Array<{ id: ThemeId; name: string; sub: string; bg: string; accent: string; accent2: string }> = [
  { id: 'midnight', name: 'Arc Midnight', sub: 'signature cyan', bg: '#04070f', accent: '#00e5ff', accent2: '#ffc857' },
  { id: 'mark42', name: 'Mark XLII', sub: 'hot-rod gold', bg: '#0b0804', accent: '#ffc857', accent2: '#ff6d3b' },
  { id: 'matrix', name: 'Emerald Code', sub: 'green terminal', bg: '#010503', accent: '#3af0b6', accent2: '#baffd9' },
  { id: 'violet', name: 'Neon Violet', sub: 'deep plasma', bg: '#070511', accent: '#b388ff', accent2: '#ff7ad9' },
  { id: 'solar', name: 'Solar Flare', sub: 'reactor amber', bg: '#0c0702', accent: '#ffb347', accent2: '#ff6d3b' },
  { id: 'titanium', name: 'Titanium Day', sub: 'light alloy', bg: '#e9edf3', accent: '#0079a8', accent2: '#a9720e' },
];

const ACCENTS = ['#00e5ff', '#ffc857', '#3af0b6', '#b388ff', '#ff3b5c', '#ff8a3d', '#ff7ad9', '#7ad9ff'];
const GLOWS: GlowLevel[] = ['off', 'subtle', 'standard', 'extreme'];
const FONTS: Array<{ id: FontMode; label: string }> = [
  { id: 'orbitron', label: 'Orbitron' },
  { id: 'mono', label: 'Terminal' },
  { id: 'sleek', label: 'Sleek' },
];
const DENSITIES: Array<{ id: Density; label: string }> = [
  { id: 'comfortable', label: 'Comfortable' },
  { id: 'compact', label: 'Compact' },
];

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6">
      <p className="j53-label mb-2.5">{title}</p>
      {children}
    </section>
  );
}

function Seg<T extends string>({ options, value, onChange }: { options: Array<{ id: T; label: string }>; value: T; onChange: (v: T) => void }) {
  return (
    <div className="j53-seg">
      {options.map((o) => (
        <button key={o.id} className={value === o.id ? 'active' : ''} onClick={() => onChange(o.id)} type="button" aria-pressed={value === o.id}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

function ToggleRow({ label, hint, on, onToggle }: { label: string; hint: string; on: boolean; onToggle: () => void }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-[rgba(var(--j53-accent-rgb),0.14)] bg-[rgba(var(--j53-bg-rgb),0.5)] px-3 py-2.5">
      <div>
        <p className="text-[13px] font-semibold text-[var(--j53-text)]">{label}</p>
        <p className="text-[11px] text-[var(--j53-muted)]">{hint}</p>
      </div>
      <button
        className={`j53-btn ${on ? 'j53-glow' : ''}`}
        style={{ padding: '6px 12px', fontSize: 10 }}
        onClick={onToggle}
        aria-pressed={on}
        type="button"
      >
        {on ? 'ON' : 'OFF'}
      </button>
    </div>
  );
}

export default function Customize() {
  const open = useJarvis((s) => s.customizeOpen);
  const setOpen = useJarvis((s) => s.setCustomizeOpen);
  const appearance = useJarvis((s) => s.appearance);
  const setAppearance = useJarvis((s) => s.setAppearance);
  const resetAppearance = useJarvis((s) => s.resetAppearance);

  // Escape closes the lab — standard drawer behavior.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, setOpen]);

  return (
    <>
      {/* scrim */}
      <div
        className={`fixed inset-0 z-50 bg-[rgba(var(--j53-bg-rgb),0.7)] backdrop-blur-[2px] transition-opacity duration-300 ${open ? 'opacity-100' : 'pointer-events-none opacity-0'}`}
        onClick={() => setOpen(false)}
        aria-hidden="true"
      />
      <aside className={`j53-drawer ${open ? 'open' : ''}`} aria-hidden={!open} aria-label="Appearance lab">
        <div className="j53-scroll flex h-full flex-col overflow-y-auto p-5">
          <div className="mb-5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Palette className="h-4.5 w-4.5 text-[var(--j53-accent)]" style={{ width: 18, height: 18 }} />
              <div>
                <p className="j53-display text-[13px] font-bold tracking-[0.18em] text-[var(--j53-text)]">APPEARANCE LAB</p>
                <p className="j53-label" style={{ fontSize: 7.5 }}>every pixel, your call</p>
              </div>
            </div>
            <button className="j53-btn" style={{ padding: '6px 9px' }} onClick={() => setOpen(false)} aria-label="Close appearance lab" type="button">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>

          <Section title="Theme core">
            <div className="grid grid-cols-1 gap-2">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  className={`j53-theme-card ${appearance.theme === t.id ? 'active' : ''}`}
                  onClick={() => setAppearance({ theme: t.id })}
                  aria-pressed={appearance.theme === t.id}
                  type="button"
                >
                  <span className="flex overflow-hidden rounded-md border border-[rgba(var(--j53-accent-rgb),0.25)]" style={{ width: 46, height: 26 }}>
                    <span className="flex-1" style={{ background: t.bg }} />
                    <span className="flex-1" style={{ background: t.accent }} />
                    <span className="flex-1" style={{ background: t.accent2 }} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13px] font-semibold text-[var(--j53-text)]">{t.name}</span>
                    <span className="block text-[10.5px] text-[var(--j53-muted)]">{t.sub}</span>
                  </span>
                  {appearance.theme === t.id && <Check className="h-4 w-4 shrink-0 text-[var(--j53-accent)]" />}
                </button>
              ))}
            </div>
          </Section>

          <Section title="Accent color">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              {ACCENTS.map((c) => (
                <button
                  key={c}
                  className={`j53-swatch ${appearance.accent?.toLowerCase() === c ? 'active' : ''}`}
                  style={{ background: c }}
                  onClick={() => setAppearance({ accent: c })}
                  aria-label={`Accent ${c}`}
                  type="button"
                />
              ))}
            </div>
            <div className="flex items-center gap-2">
              <label className="j53-btn" style={{ padding: '7px 12px', fontSize: 10 }}>
                Custom
                <input
                  type="color"
                  className="sr-only"
                  value={appearance.accent ?? '#00e5ff'}
                  onChange={(e) => setAppearance({ accent: e.target.value })}
                  aria-label="Pick custom accent color"
                />
              </label>
              {appearance.accent && (
                <>
                  <span className="j53-pill font-mono" style={{ color: 'var(--j53-accent)' }}>
                    {appearance.accent.toUpperCase()}
                  </span>
                  <button className="j53-btn" style={{ padding: '7px 12px', fontSize: 10 }} onClick={() => setAppearance({ accent: null })} type="button">
                    Theme default
                  </button>
                </>
              )}
            </div>
          </Section>

          <Section title="Glow intensity">
            <Seg options={GLOWS.map((g) => ({ id: g, label: g }))} value={appearance.glow} onChange={(g) => setAppearance({ glow: g })} />
          </Section>

          <Section title="Display font">
            <Seg options={FONTS} value={appearance.font} onChange={(f) => setAppearance({ font: f })} />
          </Section>

          <Section title="Interface density">
            <Seg options={DENSITIES} value={appearance.density} onChange={(d) => setAppearance({ density: d })} />
          </Section>

          <Section title="HUD effects">
            <div className="space-y-2">
              <ToggleRow label="Scanlines" hint="CRT phosphor overlay" on={appearance.scanlines} onToggle={() => setAppearance({ scanlines: !appearance.scanlines })} />
              <ToggleRow label="Engineering grid" hint="Ambient blueprint mesh" on={appearance.grid} onToggle={() => setAppearance({ grid: !appearance.grid })} />
              <ToggleRow label="Panel sheen" hint="Slow power sweep on panels" on={appearance.sweep} onToggle={() => setAppearance({ sweep: !appearance.sweep })} />
            </div>
          </Section>

          <div className="mt-auto flex items-center justify-between gap-2 border-t border-[rgba(var(--j53-accent-rgb),0.14)] pt-4">
            <button
              className="j53-btn j53-btn--danger"
              style={{ padding: '8px 14px', fontSize: 10 }}
              onClick={() => resetAppearance()}
              type="button"
            >
              <RotateCcw className="h-3 w-3" /> Reset to factory
            </button>
            <p className="j53-label" style={{ fontSize: 7.5 }}>saved automatically</p>
          </div>
        </div>
      </aside>
    </>
  );
}
