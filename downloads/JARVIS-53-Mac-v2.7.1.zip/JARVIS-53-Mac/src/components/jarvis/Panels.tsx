'use client';

/**
 * JARVIS 53 — HUD rails: diagnostics (left), activity feed (right),
 * quick actions, quick-launch buttons.
 */
import { useEffect, useState } from 'react';
import { useJarvis } from './store';
import { Activity, BatteryCharging, Cpu, HardDrive, Play, Pause, Radio, ShieldCheck, Sun, Waves, Zap, Clock, CloudLightning, Newspaper } from 'lucide-react';

function Bar({ label, pct, value }: { label: string; pct: number; value?: string }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between">
        <span className="j53-label">{label}</span>
        <span className="font-mono text-[11px] text-[var(--j53-muted)]">{value ?? `${pct}%`}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-[rgba(var(--j53-accent-rgb),0.08)]">
        <div className="h-full rounded-full bg-gradient-to-r from-[var(--j53-accent)] to-[#7af3ff] transition-all duration-700" style={{ width: `${Math.min(100, pct)}%` }} />
      </div>
    </div>
  );
}

export function Diagnostics() {
  const status = useJarvis((s) => s.systemStatus);
  const health = useJarvis((s) => s.health);

  if (!status) {
    return (
      <div className="j53-panel p-4">
        <p className="j53-label">diagnostics</p>
        <p className="mt-2 text-xs text-[var(--j53-muted)]">Telemetry offline.</p>
      </div>
    );
  }

  const upH = Math.floor(status.uptimeSec / 3600);
  const upM = Math.floor((status.uptimeSec % 3600) / 60);

  return (
    <div className="j53-panel space-y-3.5 p-4">
      <div className="flex items-center justify-between">
        <p className="j53-label">system diagnostics</p>
        <span className="j53-pill j53-pill--live" style={{ fontSize: 8.5 }}>
          LIVE
        </span>
      </div>
      <Bar label="CPU load" pct={status.loadPct} />
      <Bar label="Memory" pct={status.memPct} value={`${status.memUsed} / ${status.memTotal}`} />
      <div className="grid grid-cols-1 gap-1.5 text-[12px] text-[var(--j53-muted)]">
        <div className="flex items-center gap-2">
          <Cpu className="h-3.5 w-3.5 text-[var(--j53-accent)]/70" />
          <span className="truncate">{status.cpuModel} × {status.cpuCount}</span>
        </div>
        <div className="flex items-center gap-2">
          <HardDrive className="h-3.5 w-3.5 text-[var(--j53-accent)]/70" />
          <span className="truncate">{status.platformLabel} · up {upH}h {upM}m</span>
        </div>
        {status.battery && (
          <div className="flex items-center gap-2">
            <BatteryCharging className="h-3.5 w-3.5 text-[var(--j53-green)]/80" />
            <span className="truncate">{status.battery}</span>
          </div>
        )}
        {status.wifi && (
          <div className="flex items-center gap-2">
            <Radio className="h-3.5 w-3.5 text-[var(--j53-accent)]/70" />
            <span className="truncate">{status.wifi}</span>
          </div>
        )}
        {health && (
          <div className="mt-1 flex flex-wrap gap-1.5">
            <span className="j53-pill" style={{ fontSize: 8.5 }}>
              <ShieldCheck className="h-3 w-3" /> {health.toolCount} TOOLS
            </span>
            <span className="j53-pill" style={{ fontSize: 8.5 }}>
              <Zap className="h-3 w-3" /> {health.aiProvider === 'builtin' ? 'NEURAL CORE' : health.aiProvider.toUpperCase()}
            </span>
            <span className="j53-pill" style={{ fontSize: 8.5 }}>
              v{health.version}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

const QUICK: Array<{ tool: string; label: string; icon: React.ReactNode; args?: Record<string, unknown> }> = [
  { tool: 'system.battery', label: 'Battery', icon: <BatteryCharging className="h-4 w-4" /> },
  { tool: 'system.wifi', label: 'Wi-Fi', icon: <Radio className="h-4 w-4" /> },
  { tool: 'system.info', label: 'Report', icon: <Cpu className="h-4 w-4" /> },
  { tool: 'media.now_playing', label: 'Now Playing', icon: <Waves className="h-4 w-4" /> },
  { tool: 'media.play_pause', label: 'Play / Pause', icon: <Play className="h-4 w-4" /> },
  { tool: 'info.weather', label: 'Weather', icon: <CloudLightning className="h-4 w-4" /> },
  { tool: 'info.news', label: 'Headlines', icon: <Newspaper className="h-4 w-4" /> },
  { tool: 'info.time', label: 'Time', icon: <Clock className="h-4 w-4" /> },
  { tool: 'notes.list', label: 'Notes', icon: <Sun className="h-4 w-4" /> },
  { tool: 'tasks.list', label: 'Tasks', icon: <Activity className="h-4 w-4" /> },
];

export function QuickActions({ onResult }: { onResult: (output: string) => void }) {
  const executeQuick = useJarvis((s) => s.executeQuick);
  const [running, setRunning] = useState<string | null>(null);
  const busyStore = useJarvis((s) => s.busy);
  const send = useJarvis((s) => s.send);

  async function run(tool: string) {
    setRunning(tool);
    const res = await executeQuick(tool, {}, false);
    setRunning(null);
    if (res) onResult(res.output || `${res.label}: ${res.status}`);
  }

  return (
    <div className="j53-panel p-4">
      <p className="j53-label mb-3">quick actions</p>
      <div className="grid grid-cols-5 gap-2">
        {QUICK.map((q) => (
          <button
            key={q.tool}
            className="group flex flex-col items-center gap-1.5 rounded-lg border border-[rgba(var(--j53-accent-rgb),0.12)] bg-[rgba(var(--j53-bg-rgb),0.5)] px-1 py-2.5 transition-all hover:border-[rgba(var(--j53-accent-rgb),0.4)] hover:shadow-[0_0_14px_rgba(var(--j53-accent-rgb),0.15)] disabled:opacity-50"
            onClick={() => run(q.tool)}
            disabled={running !== null || busyStore}
            title={q.label}
            type="button"
          >
            <span className="text-[var(--j53-accent)] transition-transform group-hover:scale-110">{running === q.tool ? <span className="j53-spinner block" /> : q.icon}</span>
            <span className="j53-label" style={{ fontSize: 8 }}>
              {q.label}
            </span>
          </button>
        ))}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <button className="j53-btn w-full" style={{ padding: '8px 10px' }} onClick={() => send('Run a focus sequence: hide my other apps and keep only my browser focused.')} type="button">
          FOCUS MODE
        </button>
        <button className="j53-btn w-full" style={{ padding: '8px 10px' }} onClick={() => send('Give me a full system report and today\'s headlines.')} type="button">
          MORNING BRIEF
        </button>
      </div>
      <button className="j53-btn j53-btn--gold mt-2 w-full" style={{ padding: '8px 10px' }} onClick={() => send('Pause the music, set volume to 25 and take a note: review the launch checklist.')} type="button">
        <Pause className="h-3.5 w-3.5" /> WIND-DOWN RITUAL
      </button>
    </div>
  );
}

export function ActivityFeed() {
  const toolLogs = useJarvis((s) => s.toolLogs);
  return (
    <div className="j53-panel flex min-h-0 flex-col p-4">
      <p className="j53-label mb-3">activity stream</p>
      <div className="j53-scroll min-h-0 flex-1 space-y-2 overflow-y-auto pr-1" style={{ maxHeight: 300 }}>
        {toolLogs.length === 0 && <p className="text-xs text-[var(--j53-muted)]">No automations yet. JARVIS logs every action here.</p>}
        {toolLogs.map((l) => (
          <div key={l.id} className="rounded-md border border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.55)] px-2.5 py-2">
            <div className="flex items-center justify-between gap-2">
              <span className="truncate font-mono text-[11px] text-[var(--j53-accent)]">{l.tool}</span>
              <span
                className="j53-pill"
                style={{ fontSize: 8, padding: '2px 7px', color: l.status === 'done' ? 'var(--j53-green)' : l.status === 'error' ? 'var(--j53-red)' : 'var(--j53-gold)' }}
              >
                {l.status === 'done' ? 'OK' : l.status === 'error' ? 'ERR' : l.status === 'confirm_required' ? 'WAIT' : l.status === 'unsupported' ? 'N/A' : 'RUN'}
              </span>
            </div>
            <p className="mt-0.5 truncate text-[11px] text-[var(--j53-muted)]">{l.output.split('\n')[0] || l.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
