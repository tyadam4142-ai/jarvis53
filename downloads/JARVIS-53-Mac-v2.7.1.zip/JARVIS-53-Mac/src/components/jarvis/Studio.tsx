'use client';

/**
 * JARVIS 53 — Productivity Studio: Drive (files & sites JARVIS built),
 * tasks, notes, prompt library. Drive is backed by the JARVIS Drive API —
 * it works identically on the website and on desktop installs.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { useJarvis } from './store';
import { CheckSquare, Download, ExternalLink, FileCode, FileText, Folder, ListChecks, NotebookPen, Sparkles, Square, Trash2, Wand2, HardDrive, RefreshCw } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  done: boolean;
  ts: number;
}
interface Note {
  id: string;
  title: string;
  body: string;
  ts: number;
}

interface DriveEntry {
  name: string;
  size: number;
  mtime: number;
  isDir: boolean;
}

const PROMPTS = [
  'Build me a beautiful website for my coffee shop',
  'Build a portfolio site for a robotics engineer',
  'Run a system report',
  "What's the weather in New York?",
  'Open Spotify and play deep focus',
  'Search my files for invoice',
  'Take a note: call the supplier at 4pm',
  'Remind me to stretch in 45 minutes',
  'Draft an email to alex@starkindustries.com about the Q3 launch timeline',
  'Headlines from around the world',
  'Convert 100 USD to INR',
];

function fmtBytes(n: number): string {
  if (!n) return '—';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

function fileIcon(name: string) {
  if (/\.(html?|svg|css|js|mjs|json|xml)$/i.test(name)) return <FileCode className="h-4 w-4 shrink-0 text-[var(--j53-accent)]" />;
  if (/\.(png|jpe?g|gif|webp|ico)$/i.test(name)) return <FileText className="h-4 w-4 shrink-0 text-[var(--j53-green)]" />;
  return <FileText className="h-4 w-4 shrink-0 text-[var(--j53-muted)]" />;
}

function previewUrlFor(name: string) {
  const phone = useJarvis.getState().phone;
  return `/api/drive/preview?name=${encodeURIComponent(name)}${phone ? `&phone=${encodeURIComponent(phone)}` : ''}`;
}

function DriveTab() {
  const phone = useJarvis((s) => s.phone);
  const drivePreview = useJarvis((s) => s.drivePreview);
  const setDrivePreview = useJarvis((s) => s.setDrivePreview);
  const [entries, setEntries] = useState<DriveEntry[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [code, setCode] = useState<string>('');
  const [reloadKey, setReloadKey] = useState(0);
  const consumedRef = useRef<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/drive${phone ? `?phone=${encodeURIComponent(phone)}` : ''}`, { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Could not load the Drive.');
      setEntries(data.entries ?? []);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [phone]);

  useEffect(() => {
    void load();
  }, [load, reloadKey]);

  // A chat tool card asked Studio to open this file
  useEffect(() => {
    if (drivePreview && drivePreview !== consumedRef.current) {
      consumedRef.current = drivePreview;
      setSelected(drivePreview);
      setViewMode('preview');
      setDrivePreview(null);
    }
  }, [drivePreview, setDrivePreview]);

  const isPreviewable = (name: string) => /\.(html?|svg|png|jpe?g|gif|webp|pdf|txt|md|csv|json|css|js|mjs|xml)$/i.test(name);
  const isHtml = (name: string) => /\.(html?|svg)$/i.test(name);

  const openFile = async (name: string) => {
    setSelected(name);
    setViewMode(isHtml(name) ? 'preview' : 'code');
    if (!isHtml(name)) {
      try {
        const res = await fetch(previewUrlFor(name), { cache: 'no-store' });
        setCode(await res.text());
      } catch {
        setCode('Could not load file.');
      }
    }
  };

  const removeFile = async (name: string) => {
    if (!window.confirm(`Delete "${name}" from your Drive?`)) return;
    const phoneParam = phone ? `&phone=${encodeURIComponent(phone)}` : '';
    await fetch(`/api/drive?name=${encodeURIComponent(name)}${phoneParam}`, { method: 'DELETE' }).catch(() => undefined);
    if (selected === name) setSelected(null);
    setReloadKey((k) => k + 1);
  };

  const files = entries.filter((e) => !e.isDir);
  const dirsFirst = [...entries].sort((a, b) => Number(b.isDir) - Number(a.isDir) || a.name.localeCompare(b.name));

  return (
    <div className="j53-panel p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <HardDrive className="h-4 w-4 text-[var(--j53-accent)]" />
          <p className="j53-label">jarvis drive</p>
          <span className="j53-pill" style={{ fontSize: 9 }}>
            {files.length} FILE{files.length === 1 ? '' : 'S'}
          </span>
        </div>
        <div className="flex gap-2">
          <button className="j53-btn" style={{ padding: '6px 12px' }} onClick={() => setReloadKey((k) => k + 1)} title="Refresh" type="button">
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </button>
          <a className="j53-btn j53-btn--gold" style={{ padding: '6px 12px', textDecoration: 'none' }} href={`/api/drive/download${phone ? `?phone=${encodeURIComponent(phone)}` : ''}`} title="Download every file as a zip">
            <Download className="h-3.5 w-3.5" /> Download all
          </a>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center gap-2 py-10 text-sm text-[var(--j53-muted)]">
          <span className="j53-spinner" /> Opening the Drive…
        </div>
      ) : error ? (
        <p className="py-6 text-sm text-[var(--j53-red)]">{error}</p>
      ) : dirsFirst.length === 0 ? (
        <div className="rounded-lg border border-dashed border-[rgba(var(--j53-accent-rgb),0.25)] px-6 py-10 text-center">
          <Folder className="mx-auto mb-3 h-8 w-8 text-[var(--j53-muted)]" />
          <p className="text-sm text-[var(--j53-text-2)]">Your Drive is empty.</p>
          <p className="mt-1.5 text-[13px] leading-5 text-[var(--j53-muted)]">
            Say <em>&ldquo;build me a website for my bakery&rdquo;</em> or <em>&ldquo;save a file notes/todo.md&rdquo;</em> in the console — JARVIS creates real files here, previewable and downloadable.
          </p>
        </div>
      ) : (
        <div className={`grid gap-3 ${selected ? 'lg:grid-cols-[280px_minmax(0,1fr)]' : ''}`}>
          <div className="j53-scroll max-h-[56vh] space-y-1 overflow-y-auto pr-1">
            {dirsFirst.map((e) => (
              <div
                key={e.name}
                className={`group flex items-center gap-2.5 rounded-lg border px-3 py-2 transition-colors ${
                  selected === e.name
                    ? 'border-[rgba(var(--j53-accent-rgb),0.5)] bg-[rgba(var(--j53-accent-rgb),0.08)]'
                    : 'border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.55)] hover:border-[rgba(var(--j53-accent-rgb),0.3)]'
                }`}
              >
                <button className="flex min-w-0 flex-1 items-center gap-2.5 text-left" onClick={() => !e.isDir && openFile(e.name)} disabled={e.isDir} type="button">
                  {e.isDir ? <Folder className="h-4 w-4 shrink-0 text-[var(--j53-gold)]" /> : fileIcon(e.name)}
                  <span className="min-w-0 flex-1 truncate text-[13px] text-[var(--j53-text)]">{e.name}</span>
                  {!e.isDir && <span className="shrink-0 font-mono text-[10.5px] text-[var(--j53-muted)]">{fmtBytes(e.size)}</span>}
                </button>
                {!e.isDir && (
                  <span className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                    {isPreviewable(e.name) && (
                      <a href={previewUrlFor(e.name)} target="_blank" rel="noreferrer" title="Open in new tab" className="text-[var(--j53-muted)] hover:text-[var(--j53-accent)]">
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    )}
                    <button onClick={() => removeFile(e.name)} title="Delete" aria-label={`Delete ${e.name}`} type="button">
                      <Trash2 className="h-3.5 w-3.5 text-[var(--j53-muted)] transition-colors hover:text-[var(--j53-red)]" />
                    </button>
                  </span>
                )}
              </div>
            ))}
          </div>

          {selected && (
            <div className="min-w-0">
              <div className="mb-2 flex items-center justify-between gap-2">
                <p className="truncate font-mono text-[12px] text-[var(--j53-accent)]">{selected}</p>
                <div className="flex gap-1.5">
                  {isHtml(selected) && (
                    <button className={`j53-btn ${viewMode === 'preview' ? 'j53-glow' : ''}`} style={{ padding: '5px 10px' }} onClick={() => setViewMode('preview')} type="button">
                      Live
                    </button>
                  )}
                  <button className={`j53-btn ${viewMode === 'code' ? 'j53-glow' : ''}`} style={{ padding: '5px 10px' }} onClick={() => void openFile(selected)} type="button">
                    Code
                  </button>
                  <a className="j53-btn" style={{ padding: '5px 10px', textDecoration: 'none' }} href={previewUrlFor(selected)} target="_blank" rel="noreferrer" type="button">
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                </div>
              </div>
              {viewMode === 'preview' && isHtml(selected) ? (
                <iframe
                  key={selected}
                  src={previewUrlFor(selected)}
                  title={`Preview of ${selected}`}
                  sandbox="allow-scripts allow-forms allow-popups"
                  className="h-[56vh] w-full rounded-lg border border-[rgba(var(--j53-accent-rgb),0.2)] bg-white"
                />
              ) : (
                <pre className="j53-scroll max-h-[56vh] overflow-auto rounded-lg border border-[rgba(var(--j53-accent-rgb),0.15)] bg-[rgba(var(--j53-bg-rgb),0.7)] p-4 font-mono text-[12px] leading-5 text-[var(--j53-text-2)]">
                  {code || 'Select a file…'}
                </pre>
              )}
              <p className="j53-label mt-2" style={{ fontSize: 8 }}>
                preview sandboxed · scripts run, same-origin access blocked
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function Studio() {
  const send = useJarvis((s) => s.send);
  const [tab, setTab] = useState<'drive' | 'tasks' | 'notes' | 'prompts'>('drive');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [taskInput, setTaskInput] = useState('');
  const [noteTitle, setNoteTitle] = useState('');
  const [noteBody, setNoteBody] = useState('');

  useEffect(() => {
    try {
      setTasks(JSON.parse(localStorage.getItem('j53_tasks') ?? '[]'));
      setNotes(JSON.parse(localStorage.getItem('j53_notes') ?? '[]'));
    } catch {
      /* fresh start */
    }
  }, []);

  function persistTasks(next: Task[]) {
    setTasks(next);
    localStorage.setItem('j53_tasks', JSON.stringify(next));
  }
  function persistNotes(next: Note[]) {
    setNotes(next);
    localStorage.setItem('j53_notes', JSON.stringify(next));
  }

  return (
    <div className="mx-auto w-full max-w-5xl">
      <div className="mb-4 flex gap-2">
        {(
          [
            ['drive', <HardDrive key="d" className="h-3.5 w-3.5" />],
            ['tasks', <ListChecks key="t" className="h-3.5 w-3.5" />],
            ['notes', <NotebookPen key="n" className="h-3.5 w-3.5" />],
            ['prompts', <Sparkles key="p" className="h-3.5 w-3.5" />],
          ] as const
        ).map(([id, icon]) => (
          <button key={id} className={`j53-btn flex-1 ${tab === id ? 'j53-glow' : ''}`} onClick={() => setTab(id)} type="button">
            {icon} {id.toUpperCase()}
          </button>
        ))}
      </div>

      {tab === 'drive' && <DriveTab />}

      {tab === 'tasks' && (
        <div className="j53-panel p-5">
          <div className="flex gap-2">
            <input
              className="j53-input flex-1"
              placeholder="Add a task… (JARVIS can also add tasks via voice)"
              value={taskInput}
              onChange={(e) => setTaskInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && taskInput.trim()) {
                  persistTasks([{ id: Math.random().toString(36).slice(2), title: taskInput.trim(), done: false, ts: Date.now() }, ...tasks]);
                  setTaskInput('');
                }
              }}
              aria-label="New task"
            />
            <button
              className="j53-btn"
              onClick={() => {
                if (!taskInput.trim()) return;
                persistTasks([{ id: Math.random().toString(36).slice(2), title: taskInput.trim(), done: false, ts: Date.now() }, ...tasks]);
                setTaskInput('');
              }}
              type="button"
            >
              Add
            </button>
          </div>
          <div className="j53-scroll mt-4 max-h-[52vh] space-y-2 overflow-y-auto pr-1">
            {tasks.length === 0 && <p className="text-sm text-[var(--j53-muted)]">Clean slate. Add a task, or say &ldquo;remind me to…&rdquo; in the console.</p>}
            {tasks.map((t) => (
              <div key={t.id} className="flex items-center gap-3 rounded-lg border border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.55)] px-3 py-2.5">
                <button
                  onClick={() => persistTasks(tasks.map((x) => (x.id === t.id ? { ...x, done: !x.done } : x)))}
                  aria-label={t.done ? 'Mark incomplete' : 'Mark complete'}
                  type="button"
                >
                  {t.done ? <CheckSquare className="h-4.5 w-4.5 text-[var(--j53-green)]" /> : <Square className="h-4.5 w-4.5 text-[var(--j53-muted)]" />}
                </button>
                <span className={`flex-1 text-[14px] ${t.done ? 'text-[var(--j53-muted)] line-through' : 'text-[var(--j53-text)]'}`}>{t.title}</span>
                <button onClick={() => persistTasks(tasks.filter((x) => x.id !== t.id))} aria-label="Delete task" type="button">
                  <Trash2 className="h-4 w-4 text-[var(--j53-muted)] transition-colors hover:text-[var(--j53-red)]" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'notes' && (
        <div className="j53-panel p-5">
          <div className="grid gap-2 sm:grid-cols-[1fr_2fr_auto]">
            <input className="j53-input" placeholder="Title" value={noteTitle} onChange={(e) => setNoteTitle(e.target.value)} aria-label="Note title" />
            <input className="j53-input" placeholder="Note content…" value={noteBody} onChange={(e) => setNoteBody(e.target.value)} aria-label="Note body" />
            <button
              className="j53-btn"
              onClick={() => {
                if (!noteBody.trim()) return;
                persistNotes([{ id: Math.random().toString(36).slice(2), title: noteTitle.trim() || 'Quick note', body: noteBody.trim(), ts: Date.now() }, ...notes]);
                setNoteTitle('');
                setNoteBody('');
              }}
              type="button"
            >
              Save
            </button>
          </div>
          <div className="j53-scroll mt-4 max-h-[52vh] space-y-2 overflow-y-auto pr-1">
            {notes.length === 0 && <p className="text-sm text-[var(--j53-muted)]">No notes yet. Say &ldquo;take a note…&rdquo; and JARVIS writes it down.</p>}
            {notes.map((n) => (
              <div key={n.id} className="rounded-lg border border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.55)] px-3 py-2.5">
                <div className="flex items-center justify-between">
                  <p className="text-[13.5px] font-semibold text-[var(--j53-accent)]">{n.title}</p>
                  <button onClick={() => persistNotes(notes.filter((x) => x.id !== n.id))} aria-label="Delete note" type="button">
                    <Trash2 className="h-4 w-4 text-[var(--j53-muted)] transition-colors hover:text-[var(--j53-red)]" />
                  </button>
                </div>
                <p className="mt-1 whitespace-pre-wrap text-[13px] leading-5 text-[var(--j53-text-2)]">{n.body}</p>
                <p className="j53-label mt-1.5" style={{ fontSize: 8 }}>
                  {new Date(n.ts).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'prompts' && (
        <div className="j53-panel p-5">
          <p className="j53-label mb-1">prompt library</p>
          <p className="mb-4 text-sm text-[var(--j53-muted)]">One-tap commands that show off the full tool registry — including website building.</p>
          <div className="flex flex-wrap gap-2">
            {PROMPTS.map((p) => (
              <button
                key={p}
                className="flex items-center gap-1.5 rounded-full border border-[rgba(var(--j53-accent-rgb),0.18)] bg-[rgba(var(--j53-accent-rgb),0.05)] px-3.5 py-2 text-[13px] text-[var(--j53-text-2)] transition-all hover:border-[rgba(var(--j53-accent-rgb),0.45)] hover:text-[var(--j53-text)]"
                onClick={() => {
                  send(p);
                  useJarvis.getState().setView('console');
                }}
                type="button"
              >
                <Wand2 className="h-3.5 w-3.5 text-[var(--j53-accent)]" /> {p}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
