'use client';

/**
 * JARVIS 53 — service worker registration.
 * Conservative by design: the SW exists to make the HUD installable and
 * instantly openable; it never caches API responses or HTML, so updates
 * always arrive the next time the launcher rebuilds/serves the app.
 */
import { useEffect } from 'react';

export default function SwRegister() {
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!('serviceWorker' in navigator)) return;
    if (!/^https?:$/.test(window.location.protocol)) return;
    const t = setTimeout(() => {
      navigator.serviceWorker.register('/sw.js').catch(() => undefined);
    }, 1800);
    return () => clearTimeout(t);
  }, []);
  return null;
}
