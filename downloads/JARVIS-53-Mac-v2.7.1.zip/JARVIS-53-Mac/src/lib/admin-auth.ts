/**
 * JARVIS 53 — admin session guard.
 * The admin secret comes from JARVIS_ADMIN_PIN (.env) or a PIN the owner set. The old factory
 * PIN (5353) and any weak PIN are refused, so a fresh install can never be opened with a known code.
 */
import crypto from 'crypto';
import type { NextRequest } from 'next/server';
import { getSetting, DEFAULT_MASTER_PIN } from './data';

const WEAK = new Set([DEFAULT_MASTER_PIN, '0000', '1111', '1234', '123456', '000000', '111111', '12345678']);

export async function getMasterPin(): Promise<string> {
  const env = (process.env.JARVIS_ADMIN_PIN ?? '').trim();
  if (env) return env;
  return getSetting('masterPin', DEFAULT_MASTER_PIN);
}

export function pinIsUsable(pin: string): boolean {
  return pin.length >= 6 && !WEAK.has(pin);
}

export function safeEqual(a: string, b: string): boolean {
  const l = Buffer.from(a);
  const r = Buffer.from(b);
  return l.length === r.length && crypto.timingSafeEqual(l, r);
}

export function tokenFor(pin: string): string {
  return crypto.createHmac('sha256', `j53::${pin}::desk`).update('admin-session').digest('hex');
}

export function adminCookieName(): string {
  return 'j53_admin';
}

export async function guard(req: NextRequest): Promise<boolean> {
  if (process.env.JARVIS_ADMIN_MODE !== '1') return false;
  const token = req.cookies.get(adminCookieName())?.value;
  if (!token) return false;
  const pin = await getMasterPin();
  if (!pinIsUsable(pin)) return false;
  return safeEqual(token, tokenFor(pin));
}

/** Now means "admin is locked until a strong PIN is configured". */
export async function isDefaultPin(): Promise<boolean> {
  return !pinIsUsable(await getMasterPin());
}

const attempts = new Map<string, { n: number; until: number }>();
export function loginThrottled(key: string): boolean {
  const a = attempts.get(key);
  return Boolean(a && a.until > Date.now() && a.n >= 5);
}
export function loginFailed(key: string) {
  const a = attempts.get(key);
  const now = Date.now();
  if (!a || a.until < now) attempts.set(key, { n: 1, until: now + 5 * 60_000 });
  else a.n += 1;
}
export function loginOk(key: string) { attempts.delete(key); }
