/**
 * JARVIS 53 AI routing.
 * Generative responses always use the configured cloud provider pool with automatic failover.
 * Only exact deterministic computer commands are handled locally; there is no local language-model fallback.
 */
import { jarvisSystemPrompt, conciergeSystemPrompt } from './prompts';
import { cloudChat, poolCount, type AIProvider } from './keys';
import { TOOL_MAP } from '@/lib/tools/registry';

export interface AIAction {
  tool: string;
  args: Record<string, unknown>;
}

export type ProviderName = AIProvider | 'offline' | 'unavailable';
export interface AIResult {
  say: string;
  actions: AIAction[];
  provider: ProviderName;
  model?: string;
  routeNote?: string;
}

type Msg = { role: 'system' | 'user' | 'assistant'; content: string };
/** Parse the structured action format, while gracefully accepting ordinary-text model answers. */
export function parseAIJson(text: string): { say: string; actions: AIAction[] } | null {
  if (!text?.trim()) return null;
  let cleaned = text.trim();
  const fence = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) cleaned = fence[1].trim();

  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start >= 0 && end > start) {
    let raw = cleaned.slice(start, end + 1).replace(/,\s*([}\]])/g, '$1');
    try {
      const obj = JSON.parse(raw) as {
        say?: unknown;
        speak?: unknown;
        actions?: Array<{ tool?: unknown; args?: unknown }>;
        tool?: unknown;
        args?: unknown;
      };
      const say = String(obj.say ?? obj.speak ?? '').trim();
      let actions: AIAction[] = [];
      if (Array.isArray(obj.actions)) {
        actions = obj.actions
          .map((a) => ({
            tool: String(a?.tool ?? ''),
            args: a?.args && typeof a.args === 'object' && !Array.isArray(a.args) ? (a.args as Record<string, unknown>) : {},
          }))
          .filter((a) => a.tool && TOOL_MAP[a.tool]);
      } else if (obj.tool && typeof obj.tool === 'string') {
        const tool = String(obj.tool);
        const args = obj.args && typeof obj.args === 'object' && !Array.isArray(obj.args) ? (obj.args as Record<string, unknown>) : {};
        if (TOOL_MAP[tool]) actions = [{ tool, args }];
      }
      if (say || actions.length) return { say: say || 'Done.', actions: actions.slice(0, 4) };
      // A valid but differently-shaped JSON answer should not be printed as raw JSON.
      return null;
    } catch {
      if (/^\s*\{[\s\S]*\}\s*$/.test(cleaned) || /"(?:say|speak|actions|tool)"\s*:/.test(cleaned)) return null;
    }
  }

  // Some model/provider combinations occasionally ignore the JSON format for ordinary Q&A.
  // Display the answer rather than silently switching model providers just because of formatting.
  if (!/^\s*\{/.test(cleaned)) return { say: cleaned, actions: [] };
  return null;
}

interface Intent {
  re: RegExp;
  build: (m: RegExpMatchArray) => { say: string; actions: AIAction[] };
}

const OFFLINE_INTENTS: Intent[] = [
  { re: /^open (?:the )?(.+?)(?: app)?$/i, build: (m) => ({ say: `Opening ${m[1]}.`, actions: [{ tool: 'apps.launch', args: { app: m[1] } }] }) },
  { re: /^(?:quit|close|exit) (?:the )?(.+?)(?: app)?$/i, build: (m) => ({ say: `Closing ${m[1]}.`, actions: [{ tool: 'apps.quit', args: { app: m[1] } }] }) },
  { re: /^list (?:running )?apps$/i, build: () => ({ say: 'Scanning running apps.', actions: [{ tool: 'apps.list_running', args: {} }] }) },
  { re: /^(?:set )?volume (?:to )?(\d{1,3})$/i, build: (m) => ({ say: `Volume ${m[1]} percent.`, actions: [{ tool: 'system.volume', args: { level: Number(m[1]) } }] }) },
  { re: /^mute$/i, build: () => ({ say: 'Muting.', actions: [{ tool: 'system.mute', args: {} }] }) },
  { re: /^battery(?: status)?\??$/i, build: () => ({ say: 'Checking the battery.', actions: [{ tool: 'system.battery', args: {} }] }) },
  { re: /^wifi(?: status)?\??$|^wi-?fi\??$/i, build: () => ({ say: 'Checking Wi-Fi.', actions: [{ tool: 'system.wifi', args: {} }] }) },
  { re: /^lock(?: (?:the )?screen)?$/i, build: () => ({ say: 'Locking your screen.', actions: [{ tool: 'system.lock', args: {} }] }) },
  { re: /^(?:what.s|what is) the time\??$|^time\??$/i, build: () => ({ say: 'Checking the clock.', actions: [{ tool: 'info.time', args: {} }] }) },
  { re: /^(?:what.s|how.s) the weather(?: in (.+?))?\??$/i, build: (m) => ({ say: `Fetching weather${m[1] ? ` for ${m[1]}` : ''}.`, actions: [{ tool: 'info.weather', args: m[1] ? { city: m[1] } : {} }] }) },
  { re: /^play (.+?)(?: on (spotify|youtube|apple music))?$/i, build: (m) => ({ say: `Playing ${m[1]}${m[2] ? ` on ${m[2]}` : ''}.`, actions: [{ tool: 'media.play_search', args: { query: m[1], ...(m[2] ? { service: m[2].replace('apple music', 'apple_music') } : {}) } }] }) },
  { re: /^pause$|^play$/i, build: () => ({ say: 'Toggling playback.', actions: [{ tool: 'media.play_pause', args: {} }] }) },
  { re: /^next(?: track)?$/i, build: () => ({ say: 'Skipping ahead.', actions: [{ tool: 'media.next', args: {} }] }) },
  { re: /^search(?: for)? (.+)$/i, build: (m) => ({ say: `Searching for ${m[1]}.`, actions: [{ tool: 'web.search', args: { query: m[1] } }] }) },
  { re: /^(?:search )?files? (?:for |named )?(.+)$/i, build: (m) => ({ say: `Searching your files for ${m[1]}.`, actions: [{ tool: 'files.search', args: { query: m[1] } }] }) },
  { re: /^(?:take a )?note(?: that)? (.+)$/i, build: (m) => ({ say: 'Noted.', actions: [{ tool: 'notes.add', args: { title: 'Quick Note', body: m[1] } }] }) },
  { re: /^(?:remind me to )(.+)$/i, build: (m) => ({ say: `Reminder set: ${m[1]}.`, actions: [{ tool: 'reminders.create', args: { title: m[1] } }] }) },
  { re: /^email (.+?) about (.+)$/i, build: (m) => ({ say: `Drafting an email to ${m[1]}.`, actions: [{ tool: 'email.draft', args: { to: m[1], subject: m[2], body: `Hi,\n\n${m[2]}\n\nBest regards` } }] }) },
  { re: /^whatsapp (.+?) (.+)$/i, build: (m) => ({ say: 'Opening WhatsApp.', actions: [{ tool: 'whatsapp.compose', args: { phone: m[1], message: m[2] } }] }) },
  { re: /^system (?:info|report|status)$/i, build: () => ({ say: 'Running a system report.', actions: [{ tool: 'system.info', args: {} }] }) },
  { re: /^dark mode( on| off)?$/i, build: (m) => ({ say: 'Switching appearance.', actions: [{ tool: 'system.dark_mode', args: { mode: m[1]?.includes('on') ? 'dark' : m[1]?.includes('off') ? 'light' : 'toggle' } }] }) },
];

function offlineCommand(text: string): AIResult | null {
  const input = text.trim();
  // Do not let a broad one-command regex swallow a multi-step natural-language request.
  // For example, "open Spotify and play focus music" must reach the selected AI model
  // so it can choose and sequence both tools, rather than attempting to launch one long app name.
  const compoundAction = /\b(?:and then|then|after that|followed by)\b/i.test(input) ||
    /\band\s+(?:open|launch|play|search|create|send|write|draft|set|make|take|email|message|mute|pause|resume|turn on|turn off|lock|close|quit|check|show|find)\b/i.test(input);
  if (compoundAction) return null;
  for (const intent of OFFLINE_INTENTS) {
    const match = input.match(intent.re);
    if (!match) continue;
    const built = intent.build(match);
    return { ...built, provider: 'offline', routeNote: 'Handled locally by the deterministic command router.' };
  }
  return null;
}

function unavailableResult(detail: string): AIResult {
  return {
    say: `I couldn't reach any configured cloud AI provider. ${detail} I did not switch to a local language model, and no computer action was run.`,
    actions: [],
    provider: 'unavailable',
    model: 'automatic cloud failover',
    routeNote: 'All configured cloud routes failed; no local-language fallback was used.',
  };
}

export async function aiStatus(): Promise<{ provider: string; keys: { total: number; healthy: number }; model: string }> {
  const keys = await poolCount();
  const provider = keys.healthy > 0 ? 'cloud-failover' : 'key-needed';
  return { provider, keys: { total: keys.total, healthy: keys.healthy }, model: 'OpenRouter / NVIDIA NIM / Google Gemini (automatic rotation)' };
}

/**
 * Natural-language requests always use cloud AI and automatically rotate through configured
 * OpenRouter, NVIDIA NIM, and Gemini keys. Only strict, deterministic OS commands run locally.
 * The legacy plan argument is deliberately ignored.
 */
export async function jarvisThink(history: Msg[], userText: string, _plan = 'free'): Promise<AIResult> {
  const local = offlineCommand(userText);
  if (local) return local;

  const messages: Msg[] = [
    { role: 'system', content: jarvisSystemPrompt() },
    ...history
      .filter((m) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .slice(-8)
      .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content.slice(0, 4000) })),
    { role: 'user', content: userText.slice(0, 4000) },
  ];

  try {
    const response = await cloudChat(messages, {
      temperature: 0.2,
      // Websites and documents ride inside the JSON "actions" — a small cap here
      // is what used to truncate them mid-string and break parsing.
      maxTokens: 8000,
      maxAttempts: 6,
      // If a provider ignores the requested response format, try another provider/key.
      validate: (text) => parseAIJson(text) !== null,
    });
    const parsed = parseAIJson(response.text);
    if (!parsed) return unavailableResult('Every available provider returned a response JARVIS could not understand.');
    return {
      ...parsed,
      provider: response.provider,
      model: response.model,
      routeNote: `Cloud failover route · ${response.provider} / ${response.model}. Local routing is used only for exact deterministic commands.`,
    };
  } catch (error) {
    const detail = error instanceof Error ? error.message : 'The request failed.';
    return unavailableResult(detail);
  }
}

export async function conciergeReply(
  history: Msg[],
  userText: string
): Promise<{ text: string; needsHuman: boolean; provider: ProviderName }> {
  const messages: Msg[] = [
    { role: 'system', content: conciergeSystemPrompt() },
    ...history
      .filter((m) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .slice(-8)
      .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content.slice(0, 4000) })),
    { role: 'user', content: userText.slice(0, 2000) },
  ];

  try {
    const response = await cloudChat(messages, { temperature: 0.2, maxTokens: 900, maxAttempts: 8 });
    return finalize(response.text, response.provider);
  } catch (error) {
    const detail = error instanceof Error ? error.message : 'All cloud providers are unavailable.';
    return {
      text: `I couldn't get a response from the configured cloud AI providers. ${detail} Please check the keys/credits or retry shortly. I have not switched to a local answer brain.`,
      needsHuman: false,
      provider: 'unavailable',
    };
  }

  function finalize(text: string, provider: ProviderName) {
    const needsHuman = /\[\[TICKET\]\]/.test(text);
    return {
      text: `${text.replace(/\[\[TICKET\]\]/g, '').trim()}${needsHuman ? '\n\n[[TICKET]]' : ''}\n\n— J-53 Concierge`,
      needsHuman,
      provider,
    };
  }
}

/**
 * Draft a customer-facing message through the configured cloud AI key pool.
 * This helper intentionally has no local canned-response fallback: provider failures
 * bubble up to the API route, which returns a visible error to the UI.
 */
export async function draftMessage(input: {
  channel: 'whatsapp' | 'email';
  brief: string;
  recipient?: string | null;
  tone?: string | null;
}): Promise<{ subject: string; body: string; provider: AIProvider; model: string }> {
  const channel = input.channel;
  const system = channel === 'email'
    ? 'You are JARVIS 53, an excellent email-writing assistant. Write a polished, ready-to-edit email based only on the user brief. Do not invent facts, dates, attachments, or promises. Return one valid JSON object only, with string keys "subject" and "body". No markdown fences.'
    : 'You are JARVIS 53, an excellent WhatsApp-message writer. Write a concise, natural message based only on the user brief. Do not invent facts or promises. Return one valid JSON object only, with string keys "subject" (empty string) and "body". No markdown fences.';
  const user = [
    `Channel: ${channel}`,
    `Recipient: ${input.recipient?.trim() || 'not specified'}`,
    `Tone: ${input.tone?.trim() || 'Professional and natural'}`,
    `Brief: ${input.brief.trim().slice(0, 2000)}`,
    'Return the complete draft as JSON with subject and body fields.',
  ].join('\n');

  const decode = (raw: string): { subject: string; body: string } | null => {
    let cleaned = raw.trim();
    const fence = cleaned.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
    if (fence) cleaned = fence[1].trim();
    try {
      const value = JSON.parse(cleaned) as Record<string, unknown>;
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        const body = String(value.body ?? value.message ?? value.text ?? value.draft ?? '').trim();
        const subject = String(value.subject ?? '').trim();
        if (body) return { subject: channel === 'email' ? (subject || 'Draft email') : '', body };
      }
      // A syntactically valid but unrelated JSON object is not a usable draft.
      return null;
    } catch {
      // Some otherwise useful model replies ignore JSON formatting. Salvage plain text,
      // but reject malformed JSON-looking output instead of showing raw braces to the user.
      if (!cleaned || /^\s*[\[{]/.test(cleaned)) return null;
      const subjectLine = channel === 'email'
        ? cleaned.match(/^Subject\s*:\s*(.+?)\s*(?:\r?\n){1,2}([\s\S]+)$/i)
        : null;
      if (subjectLine) return { subject: subjectLine[1].trim(), body: subjectLine[2].trim() };
      return { subject: channel === 'email' ? 'Draft email' : '', body: cleaned };
    }
  };

  const response = await cloudChat(
    [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
    {
      temperature: 0.35,
      maxTokens: 800,
      maxAttempts: 6,
      validate: (text) => decode(text) !== null,
    },
  );
  const draft = decode(response.text);
  if (!draft?.body) throw new Error('The configured cloud AI providers did not return a usable message draft. Please retry.');
  return { ...draft, provider: response.provider, model: response.model };
}

/**
 * Draft a support-ticket reply for an admin to review. It never sends the reply.
 * Provider failures are surfaced to the route; no local generated answer is substituted.
 */
export async function draftTicketReply(
  ticket: { subject: string; phone?: string | null },
  replies: Array<{ author: string; body: string }>,
): Promise<string> {
  const transcript = replies
    .slice(-12)
    .map((reply) => `${String(reply.author || 'Customer').slice(0, 80)}: ${String(reply.body || '').slice(0, 1800)}`)
    .join('\n\n')
    .slice(-10000);
  const response = await cloudChat(
    [
      {
        role: 'system',
        content: 'You are a helpful customer-support specialist for JARVIS 53. Draft a concise, empathetic support reply based on the ticket and conversation. Do not claim an action was completed, invent policies, promise refunds, or disclose secrets. The administrator will review and send it manually. Return only the reply text.',
      },
      {
        role: 'user',
        content: `Ticket subject: ${String(ticket.subject || 'Support request').slice(0, 300)}\n\nConversation so far:\n${transcript || '(No replies yet.)'}\n\nDraft the next reply.`,
      },
    ],
    { temperature: 0.25, maxTokens: 700, maxAttempts: 6 },
  );
  const draft = response.text.trim().replace(/^```(?:text|markdown)?\s*/i, '').replace(/\s*```$/, '').trim();
  if (!draft) throw new Error('The configured cloud AI providers returned an empty support draft. Please retry.');
  return draft;
}

