/**
 * JARVIS 53 — settings & telemetry helpers.
 */
import { db } from '@/lib/db';

export async function getSetting(key: string, fallback: string): Promise<string> {
  try {
    const row = await db.setting.findUnique({ where: { key } });
    return row?.value ?? fallback;
  } catch {
    return fallback;
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db.setting.upsert({ where: { key }, update: { value }, create: { key, value } });
}

export async function logUsage(phone: string | null | undefined, kind: string, detail?: string): Promise<void> {
  try {
    await db.usageLog.create({ data: { phone: phone ?? null, kind, detail: detail?.slice(0, 300) } });
  } catch {
    /* telemetry must never break the product */
  }
}

export const DEFAULT_MASTER_PIN = '5353';
