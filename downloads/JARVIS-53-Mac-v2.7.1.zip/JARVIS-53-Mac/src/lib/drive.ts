/**
 * JARVIS 53 — JARVIS Drive.
 * A persistent, sandboxed workspace that exists on EVERY installation —
 * the hosted website, a Mac, a Windows PC, anywhere. When JARVIS "creates
 * files" or "builds a website", the bytes land here: browsable in
 * Studio → Drive, previewable live, downloadable as a zip.
 *
 * Path safety: every name is resolved inside DRIVE_ROOT/<bucket>/ and any
 * attempt to escape (`..`, absolute paths, symlink tricks) is rejected.
 */
import { promises as fs } from 'fs';
import path from 'path';

export const DRIVE_ROOT = process.env.JARVIS_DRIVE_DIR
  ? path.resolve(process.env.JARVIS_DRIVE_DIR)
  : path.join(process.cwd(), 'workspace');

export const MAX_FILE_BYTES = 3_000_000; // 3 MB per file — plenty for a full website
const MAX_LIST_ENTRIES = 400;
const MAX_DEPTH = 6;

/** Bucket = per-customer subfolder (phone-derived) or the shared "local" drive. */
export function driveBucket(phone?: string | null): string {
  const digits = String(phone ?? '').replace(/\D/g, '');
  return digits.length >= 8 ? digits : 'local';
}

export interface DrivePath {
  ok: boolean;
  abs: string;
  rel: string;
  reason?: string;
}

/** Resolve + validate a user-supplied Drive name ("sites/bakery.html"). */
export function resolveDrivePath(bucket: string, rawName: string): DrivePath {
  const cleaned = String(rawName ?? '')
    .replace(/\\/g, '/')
    .replace(/^\/+/, '')
    .trim();
  if (!cleaned) return { ok: false, abs: '', rel: '', reason: 'A file name is required.' };
  if (cleaned.length > 240) return { ok: false, abs: '', rel: '', reason: 'File name is too long.' };

  const segments = cleaned.split('/').filter(Boolean);
  if (segments.length === 0) return { ok: false, abs: '', rel: '', reason: 'A file name is required.' };
  if (segments.length > MAX_DEPTH) return { ok: false, abs: '', rel: '', reason: 'Folder depth is limited to 6.' };
  for (const seg of segments) {
    if (seg === '.' || seg === '..') return { ok: false, abs: '', rel: '', reason: 'Relative paths are not allowed in the Drive.' };
    if (seg.startsWith('.')) return { ok: false, abs: '', rel: '', reason: 'Hidden files are not allowed in the Drive.' };
    if (/[<>:"|?*\u0000-\u001f]/.test(seg)) return { ok: false, abs: '', rel: '', reason: `"${seg}" contains characters that are not safe for file names.` };
  }

  const base = path.join(DRIVE_ROOT, bucket);
  const abs = path.resolve(base, ...segments);
  if (abs !== base && !abs.startsWith(base + path.sep)) {
    return { ok: false, abs: '', rel: '', reason: 'That path tries to escape the JARVIS Drive.' };
  }
  return { ok: true, abs, rel: segments.join('/') };
}

export async function ensureBucket(bucket: string): Promise<string> {
  const dir = path.join(DRIVE_ROOT, bucket);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

export interface DriveEntry {
  name: string;
  size: number;
  mtime: number;
  isDir: boolean;
}

async function walk(dir: string, prefix: string, depth: number, out: DriveEntry[]): Promise<void> {
  if (out.length >= MAX_LIST_ENTRIES || depth > MAX_DEPTH) return;
  let entries: import('fs').Dirent[] = [];
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  entries.sort((a, b) => Number(b.isDirectory()) - Number(a.isDirectory()) || a.name.localeCompare(b.name));
  for (const e of entries) {
    if (out.length >= MAX_LIST_ENTRIES) return;
    if (e.name.startsWith('.')) continue;
    const rel = prefix ? `${prefix}/${e.name}` : e.name;
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) {
      out.push({ name: rel, size: 0, mtime: 0, isDir: true });
      await walk(abs, rel, depth + 1, out);
    } else if (e.isFile()) {
      try {
        const st = await fs.stat(abs);
        out.push({ name: rel, size: st.size, mtime: st.mtimeMs, isDir: false });
      } catch {
        /* raced away */
      }
    }
  }
}

export async function listDrive(bucket: string): Promise<DriveEntry[]> {
  const base = path.join(DRIVE_ROOT, bucket);
  const out: DriveEntry[] = [];
  await walk(base, '', 0, out);
  return out;
}

export async function writeDriveFile(bucket: string, name: string, content: string, append = false): Promise<{ rel: string; abs: string; size: number }> {
  const resolved = resolveDrivePath(bucket, name);
  if (!resolved.ok) throw new Error(resolved.reason!);
  const body = Buffer.from(String(content ?? ''), 'utf8');
  if (body.length > MAX_FILE_BYTES) throw new Error(`File is too large for the Drive (limit 3 MB, got ${(body.length / 1e6).toFixed(1)} MB).`);
  await fs.mkdir(path.dirname(resolved.abs), { recursive: true });
  if (append) await fs.appendFile(resolved.abs, body);
  else await fs.writeFile(resolved.abs, body);
  return { rel: resolved.rel, abs: resolved.abs, size: body.length };
}

export async function readDriveFile(bucket: string, name: string, capBytes = 400_000): Promise<{ rel: string; content: string; size: number; truncated: boolean }> {
  const resolved = resolveDrivePath(bucket, name);
  if (!resolved.ok) throw new Error(resolved.reason!);
  const st = await fs.stat(resolved.abs);
  if (st.isDirectory()) throw new Error(`"${resolved.rel}" is a folder, not a file.`);
  const raw = await fs.readFile(resolved.abs);
  const truncated = raw.length > capBytes;
  return { rel: resolved.rel, content: raw.subarray(0, capBytes).toString('utf8'), size: st.size, truncated };
}

export async function deleteDrivePath(bucket: string, name: string): Promise<{ rel: string; wasDir: boolean }> {
  const resolved = resolveDrivePath(bucket, name);
  if (!resolved.ok) throw new Error(resolved.reason!);
  if (resolved.rel === '' || resolved.rel === '.') throw new Error('The Drive root itself cannot be deleted.');
  const st = await fs.stat(resolved.abs).catch(() => null);
  if (!st) throw new Error(`"${resolved.rel}" does not exist in the Drive.`);
  await fs.rm(resolved.abs, { recursive: true, force: true });
  return { rel: resolved.rel, wasDir: st.isDirectory() };
}

export function contentTypeFor(name: string): string {
  const ext = path.extname(name).toLowerCase();
  const map: Record<string, string> = {
    '.html': 'text/html; charset=utf-8',
    '.htm': 'text/html; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.css': 'text/css; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.mjs': 'text/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.md': 'text/markdown; charset=utf-8',
    '.txt': 'text/plain; charset=utf-8',
    '.csv': 'text/csv; charset=utf-8',
    '.xml': 'application/xml; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.ico': 'image/x-icon',
    '.pdf': 'application/pdf',
  };
  return map[ext] ?? 'application/octet-stream';
}

/* ───────────────────── Minimal store-only ZIP writer ─────────────────────
   Zero dependencies, works on every platform. Drive files are text/small,
   so stored (uncompressed) entries keep the writer tiny and bulletproof. */

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function dosDateTime(d: Date): { time: number; date: number } {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}

export function makeZip(files: Array<{ name: string; data: Buffer; mtime?: Date }>): Buffer {
  const { time, date } = dosDateTime(new Date());
  const chunks: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = Buffer.from(file.name, 'utf8');
    const data = file.data;
    const crc = crc32(data);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4); // version needed
    local.writeUInt16LE(0x0800, 6); // UTF-8 names
    local.writeUInt16LE(0, 8); // stored
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBytes.length, 26);
    local.writeUInt16LE(0, 28);
    chunks.push(local, nameBytes, data);

    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0);
    cd.writeUInt16LE(20, 4); // version made by
    cd.writeUInt16LE(20, 6); // version needed
    cd.writeUInt16LE(0x0800, 8);
    cd.writeUInt16LE(0, 10);
    cd.writeUInt16LE(time, 12);
    cd.writeUInt16LE(date, 14);
    cd.writeUInt32LE(crc, 16);
    cd.writeUInt32LE(data.length, 20);
    cd.writeUInt32LE(data.length, 24);
    cd.writeUInt16LE(nameBytes.length, 28);
    cd.writeUInt16LE(0, 30);
    cd.writeUInt16LE(0, 32);
    cd.writeUInt16LE(0, 34);
    cd.writeUInt16LE(0, 36);
    cd.writeUInt32LE(0, 38);
    cd.writeUInt32LE(offset, 42);
    central.push(Buffer.concat([cd, nameBytes]));

    offset += local.length + nameBytes.length + data.length;
  }

  const centralBuf = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralBuf.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);

  return Buffer.concat([...chunks, centralBuf, end]);
}

/** Zip the whole bucket. Returns null when the Drive is empty. */
export async function zipDrive(bucket: string): Promise<Buffer | null> {
  const entries = await listDrive(bucket);
  const files = entries.filter((e) => !e.isDir).slice(0, 500);
  if (files.length === 0) return null;
  const payload: Array<{ name: string; data: Buffer; mtime?: Date }> = [];
  for (const f of files) {
    const resolved = resolveDrivePath(bucket, f.name);
    if (!resolved.ok) continue;
    try {
      const data = await fs.readFile(resolved.abs);
      payload.push({ name: `JARVIS-Drive/${f.name}`, data, mtime: new Date(f.mtime || Date.now()) });
    } catch {
      /* skip unreadable */
    }
  }
  return payload.length ? makeZip(payload) : null;
}

export function fmtSize(n: number): string {
  if (!Number.isFinite(n)) return '—';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}
