/**
 * JARVIS 53 — per-request tool context.
 * Carries the activated customer's identity into native tool handlers
 * without changing their signature, using Node's AsyncLocalStorage so
 * concurrent requests can never cross buckets.
 */
import { AsyncLocalStorage } from 'async_hooks';

export interface ToolContext {
  phone: string | null;
}

const storage = new AsyncLocalStorage<ToolContext>();

export function runInToolContext<T>(ctx: ToolContext, fn: () => Promise<T>): Promise<T> {
  return storage.run(ctx, fn);
}

export function currentPhone(): string | null {
  return storage.getStore()?.phone ?? null;
}
