/**
 * JARVIS 53 — JARVIS Drive tool handlers.
 * Real file creation + full website building that work on EVERY install —
 * macOS, Windows and the hosted website. Files land in the sandboxed
 * JARVIS Drive, where the customer can preview and download them
 * (Studio → Drive, or the buttons right on the chat tool card).
 */
import type { ExecResult } from '../os';
import { currentPhone } from './context';
import {
  driveBucket,
  listDrive,
  readDriveFile,
  writeDriveFile,
  deleteDrivePath,
  fmtSize,
} from '../drive';

type Args = Record<string, unknown>;
type Handler = (a: Args) => Promise<ExecResult>;

const ok = (stdout: string): ExecResult => ({ code: 0, stdout, stderr: '' });
const fail = (stderr: string): ExecResult => ({ code: 1, stdout: '', stderr });

const str = (a: Args, k: string, d = ''): string => (a[k] === undefined || a[k] === null ? d : String(a[k]));

function looksLikeHtml(content: string): boolean {
  return /<(!doctype|html|head|body|div|section|main|h1|script|style|nav|header|footer)\b/i.test(content);
}

const driveWrite: Handler = async (a) => {
  const name = str(a, 'name').trim();
  const content = str(a, 'content');
  const append = a.append === true || a.append === 'true';
  if (!name) return fail('A file name is required, e.g. "notes/ideas.md".');
  if (!content && !append) return fail('The "content" argument is empty — nothing to write.');
  try {
    const bucket = driveBucket(currentPhone());
    const res = await writeDriveFile(bucket, name, content, append);
    const previewable = /\.(html?|svg)$/i.test(name);
    return ok(
      `Saved ${res.rel} (${fmtSize(res.size)}) to your JARVIS Drive.` +
        (previewable ? ' Open Studio → Drive to see it live.' : '')
    );
  } catch (e) {
    return fail((e as Error).message);
  }
};

const driveSite: Handler = async (a) => {
  const name = str(a, 'name').trim() || 'site.html';
  const title = str(a, 'title').trim();
  const content = str(a, 'content');
  if (!content.trim()) return fail('The "content" argument must contain the complete website HTML.');
  if (!looksLikeHtml(content)) return fail('The content does not look like a website. Provide complete HTML starting with <!DOCTYPE html>.');
  const fileName = /\.(html?|htm)$/i.test(name) ? name : `${name.replace(/[\\/]+$/, '')}.html`;
  try {
    const bucket = driveBucket(currentPhone());
    const res = await writeDriveFile(bucket, fileName, content, false);
    const lines = content.split('\n').length;
    return ok(
      `Website built: ${res.rel} (${fmtSize(res.size)}, ${lines} lines)${title ? ` — "${title}"` : ''}. ` +
        `It is live in Studio → Drive with a one-click preview, and the whole Drive downloads as a zip.`
    );
  } catch (e) {
    return fail((e as Error).message);
  }
};

const driveList: Handler = async () => {
  try {
    const bucket = driveBucket(currentPhone());
    const entries = await listDrive(bucket);
    if (entries.length === 0) return ok('Your JARVIS Drive is empty. Ask me to build a website, write a file, or draft code and I will save it there.');
    const lines = entries.slice(0, 60).map((e) => (e.isDir ? `📁 ${e.name}/` : `📄 ${e.name} — ${fmtSize(e.size)}`));
    return ok(`JARVIS Drive (${entries.filter((e) => !e.isDir).length} files):\n${lines.join('\n')}\n\nBrowse everything in Studio → Drive.`);
  } catch (e) {
    return fail((e as Error).message);
  }
};

const driveRead: Handler = async (a) => {
  const name = str(a, 'name').trim();
  if (!name) return fail('A file name is required.');
  try {
    const bucket = driveBucket(currentPhone());
    const res = await readDriveFile(bucket, name, 6000);
    return ok(`${res.rel} (${fmtSize(res.size)}):\n\n${res.content}${res.truncated ? '\n\n… (truncated — open Studio → Drive for the full file)' : ''}`);
  } catch (e) {
    return fail((e as Error).message);
  }
};

const driveDelete: Handler = async (a) => {
  const name = str(a, 'name').trim();
  if (!name) return fail('A file name is required.');
  try {
    const bucket = driveBucket(currentPhone());
    const res = await deleteDrivePath(bucket, name);
    return ok(`Deleted ${res.rel} from your JARVIS Drive.`);
  } catch (e) {
    return fail((e as Error).message);
  }
};

const driveDownload: Handler = async () => {
  try {
    const bucket = driveBucket(currentPhone());
    const entries = await listDrive(bucket);
    const files = entries.filter((e) => !e.isDir);
    if (files.length === 0) return ok('Your JARVIS Drive is empty — nothing to download yet.');
    const total = files.reduce((n, f) => n + f.size, 0);
    return ok(`Your Drive holds ${files.length} file(s) (${fmtSize(total)}). Download the zip: Studio → Drive → "Download all", or the Download button on any Drive card.`);
  } catch (e) {
    return fail((e as Error).message);
  }
};

/** Platform-independent — installed into every OS handler map. */
export const DRIVE_HANDLERS: Record<string, Handler> = {
  'drive.write': driveWrite,
  'drive.site': driveSite,
  'drive.list': driveList,
  'drive.read': driveRead,
  'drive.delete': driveDelete,
  'drive.download': driveDownload,
};
