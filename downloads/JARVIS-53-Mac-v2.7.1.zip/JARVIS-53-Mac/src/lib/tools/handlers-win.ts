/**
 * JARVIS 53 — Windows native automation handlers.
 * PowerShell via execFile argv arrays; every user value is single-quote escaped
 * (escPs) — command injection is impossible by construction.
 */
import {
  execCmd, execShell, escPs, resolvePath, isPathSafe, safeToken, enc,
  fetchJson, fetchText, fmtBytes, toolUnavailable, HOME, spawnDetached,
} from '../os';
import type { ExecResult } from '../os';
import { promises as fs } from 'fs';
import { DRIVE_HANDLERS } from './handlers-drive';
import path from 'path';
import os from 'os';

type Args = Record<string, unknown>;
type Handler = (a: Args) => Promise<ExecResult>;

const ps = (script: string, timeoutMs = 20000): Promise<ExecResult> =>
  execCmd('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], timeoutMs);

const ok = (stdout: string): ExecResult => ({ code: 0, stdout, stderr: '' });
const fail = (stderr: string): ExecResult => ({ code: 1, stdout: '', stderr });
const sq = (s: string) => `'${escPs(s)}'`;

const str = (a: Args, k: string, d = ''): string => (a[k] === undefined || a[k] === null ? d : String(a[k]));
const num = (a: Args, k: string, d = 0): number => {
  const n = Number(a[k]);
  return Number.isFinite(n) ? n : d;
};
const appName = (a: Args) => safeToken(str(a, 'app'));

/* ── App Control ── */
const APP_MAP: Record<string, string> = {
  chrome: 'chrome', edge: 'msedge', firefox: 'firefox', spotify: 'spotify',
  notepad: 'notepad', calculator: 'calc', calc: 'calc', paint: 'mspaint',
  explorer: 'explorer', 'file explorer': 'explorer', terminal: 'wt',
  'vs code': 'code', vscode: 'code', word: 'winword', excel: 'excel',
  powerpoint: 'powerpnt', outlook: 'olk' , teams: 'teams', discord: 'discord',
  steam: 'steam', slack: 'slack', zoom: 'zoom', telegram: 'telegram',
};

const appsLaunch: Handler = async (a) => {
  const app = appName(a).toLowerCase();
  if (!app) return fail('No application name given.');
  const target = APP_MAP[app] ?? app;
  const r = await ps(`try { Start-Process ${sq(target)} -ErrorAction Stop; 'OK' } catch { try { Start-Process ${sq(app)} -ErrorAction Stop; 'OK' } catch { 'FAIL' } }`, 15000);
  if (r.stdout.includes('OK')) return ok(`${str(a, 'app')} is launching.`);
  return fail(`Couldn't launch "${str(a, 'app')}". Is it installed and on PATH?`);
};

const appsQuit: Handler = async (a) => {
  const name = appName(a);
  const r = await ps(`Get-Process -Name *${escPs(name)}* -ErrorAction SilentlyContinue | ForEach-Object { $_.CloseMainWindow() } | Out-Null; 'DONE'`);
  return r.stdout.includes('DONE') ? ok(`${name} closed gracefully.`) : fail(`No windows found for ${name}.`);
};

const appsForceQuit: Handler = async (a) => {
  const name = appName(a);
  const r = await ps(`Stop-Process -Name *${escPs(name)}* -Force -ErrorAction SilentlyContinue; 'DONE'`);
  return r.stdout.includes('DONE') ? ok(`${name} was force-quit.`) : fail(`No process matched ${name}.`);
};

const appsListRunning: Handler = async () => {
  const r = await ps(`Get-Process | Where-Object { $_.MainWindowTitle } | Select-Object -Unique ProcessName | ForEach-Object { $_.ProcessName } | Sort-Object | Out-String`, 20000);
  const names = r.stdout.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  return names.length ? ok(`Running apps (${names.length}): ${names.join(', ')}`) : fail('Could not enumerate running apps.');
};

const appsActivate: Handler = async (a) => {
  return appsLaunch(a);
};

const appsFrontmost: Handler = async () => {
  const script = [
    "Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class FW { [DllImport(\"user32.dll\")] public static extern IntPtr GetForegroundWindow(); }'",
    '$p = Get-Process | Where-Object { $_.MainWindowHandle -eq [FW]::GetForegroundWindow() } | Select-Object -First 1',
    '$p.ProcessName',
  ].join('; ');
  const r = await ps(script, 15000);
  const name = r.stdout.trim();
  return name ? ok(`Active app: ${name}`) : fail('Could not read active window.');
};

const appsInstall: Handler = async (a) => {
  const pkg = safeToken(str(a, 'app'));
  const r = await execShell(`winget install --id ${pkg.replace(/["'|;&<>]/g, '')} --silent --accept-package-agreements --accept-source-agreements`, 600000);
  return r.code === 0 ? ok(`Installed ${pkg} via winget.`) : fail(r.stdout.slice(-400) || r.stderr.slice(-400) || `winget could not install ${pkg}.`);
};

/* ── System ── */
async function sendKey(ch: number, times = 1): Promise<void> {
  await ps(`$s = New-Object -ComObject WScript.Shell; 1..${times} | ForEach-Object { $s.SendKeys([char]${ch}) }`, 15000);
}

const systemVolume: Handler = async (a) => {
  const level = Math.max(0, Math.min(100, Math.round(num(a, 'level', 40))));
  const ups = Math.ceil(50);
  await ps(`$s = New-Object -ComObject WScript.Shell; 1..${ups} | ForEach-Object { $s.SendKeys([char]174) }; 1..${Math.round(level / 2)} | ForEach-Object { $s.SendKeys([char]175) }`, 30000);
  return ok(`Volume set to roughly ${level}%.`);
};

const systemMute: Handler = async () => {
  await sendKey(173);
  return ok('Muted.');
};

const systemUnmute: Handler = async () => {
  await sendKey(173);
  return ok('Toggled mute state (if it was muted, sound is back).');
};

const systemBrightness: Handler = async (a) => {
  const level = Math.max(0, Math.min(100, Math.round(num(a, 'level', 50))));
  const r = await ps(`(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1, ${level}); 'OK'`, 15000);
  return r.stdout.includes('OK') ? ok(`Brightness set to ${level}%.`) : fail('This display does not expose software brightness (external monitors use hardware buttons).');
};

const systemDarkMode: Handler = async (a) => {
  const mode = (str(a, 'mode', 'toggle') || 'toggle').toLowerCase();
  let target: string;
  if (mode === 'toggle') {
    const cur = await ps(`(Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize').AppsUseLightTheme`);
    target = cur.stdout.trim() === '1' ? '0' : '1';
  } else target = mode === 'dark' ? '0' : '1';
  await ps(`Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize' -Name AppsUseLightTheme -Value ${target}; Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize' -Name SystemUsesLightTheme -Value ${target}`);
  return ok(`Switched to ${target === '0' ? 'Dark' : 'Light'} mode (may take a beat to apply).`);
};

const systemLock: Handler = async () => {
  spawnDetached('rundll32.exe', ['user32.dll,LockWorkStation']);
  return ok('Screen locked.');
};

const systemSleep: Handler = async () => {
  spawnDetached('rundll32.exe', ['powrprof.dll,SetSuspendState 0,1,0']);
  return ok('Going to sleep. Goodnight.');
};

const systemRestart: Handler = async () => {
  await execShell('shutdown /r /t 1');
  return ok('Restarting now.');
};

const systemShutdown: Handler = async () => {
  await execShell('shutdown /s /t 1');
  return ok('Shutting down.');
};

const systemBattery: Handler = async () => {
  const r = await ps(`$b = Get-WmiObject Win32_Battery; if ($b) { "$($b.EstimatedChargeRemaining)% | Status: $($b.BatteryStatus)" } else { 'NO_BATTERY' }`);
  if (r.stdout.includes('NO_BATTERY')) return ok('No battery detected — this looks like a desktop PC on mains power.');
  return ok(`Battery: ${r.stdout.trim()}`);
};

const systemWifi: Handler = async () => {
  const r = await execShell('netsh wlan show interfaces');
  if (r.code !== 0) return ok('Wi-Fi adapter status unavailable via netsh.');
  const ssid = r.stdout.match(/SSID\s*:\s*(.+)/);
  const state = r.stdout.match(/State\s*:\s*(.+)/);
  if (ssid) return ok(`Wi-Fi ${state?.[1]?.trim() ?? ''} — network: ${ssid[1].trim()}`);
  return ok('Wi-Fi is not connected.');
};

const systemScreensaver: Handler = async () => {
  await ps(`Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class SS { [DllImport("user32.dll")] public static extern int SendMessage(int hWnd, int hMsg, int wParam, int lParam); }'; [SS]::SendMessage(0xFFFF, 0x0112, 0xF140, 0) | Out-Null; 'OK'`);
  return ok('Screensaver started.');
};

const systemEmptyTrash: Handler = async () => {
  await ps('Clear-RecycleBin -Force -ErrorAction SilentlyContinue; "DONE"');
  return ok('Recycle Bin emptied.');
};

const systemInfo: Handler = async () => {
  const total = os.totalmem(), free = os.freemem();
  const r = await ps(`$os = Get-CimInstance Win32_OperatingSystem; $c = Get-CimInstance Win32_Processor | Select-Object -First 1; $d = Get-PSDrive C | ForEach-Object { [math]::Round($_.Used/1GB,1) }; $t = Get-PSDrive C | ForEach-Object { [math]::Round(($_.Used+$_.Free)/1GB,1) }; "$($c.Name) x$($c.NumberOfCores) | $($os.Caption) | RAM used $([math]::Round(($os.TotalVisibleMemorySize-$os.FreePhysicalMemory)/1MB,1))/$([math]::Round($os.TotalVisibleMemorySize/1MB,1)) GB | Disk C: $d/$t GB used | Boot: $($os.LastBootUpTime)"`, 25000);
  return ok(r.stdout.trim() ? `System Report — ${r.stdout.trim()}` : `System Report — ${os.type()} ${os.release()} (${os.arch()}), RAM ${fmtBytes(total - free)}/${fmtBytes(total)} used.`);
};

/* ── Files ── */
const filesList: Handler = async (a) => {
  const dir = resolvePath(str(a, 'path', '~'));
  const guard = isPathSafe(dir);
  if (!guard.safe) return fail(guard.reason!);
  const r = await ps(`Get-ChildItem -Force -Path ${sq(dir)} -ErrorAction SilentlyContinue | Select-Object -First 60 | ForEach-Object { if ($_.PSIsContainer) { "📁 $($_.Name)" } else { "📄 $($_.Name) — $([math]::Round($_.Length/1KB,1)) KB" } } | Out-String`, 20000);
  const items = r.stdout.split(/\r?\n/).filter(Boolean);
  return items.length ? ok(`${dir}\n\n${items.join('\n')}`) : fail(`Can't list ${dir} (missing or empty).`);
};

const filesRead: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const r = await ps(`Get-Content -Raw -Path ${sq(p)} -ErrorAction Stop`, 15000);
  return r.code === 0 ? ok(`${p}\n\n${r.stdout.slice(0, 8000)}`) : fail(`Can't read ${p}: ${r.stderr.trim().slice(0, 200)}`);
};

const filesWrite: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const content = str(a, 'content');
  const append = a.append === true || a.append === 'true';
  try {
    await fs.mkdir(path.dirname(p), { recursive: true });
    await (append ? fs.appendFile(p, `\n${content}`, 'utf8') : fs.writeFile(p, content, 'utf8'));
    return ok(`${append ? 'Appended to' : 'Wrote'} ${p} (${fmtBytes(Buffer.byteLength(content))}).`);
  } catch (e) {
    return fail(`Write failed: ${(e as Error).message}`);
  }
};

const filesSearch: Handler = async (a) => {
  const q = str(a, 'query').trim();
  if (!q) return fail('Empty search query.');
  const folder = a.folder ? resolvePath(str(a, 'folder')) : path.join(HOME, 'Documents');
  const guard = isPathSafe(folder);
  if (!guard.safe) return fail(guard.reason!);
  const r = await ps(`Get-ChildItem -Path ${sq(folder)} -Recurse -Depth 3 -Filter *${escPs(q.replace(/[*?"|<>]/g, ''))}* -ErrorAction SilentlyContinue | Select-Object -First 25 -ExpandProperty FullName | Out-String`, 30000);
  const items = r.stdout.split(/\r?\n/).filter(Boolean);
  return items.length ? ok(`Found ${items.length} match(es):\n${items.join('\n')}`) : ok(`No files matching "${q}" in ${folder} (searched 3 levels deep).`);
};

const filesMkdir: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  await fs.mkdir(p, { recursive: true });
  return ok(`Created folder ${p}.`);
};

const filesCopy: Handler = async (a) => {
  const from = resolvePath(str(a, 'from'));
  const to = resolvePath(str(a, 'to'));
  for (const p of [from, to]) {
    const guard = isPathSafe(p);
    if (!guard.safe) return fail(guard.reason!);
  }
  await fs.copyFile(from, to).catch(async () => {
    await ps(`Copy-Item ${sq(from)} ${sq(to)} -Recurse -Force; 'OK'`, 60000);
  });
  return ok(`Copied → ${to}`);
};

const filesMove: Handler = async (a) => {
  const from = resolvePath(str(a, 'from'));
  const to = resolvePath(str(a, 'to'));
  for (const p of [from, to]) {
    const guard = isPathSafe(p);
    if (!guard.safe) return fail(guard.reason!);
  }
  await fs.rename(from, to).catch(async () => {
    await ps(`Move-Item ${sq(from)} ${sq(to)} -Force; 'OK'`, 60000);
  });
  return ok(`Moved → ${to}`);
};

const filesDelete: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const r = await ps(`Add-Type -AssemblyName Microsoft.VisualBasic; if (Test-Path -PathType Container ${sq(p)}) { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory(${sq(p)}, 'OnlyErrorDialogs', 'SendToRecycleBin') } else { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile(${sq(p)}, 'OnlyErrorDialogs', 'SendToRecycleBin') }; 'TRASHED'`, 20000);
  return r.stdout.includes('TRASHED') ? ok(`Moved ${p} to Recycle Bin (recoverable).`) : fail(`Delete failed: ${r.stderr.trim().slice(0, 200)}`);
};

const filesZip: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const out = `${p}.zip`;
  const r = await ps(`Compress-Archive -Path ${sq(p)} -DestinationPath ${sq(out)} -Force; 'OK'`, 120000);
  return r.stdout.includes('OK') ? ok(`Compressed → ${out}`) : fail(`Zip failed: ${r.stderr.trim().slice(0, 200)}`);
};

const filesUnzip: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const dest = p.replace(/\.zip$/i, '');
  await fs.mkdir(dest, { recursive: true });
  const r = await ps(`Expand-Archive -Path ${sq(p)} -DestinationPath ${sq(dest)} -Force; 'OK'`, 120000);
  return r.stdout.includes('OK') ? ok(`Extracted → ${dest}`) : fail(`Unzip failed: ${r.stderr.trim().slice(0, 200)}`);
};

const filesInfo: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  try {
    const st = await fs.stat(p);
    return ok(`${p}\nType: ${st.isDirectory() ? 'Folder' : 'File'}\nSize: ${fmtBytes(st.size)}\nModified: ${st.mtime.toLocaleString()}\nCreated: ${st.birthtime.toLocaleString()}`);
  } catch (e) {
    return fail(`Can't stat ${p}: ${(e as Error).message}`);
  }
};

const filesReveal: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  spawnDetached('explorer.exe', [`/select,${p}`]);
  return ok(`Revealed in Explorer: ${p}`);
};

const filesOpenTerminal: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  spawnDetached('cmd.exe', ['/c', 'start', 'cmd', '/k', `cd /d ${p}`]);
  return ok(`Terminal opened at ${p}`);
};

const filesRecent: Handler = async () => {
  const dir = path.join(HOME, 'Downloads');
  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const withTime = await Promise.all(
      entries.filter((e) => !e.name.startsWith('.')).map(async (e) => {
        const st = await fs.stat(path.join(dir, e.name)).catch(() => null);
        return st ? { name: e.name, mtime: st.mtime, size: st.size } : null;
      })
    );
    const sorted = withTime.filter(Boolean).sort((x, y) => y!.mtime.getTime() - x!.mtime.getTime()).slice(0, 15);
    return ok(sorted.length ? `Newest in Downloads:\n${sorted.map((f) => `• ${f!.name} — ${fmtBytes(f!.size)} (${f!.mtime.toLocaleDateString()})`).join('\n')}` : 'Downloads is empty.');
  } catch (e) {
    return fail(`Can't read Downloads: ${(e as Error).message}`);
  }
};

/* ── Clipboard ── */
const clipboardGet: Handler = async () => {
  const r = await ps('Get-Clipboard -Raw | Out-String', 10000);
  return r.stdout.trim() ? ok(`Clipboard: ${r.stdout.trim().slice(0, 1500)}`) : ok('Clipboard is empty.');
};

const clipboardSet: Handler = async (a) => {
  const text = str(a, 'text');
  const r = await ps(`Set-Clipboard -Value ${sq(text)}; 'OK'`, 10000);
  return r.stdout.includes('OK') ? ok('Copied to clipboard.') : fail('Clipboard copy failed.');
};

/* ── Media (media keys) ── */
const mediaPlayPause: Handler = async () => {
  await sendKey(179);
  return ok('Toggled play/pause.');
};
const mediaNext: Handler = async () => {
  await sendKey(176);
  return ok('Skipped forward.');
};
const mediaPrevious: Handler = async () => {
  await sendKey(177);
  return ok('Skipped back.');
};

const mediaPlaySearch: Handler = async (a) => {
  const query = str(a, 'query').trim();
  const service = (str(a, 'service', 'spotify') || 'spotify').toLowerCase().replace(/\s/g, '_');
  if (!query) return fail('What should I play?');
  if (service === 'youtube') {
    spawnDetached('cmd.exe', ['/c', 'start', '', `https://www.youtube.com/results?search_query=${enc(query)}`]);
    return ok(`Opened YouTube search for "${query}".`);
  }
  if (service === 'apple_music' || service === 'music') {
    spawnDetached('cmd.exe', ['/c', 'start', '', `https://music.apple.com/us/search?term=${enc(query)}`]);
    return ok(`Opened Apple Music search for "${query}".`);
  }
  const r = await ps(`Start-Process ${sq('spotify:search:' + query)} -ErrorAction SilentlyContinue; 'OK'`, 10000);
  if (r.stdout.includes('OK')) return ok(`Requested Spotify to play "${query}".`);
  spawnDetached('cmd.exe', ['/c', 'start', '', `https://open.spotify.com/search/${enc(query)}`]);
  return ok(`Opened Spotify search for "${query}".`);
};

/* ── Windows/WM ── */
const windowSnapLeft: Handler = async () => {
  await ps(`$s = New-Object -ComObject WScript.Shell; $s.SendKeys('#{LEFT}'); 'OK'`, 10000);
  return ok('Snapped front window to the left half.');
};

const windowSnapRight: Handler = async () => {
  await ps(`$s = New-Object -ComObject WScript.Shell; $s.SendKeys('#{RIGHT}'); 'OK'`, 10000);
  return ok('Snapped front window to the right half.');
};

const windowHideOthers: Handler = async () => {
  await ps(`$s = New-Object -ComObject WScript.Shell; $s.SendKeys('#{HOME}'); 'OK'`, 10000);
  return ok('Everything else minimized. Focus mode engaged.');
};

const windowCloseFront: Handler = async () => {
  await ps(`$s = New-Object -ComObject WScript.Shell; $s.SendKeys('%{F4}'); 'OK'`, 10000);
  return ok('Closed the front window.');
};

/* ── Comms ── */
const emailDraft: Handler = async (a) => {
  const to = safeToken(str(a, 'to'));
  const subject = str(a, 'subject', '(no subject)');
  const body = str(a, 'body');
  if (!to.includes('@')) return fail("That doesn't look like a valid email address.");
  const mailto = `mailto:${enc(to)}?subject=${enc(subject)}&body=${enc(body)}`;
  const r = await ps(`Start-Process ${sq(mailto)}; 'OK'`, 10000);
  return r.stdout.includes('OK') ? ok(`Draft prepared in your mail app for ${to} — review and hit send. I never send email without you.`) : fail('No default mail client found.');
};

const whatsappCompose: Handler = async (a) => {
  const phone = str(a, 'phone').replace(/[^\d+]/g, '');
  const message = str(a, 'message');
  if (!/^\+?\d{8,15}$/.test(phone)) return fail('Phone must be an international number, e.g. +919876543210.');
  const url = `https://wa.me/${phone.replace(/^\+/, '')}?text=${enc(message)}`;
  const r = await ps(`Start-Process ${sq(url)}; 'OK'`, 10000);
  return r.stdout.includes('OK') ? ok(`WhatsApp opened for ${phone} — message loaded, ready for your review.`) : fail('Could not open WhatsApp.');
};

/* ── Productivity (Reminders unavailable → JARVIS vault files) ── */
async function vaultFile(kind: 'tasks' | 'notes'): Promise<string> {
  const dir = path.join(HOME, 'Documents', 'JARVIS53');
  await fs.mkdir(dir, { recursive: true });
  return path.join(dir, `${kind}.txt`);
}

const notesAdd: Handler = async (a) => {
  const title = str(a, 'title', 'JARVIS Note');
  const body = str(a, 'body');
  const f = await vaultFile('notes');
  await fs.appendFile(f, `\n=== ${title} — ${new Date().toLocaleString()} ===\n${body}\n`, 'utf8');
  return ok(`Note "${title}" saved to your JARVIS vault (Documents\\JARVIS53\\notes.txt).`);
};

const notesList: Handler = async () => {
  const f = await vaultFile('notes');
  const content = await fs.readFile(f, 'utf8').catch(() => '');
  const titles = content.split('\n').filter((l) => l.startsWith('===')).slice(-15).reverse();
  return titles.length ? ok(`Your ${titles.length} most recent notes:\n${titles.map((t) => `• ${t.replace(/===/g, '').trim()}`).join('\n')}`) : ok('No notes yet.');
};

const remindersCreate: Handler = async (a) => tasksCreate(a);
const remindersList: Handler = async (a) => tasksList(a);

const tasksCreate: Handler = async (a) => {
  const title = str(a, 'title');
  const f = await vaultFile('tasks');
  await fs.appendFile(f, `[ ] ${title} — ${new Date().toLocaleString()}\n`, 'utf8');
  return ok(`Task "${title}" added to your JARVIS task vault.`);
};

const tasksList: Handler = async () => {
  const f = await vaultFile('tasks');
  const content = await fs.readFile(f, 'utf8').catch(() => '');
  const lines = content.split('\n').filter((l) => l.startsWith('[ ]')).slice(-20);
  return lines.length ? ok(`Open tasks:\n${lines.join('\n')}`) : ok('No open tasks.');
};

const calendarCreate: Handler = async (a) => {
  const title = str(a, 'title');
  const dateStr = str(a, 'date');
  const timeStr = str(a, 'time', '09:00');
  const minutes = Math.max(5, num(a, 'minutes', 60));
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return fail('Date must be YYYY-MM-DD.');
  if (!/^\d{2}:\d{2}$/.test(timeStr)) return fail('Time must be HH:MM (24h).');
  const [h, m] = timeStr.split(':').map(Number);
  const start = new Date(`${dateStr}T${timeStr}:00`);
  const end = new Date(start.getTime() + minutes * 60000);
  const fmt = (d: Date) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const dir = path.join(HOME, 'Documents', 'JARVIS53');
  await fs.mkdir(dir, { recursive: true });
  const ics = path.join(dir, `event-${Date.now()}.ics`);
  await fs.writeFile(
    ics,
    `BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//JARVIS53//EN\nBEGIN:VEVENT\nUID:${Date.now()}@jarvis53\nDTSTAMP:${fmt(new Date())}\nDTSTART:${fmt(start)}\nDTEND:${fmt(end)}\nSUMMARY:${title}\nEND:VEVENT\nEND:VCALENDAR`,
    'utf8'
  );
  await ps(`Start-Process ${sq(ics)}; 'OK'`, 10000);
  return ok(`Event "${title}" created (${dateStr} ${timeStr}, ${minutes} min) and opened in your calendar app. Hour ${h}:${m}.`);
};

/* ── Web ── */
const webOpen: Handler = async (a) => {
  let url = str(a, 'url').trim();
  if (!/^https?:\/\//i.test(url)) {
    if (/^[\w.-]+\.[a-z]{2,}(\/.*)?$/i.test(url)) url = `https://${url}`;
    else return fail("That doesn't look like a valid URL.");
  }
  const r = await ps(`Start-Process ${sq(url)}; 'OK'`, 10000);
  return r.stdout.includes('OK') ? ok(`Opened ${url}`) : fail('Could not open the browser.');
};

const webSearch: Handler = async (a) => {
  const q = str(a, 'query');
  await webOpen({ url: `https://www.google.com/search?q=${enc(q)}` });
  return ok(`Searched Google for "${q}".`);
};

const webYoutube: Handler = async (a) => {
  const q = str(a, 'query');
  await webOpen({ url: `https://www.youtube.com/results?search_query=${enc(q)}` });
  return ok(`Searching YouTube for "${q}".`);
};

/* ── Info (network) ── */
const infoTime: Handler = async () => ok(new Date().toLocaleString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }));

const infoWeather: Handler = async (a) => {
  const city = enc(str(a, 'city', '') || '');
  const data = await fetchJson<{ current_condition: Array<{ temp_C: string; FeelsLikeC: string; humidity: string; weatherDesc: Array<{ value: string }>; windspeedKmph: string }> }>(`https://wttr.in/${city}?format=j1`);
  if (!data?.current_condition?.[0]) return fail('Weather service unreachable.');
  const c = data.current_condition[0];
  return ok(`Weather: ${c.weatherDesc[0].value}, ${c.temp_C}°C (feels like ${c.FeelsLikeC}°C), humidity ${c.humidity}%, wind ${c.windspeedKmph} km/h${city ? ` — ${decodeURIComponent(city)}` : ''}`);
};

const infoNews: Handler = async () => {
  const xml = await fetchText('https://feeds.bbci.co.uk/news/world/rss.xml');
  if (!xml) return fail('News service unreachable.');
  const titles = [...xml.matchAll(/<title>(<!\[CDATA\[)?(.*?)(\]\]>)?<\/title>/g)].map((m) => m[2]).slice(1, 9);
  return ok(`Top headlines:\n${titles.map((t, i) => `${i + 1}. ${t}`).join('\n')}`);
};

const infoWiki: Handler = async (a) => {
  const q = enc(str(a, 'query').trim().replace(/\s+/g, '_'));
  const data = await fetchJson<{ extract: string; title: string }>(`https://en.wikipedia.org/api/rest_v1/page/summary/${q}`);
  if (!data?.extract) return fail(`No Wikipedia entry found for "${str(a, 'query')}".`);
  return ok(`${data.title} — ${data.extract.slice(0, 900)}`);
};

const infoIp: Handler = async () => {
  const data = await fetchJson<{ ip: string }>('https://api.ipify.org?format=json');
  return data?.ip ? ok(`Your public IP: ${data.ip}`) : fail('Network unreachable.');
};

const infoCurrency: Handler = async (a) => {
  const from = str(a, 'from', 'USD').toUpperCase().slice(0, 3);
  const to = str(a, 'to', 'INR').toUpperCase().slice(0, 3);
  const amount = num(a, 'amount', 1);
  const data = await fetchJson<{ rates: Record<string, number> }>(`https://open.er-api.com/v6/latest/${from}`);
  if (!data?.rates?.[to]) return fail(`Couldn't fetch ${from}→${to} rate.`);
  const rate = data.rates[to];
  return ok(`${amount} ${from} = ${(amount * rate).toFixed(2)} ${to} (live rate ${rate.toFixed(4)})`);
};

/* ── Text ── */
const textSpeak: Handler = async (a) => {
  const text = str(a, 'text').slice(0, 500);
  spawnDetached('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak(${sq(text)})`]);
  return ok(`Spoken: "${text.slice(0, 80)}${text.length > 80 ? '…' : ''}"`);
};

/* ── Dev ── */
const devOpenVscode: Handler = async (a) => {
  const p = resolvePath(str(a, 'path', '~'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const r = await ps(`Start-Process code -ArgumentList ${sq(p)} -ErrorAction SilentlyContinue; 'OK'`, 10000);
  return r.stdout.includes('OK') ? ok(`VS Code opened at ${p}`) : fail('VS Code not found — install it from https://code.visualstudio.com');
};

const devGitStatus: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const branch = await execCmd('git', ['-C', p, 'branch', '--show-current']);
  if (branch.code !== 0) return fail('Not a git repository (or git is not installed).');
  const st = await execCmd('git', ['-C', p, 'status', '--porcelain']);
  const lines = st.stdout.split('\n').filter(Boolean);
  return ok(`Repository: ${p}\nBranch: ${branch.stdout.trim() || 'detached'}\nChanges: ${lines.length}\n${lines.slice(0, 20).map((l) => `• ${l}`).join('\n')}`);
};

export const WIN_HANDLERS: Record<string, Handler> = {
  ...DRIVE_HANDLERS,
  'apps.launch': appsLaunch,
  'apps.quit': appsQuit,
  'apps.force_quit': appsForceQuit,
  'apps.list_running': appsListRunning,
  'apps.activate': appsActivate,
  'apps.frontmost': appsFrontmost,
  'apps.install': appsInstall,
  'system.volume': systemVolume,
  'system.mute': systemMute,
  'system.unmute': systemUnmute,
  'system.brightness': systemBrightness,
  'system.dark_mode': systemDarkMode,
  'system.lock': systemLock,
  'system.sleep': systemSleep,
  'system.restart': systemRestart,
  'system.shutdown': systemShutdown,
  'system.battery': systemBattery,
  'system.wifi': systemWifi,
  'system.screensaver': systemScreensaver,
  'system.empty_trash': systemEmptyTrash,
  'system.info': systemInfo,
  'files.list': filesList,
  'files.read': filesRead,
  'files.write': filesWrite,
  'files.search': filesSearch,
  'files.mkdir': filesMkdir,
  'files.copy': filesCopy,
  'files.move': filesMove,
  'files.delete': filesDelete,
  'files.zip': filesZip,
  'files.unzip': filesUnzip,
  'files.info': filesInfo,
  'files.reveal': filesReveal,
  'files.open_terminal': filesOpenTerminal,
  'files.recent': filesRecent,
  'clipboard.get': clipboardGet,
  'clipboard.set': clipboardSet,
  'media.play_pause': mediaPlayPause,
  'media.next': mediaNext,
  'media.previous': mediaPrevious,
  'media.play_search': mediaPlaySearch,
  'window.snap_left': windowSnapLeft,
  'window.snap_right': windowSnapRight,
  'window.hide_others': windowHideOthers,
  'window.close_front': windowCloseFront,
  'email.draft': emailDraft,
  'whatsapp.compose': whatsappCompose,
  'notes.add': notesAdd,
  'notes.list': notesList,
  'reminders.create': remindersCreate,
  'reminders.list': remindersList,
  'calendar.create': calendarCreate,
  'tasks.create': tasksCreate,
  'tasks.list': tasksList,
  'web.open': webOpen,
  'web.search': webSearch,
  'web.youtube': webYoutube,
  'info.time': infoTime,
  'info.weather': infoWeather,
  'info.news': infoNews,
  'info.wiki': infoWiki,
  'info.ip': infoIp,
  'info.currency': infoCurrency,
  'text.speak': textSpeak,
  'dev.open_vscode': devOpenVscode,
  'dev.git_status': devGitStatus,
};

export const WIN_UNSUPPORTED: Record<string, ExecResult> = {
  'imessage.send': toolUnavailable('imessage.send', 'mac'),
  'media.now_playing': toolUnavailable('media.now_playing', 'mac'),
};
