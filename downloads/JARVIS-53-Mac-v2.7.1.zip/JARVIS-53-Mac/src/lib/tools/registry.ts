/**
 * JARVIS 53 — Tool Registry.
 * Every automation JARVIS can perform on the customer's machine.
 * Risk tiers: low = autonomous, medium = inline confirm, high = explicit confirm.
 */

export type Risk = 'low' | 'medium' | 'high';
export type Platform = 'mac' | 'win';
export type AnyPlatform = Platform | 'linux';

export interface ToolArg {
  name: string;
  type: 'string' | 'number' | 'boolean';
  required: boolean;
  desc: string;
  example?: string;
}

export interface ToolDef {
  id: string;
  name: string;
  category: 'App Control' | 'System' | 'Files' | 'Drive' | 'Clipboard' | 'Media' | 'Windows' | 'Comms' | 'Productivity' | 'Web' | 'Info' | 'Text' | 'Dev';
  desc: string;
  risk: Risk;
  os: Platform[]; // platforms with a real native handler
  args: ToolArg[];
  confirm?: string; // custom confirmation phrase for high-risk tools
}

export const TOOLS: ToolDef[] = [
  /* ── App Control ── */
  { id: 'apps.launch', name: 'Launch App', category: 'App Control', desc: 'Open any installed application by name.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'app', type: 'string', required: true, desc: 'App name, e.g. Spotify, Chrome, Safari, Word', example: 'Spotify' }] },
  { id: 'apps.quit', name: 'Quit App', category: 'App Control', desc: 'Gracefully close an application.', risk: 'medium', os: ['mac', 'win'], args: [{ name: 'app', type: 'string', required: true, desc: 'App name', example: 'Chrome' }] },
  { id: 'apps.force_quit', name: 'Force Quit App', category: 'App Control', desc: 'Kill an unresponsive application immediately.', risk: 'high', os: ['mac', 'win'], args: [{ name: 'app', type: 'string', required: true, desc: 'App/process name' }] },
  { id: 'apps.list_running', name: 'List Running Apps', category: 'App Control', desc: 'See every app currently running.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'apps.activate', name: 'Focus App', category: 'App Control', desc: 'Bring an app to the foreground.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'app', type: 'string', required: true, desc: 'App name' }] },
  { id: 'apps.frontmost', name: 'Active App', category: 'App Control', desc: 'Report which app is currently focused.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'apps.install', name: 'Install App', category: 'App Control', desc: 'Install software via Homebrew (Mac) or winget (Windows).', risk: 'high', os: ['mac', 'win'], args: [{ name: 'app', type: 'string', required: true, desc: 'Package name, e.g. figma, zoom' }] },

  /* ── System ── */
  { id: 'system.volume', name: 'Set Volume', category: 'System', desc: 'Set speaker volume 0–100.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'level', type: 'number', required: true, desc: '0–100', example: '40' }] },
  { id: 'system.mute', name: 'Mute', category: 'System', desc: 'Mute the speakers.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'system.unmute', name: 'Unmute', category: 'System', desc: 'Restore speaker audio.', risk: 'low', os: ['mac'], args: [] },
  { id: 'system.brightness', name: 'Set Brightness', category: 'System', desc: 'Adjust display brightness 0–100 (built-in displays).', risk: 'low', os: ['win'], args: [{ name: 'level', type: 'number', required: true, desc: '0–100' }] },
  { id: 'system.dark_mode', name: 'Appearance', category: 'System', desc: 'Switch dark / light mode.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'mode', type: 'string', required: false, desc: 'dark | light | toggle', example: 'dark' }] },
  { id: 'system.lock', name: 'Lock Screen', category: 'System', desc: 'Lock the computer instantly.', risk: 'medium', os: ['mac', 'win'], args: [] },
  { id: 'system.sleep', name: 'Sleep', category: 'System', desc: 'Put the machine to sleep.', risk: 'medium', os: ['mac', 'win'], args: [] },
  { id: 'system.restart', name: 'Restart', category: 'System', desc: 'Restart the computer.', risk: 'high', os: ['mac', 'win'], args: [], confirm: 'restart this computer' },
  { id: 'system.shutdown', name: 'Shut Down', category: 'System', desc: 'Power the computer off.', risk: 'high', os: ['mac', 'win'], args: [], confirm: 'shut down this computer' },
  { id: 'system.battery', name: 'Battery Status', category: 'System', desc: 'Battery level and charging state.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'system.wifi', name: 'Wi-Fi Status', category: 'System', desc: 'Current network and connection state.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'system.screensaver', name: 'Start Screensaver', category: 'System', desc: 'Kick off the screensaver.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'system.empty_trash', name: 'Empty Trash', category: 'System', desc: 'Permanently empty Trash / Recycle Bin.', risk: 'high', os: ['mac', 'win'], args: [], confirm: 'permanently empty the Trash' },
  { id: 'system.info', name: 'System Report', category: 'System', desc: 'CPU, memory, disk, uptime, OS version.', risk: 'low', os: ['mac', 'win'], args: [] },

  /* ── Files ── */
  { id: 'files.list', name: 'List Folder', category: 'Files', desc: 'List files in a folder (~ = home).', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: false, desc: 'Folder path (default home)' }] },
  { id: 'files.read', name: 'Read File', category: 'Files', desc: 'Read a text file.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'File path' }] },
  { id: 'files.write', name: 'Write File', category: 'Files', desc: 'Create or overwrite a text file.', risk: 'medium', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'File path' }, { name: 'content', type: 'string', required: true, desc: 'Text to write' }, { name: 'append', type: 'boolean', required: false, desc: 'Append instead of overwrite' }] },
  { id: 'files.search', name: 'Search Files', category: 'Files', desc: 'Spotlight-speed search across your Mac / drives.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'query', type: 'string', required: true, desc: 'Filename search' }, { name: 'folder', type: 'string', required: false, desc: 'Limit to folder' }] },
  { id: 'files.mkdir', name: 'New Folder', category: 'Files', desc: 'Create a folder.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'Folder path' }] },
  { id: 'files.copy', name: 'Copy File', category: 'Files', desc: 'Copy a file or folder.', risk: 'medium', os: ['mac', 'win'], args: [{ name: 'from', type: 'string', required: true, desc: 'Source path' }, { name: 'to', type: 'string', required: true, desc: 'Destination path' }] },
  { id: 'files.move', name: 'Move File', category: 'Files', desc: 'Move or rename a file or folder.', risk: 'medium', os: ['mac', 'win'], args: [{ name: 'from', type: 'string', required: true, desc: 'Source path' }, { name: 'to', type: 'string', required: true, desc: 'Destination path' }] },
  { id: 'files.delete', name: 'Delete File', category: 'Files', desc: 'Send a file/folder to Trash (recoverable).', risk: 'medium', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'Path to trash' }] },
  { id: 'files.zip', name: 'Zip Files', category: 'Files', desc: 'Compress a file/folder into a .zip.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'Path to compress' }] },
  { id: 'files.unzip', name: 'Unzip Archive', category: 'Files', desc: 'Extract a .zip archive.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'Zip path' }] },
  { id: 'files.info', name: 'File Info', category: 'Files', desc: 'Size, dates and type of a file.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'Path' }] },
  { id: 'files.reveal', name: 'Reveal in Finder', category: 'Files', desc: 'Show a file in Finder / Explorer.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'Path to reveal' }] },
  { id: 'files.open_terminal', name: 'Open Terminal Here', category: 'Files', desc: 'Open Terminal / CMD at a folder.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'Folder path' }] },
  { id: 'files.recent', name: 'Recent Downloads', category: 'Files', desc: 'List the newest files in Downloads.', risk: 'low', os: ['mac', 'win'], args: [] },

  /* ── Drive (JARVIS's own sandboxed workspace — works on every install, incl. the website) ── */
  { id: 'drive.write', name: 'Save to Drive', category: 'Drive', desc: 'Create or overwrite a file in the JARVIS Drive (persistent, previewable, downloadable).', risk: 'low', os: ['mac', 'win'], args: [{ name: 'name', type: 'string', required: true, desc: 'File name in the Drive, e.g. notes/ideas.md or bakery/index.html', example: 'ideas.md' }, { name: 'content', type: 'string', required: true, desc: 'Full text content to write' }, { name: 'append', type: 'boolean', required: false, desc: 'Append instead of overwrite' }] },
  { id: 'drive.site', name: 'Build Website', category: 'Drive', desc: 'Build a complete single-file website (HTML + inline CSS/JS) and save it to the Drive for instant live preview.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'name', type: 'string', required: true, desc: 'Site file name, e.g. bakery.html', example: 'bakery.html' }, { name: 'title', type: 'string', required: false, desc: 'Site title' }, { name: 'content', type: 'string', required: true, desc: 'COMPLETE production-quality HTML document' }] },
  { id: 'drive.list', name: 'List Drive', category: 'Drive', desc: 'Show every file saved in the JARVIS Drive.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'drive.read', name: 'Read Drive File', category: 'Drive', desc: 'Read a file saved in the JARVIS Drive.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'name', type: 'string', required: true, desc: 'File name in the Drive' }] },
  { id: 'drive.delete', name: 'Delete Drive File', category: 'Drive', desc: 'Delete a file or folder from the JARVIS Drive.', risk: 'medium', os: ['mac', 'win'], args: [{ name: 'name', type: 'string', required: true, desc: 'File name in the Drive' }] },
  { id: 'drive.download', name: 'Download Drive', category: 'Drive', desc: 'Get the zip download for everything in the JARVIS Drive.', risk: 'low', os: ['mac', 'win'], args: [] },

  /* ── Clipboard ── */
  { id: 'clipboard.get', name: 'Read Clipboard', category: 'Clipboard', desc: 'Read current clipboard text.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'clipboard.set', name: 'Copy to Clipboard', category: 'Clipboard', desc: 'Place text on the clipboard.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'text', type: 'string', required: true, desc: 'Text to copy' }] },

  /* ── Media ── */
  { id: 'media.play_pause', name: 'Play / Pause', category: 'Media', desc: 'Toggle playback (Spotify → Music → system).', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'media.next', name: 'Next Track', category: 'Media', desc: 'Skip forward.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'media.previous', name: 'Previous Track', category: 'Media', desc: 'Skip back.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'media.now_playing', name: 'Now Playing', category: 'Media', desc: 'Current Spotify / Music track.', risk: 'low', os: ['mac'], args: [] },
  { id: 'media.play_search', name: 'Play Search', category: 'Media', desc: 'Play a song/artist/playlist on Spotify, Apple Music or YouTube.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'query', type: 'string', required: true, desc: 'What to play', example: 'Focus Flow playlist' }, { name: 'service', type: 'string', required: false, desc: 'spotify | apple_music | youtube (default spotify)' }] },

  /* ── Windows ── */
  { id: 'window.snap_left', name: 'Snap Left', category: 'Windows', desc: 'Snap the front window to the left half.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'window.snap_right', name: 'Snap Right', category: 'Windows', desc: 'Snap the front window to the right half.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'window.hide_others', name: 'Hide Other Apps', category: 'Windows', desc: 'Hide every app except the focused one.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'window.close_front', name: 'Close Front Window', category: 'Windows', desc: 'Close the active window/tab.', risk: 'medium', os: ['mac', 'win'], args: [] },

  /* ── Comms ── */
  { id: 'email.draft', name: 'Draft Email', category: 'Comms', desc: 'Prepare an email draft in Mail for your review — never auto-sends.', risk: 'medium', os: ['mac', 'win'], args: [{ name: 'to', type: 'string', required: true, desc: 'Recipient address' }, { name: 'subject', type: 'string', required: true, desc: 'Subject' }, { name: 'body', type: 'string', required: true, desc: 'Email body' }] },
  { id: 'whatsapp.compose', name: 'WhatsApp Compose', category: 'Comms', desc: 'Open WhatsApp with a validated message ready to send.', risk: 'medium', os: ['mac', 'win'], args: [{ name: 'phone', type: 'string', required: true, desc: 'International number, e.g. +919876543210' }, { name: 'message', type: 'string', required: true, desc: 'Message text' }] },
  { id: 'imessage.send', name: 'Send iMessage', category: 'Comms', desc: 'Send an iMessage from this Mac.', risk: 'high', os: ['mac'], args: [{ name: 'to', type: 'string', required: true, desc: 'Phone/email of recipient' }, { name: 'message', type: 'string', required: true, desc: 'Message text' }] },

  /* ── Productivity ── */
  { id: 'notes.add', name: 'Add Note', category: 'Productivity', desc: 'Create a note in Apple Notes / JARVIS vault.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'title', type: 'string', required: false, desc: 'Note title' }, { name: 'body', type: 'string', required: true, desc: 'Note content' }] },
  { id: 'notes.list', name: 'List Notes', category: 'Productivity', desc: 'List recent notes.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'reminders.create', name: 'Create Reminder', category: 'Productivity', desc: 'Add a reminder (optional due date).', risk: 'low', os: ['mac', 'win'], args: [{ name: 'title', type: 'string', required: true, desc: 'Reminder text' }, { name: 'when', type: 'string', required: false, desc: 'e.g. tomorrow 9am' }] },
  { id: 'reminders.list', name: 'List Reminders', category: 'Productivity', desc: 'Show open reminders.', risk: 'low', os: ['mac'], args: [] },
  { id: 'calendar.create', name: 'Calendar Event', category: 'Productivity', desc: 'Create a calendar event.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'title', type: 'string', required: true, desc: 'Event title' }, { name: 'date', type: 'string', required: true, desc: 'YYYY-MM-DD' }, { name: 'time', type: 'string', required: false, desc: 'HH:MM 24h' }, { name: 'minutes', type: 'number', required: false, desc: 'Duration minutes (default 60)' }] },
  { id: 'tasks.create', name: 'Add Task', category: 'Productivity', desc: 'Add to the Reminders / JARVIS task list.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'title', type: 'string', required: true, desc: 'Task' }] },
  { id: 'tasks.list', name: 'List Tasks', category: 'Productivity', desc: 'Show open tasks.', risk: 'low', os: ['mac', 'win'], args: [] },

  /* ── Web ── */
  { id: 'web.open', name: 'Open URL', category: 'Web', desc: 'Open a website in the default browser.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'url', type: 'string', required: true, desc: 'URL' }] },
  { id: 'web.search', name: 'Google Search', category: 'Web', desc: 'Search the web.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'query', type: 'string', required: true, desc: 'Search terms' }] },
  { id: 'web.youtube', name: 'YouTube Search', category: 'Web', desc: 'Search / play on YouTube.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'query', type: 'string', required: true, desc: 'Search terms' }] },

  /* ── Info ── */
  { id: 'info.time', name: 'Date & Time', category: 'Info', desc: 'Current local date/time.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'info.weather', name: 'Weather', category: 'Info', desc: 'Live weather for a city.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'city', type: 'string', required: false, desc: 'City (default: auto by IP)' }] },
  { id: 'info.news', name: 'Headlines', category: 'Info', desc: 'Top world headlines.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'info.wiki', name: 'Wikipedia', category: 'Info', desc: 'Encyclopedia summary.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'query', type: 'string', required: true, desc: 'Topic' }] },
  { id: 'info.ip', name: 'Public IP', category: 'Info', desc: 'Your public IP address.', risk: 'low', os: ['mac', 'win'], args: [] },
  { id: 'info.currency', name: 'Exchange Rate', category: 'Info', desc: 'Convert currency at live rates.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'from', type: 'string', required: true, desc: 'e.g. USD' }, { name: 'to', type: 'string', required: true, desc: 'e.g. INR' }, { name: 'amount', type: 'number', required: false, desc: 'Amount (default 1)' }] },

  /* ── Text ── */
  { id: 'text.speak', name: 'Speak Text', category: 'Text', desc: 'Say text out loud through the speakers.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'text', type: 'string', required: true, desc: 'What to say' }] },

  /* ── Dev ── */
  { id: 'dev.open_vscode', name: 'Open in VS Code', category: 'Dev', desc: 'Open a folder in Visual Studio Code.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: false, desc: 'Folder (default home)' }] },
  { id: 'dev.git_status', name: 'Git Status', category: 'Dev', desc: 'Git branch + pending changes for a repo.', risk: 'low', os: ['mac', 'win'], args: [{ name: 'path', type: 'string', required: true, desc: 'Repo path' }] },
];

export const TOOL_MAP: Record<string, ToolDef> = Object.fromEntries(TOOLS.map((t) => [t.id, t]));

export const TOOL_CATEGORIES = Array.from(new Set(TOOLS.map((t) => t.category)));

/** Registry summary for the AI prompt (platform-filtered). */
export function toolCatalog(platform: AnyPlatform, availableOverride?: Set<string>): string {
  const lines: string[] = [];
  for (const t of TOOLS) {
    const available = availableOverride ? availableOverride.has(t.id) : platform === 'linux' ? false : t.os.includes(platform);
    const argStr = t.args.map((a) => `${a.name}${a.required ? '' : '?'}:${a.type}`).join(', ');
    lines.push(`- ${t.id}(${argStr}) — ${t.desc} [risk:${t.risk}${available ? '' : '|unavailable-on-this-machine'}]`);
  }
  return lines.join('\n');
}

/** One all-inclusive J53 subscription. Annual billing is priced at ten monthly payments. */
export const ALL_ACCESS_PRICES = { monthly: 553, annual: 5530 } as const;
export const PLANS = ['all-access'];
export const DEFAULT_PLAN = 'all-access';
export function subscriptionPrice(cycle: 'monthly' | 'annual'): number {
  const raw = process.env[cycle === 'annual' ? 'JARVIS_PRICE_ANNUAL_INR' : 'JARVIS_PRICE_MONTHLY_INR'];
  const configured = raw ? Number(raw) : NaN;
  return Number.isFinite(configured) && configured > 0 ? Math.round(configured) : ALL_ACCESS_PRICES[cycle];
}
