#!/bin/bash
# JARVIS 53 — stops the local server (port 3000)
cd "$(dirname "$0")" || exit 1
if [ -f native/global-voice.pid ]; then
  kill "$(cat native/global-voice.pid)" 2>/dev/null || true
  rm -f native/global-voice.pid
fi
PIDS=$(lsof -ti tcp:3000 2>/dev/null)
if [ -n "$PIDS" ]; then
  echo "$PIDS" | xargs kill 2>/dev/null || true
  echo "[✓] JARVIS 53 powered down. See you soon."
else
  echo "[✓] JARVIS 53 server is not running."
fi
