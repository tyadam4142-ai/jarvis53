#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
#  JARVIS 53 · MAKE-DB  —  create / update the database in one command
#  Usage:  bash MAKE-DB.sh          (from inside JARVIS-53-WebApp)
#  Creates db/custom.db with ALL tables (customers, tickets, chats,
#  announcements, keys, settings, telemetry). Safe to re-run — it
#  never deletes existing data.
# ═══════════════════════════════════════════════════════════════
set -euo pipefail
cd "$(dirname "$0")"

# A distributable never contains .env. Create a private local copy from the example on first setup.
if [ ! -f .env ]; then
  cp .env.example .env
  chmod 600 .env
  echo "Created .env from .env.example. Review server mode, URL, and secrets before launch."
fi

# Keep a recoverable copy before any Prisma schema sync.
if [ -f db/custom.db ]; then
  mkdir -p backups
  stamp=$(date -u +%Y%m%dT%H%M%SZ)
  cp -p db/custom.db "backups/custom.db.${stamp}.bak"
  echo "Database backup: backups/custom.db.${stamp}.bak"
fi

echo "── JARVIS 53 · database setup ──────────────────────────"

# 0. Always use the DATABASE_URL from this folder's .env, so a stray
#    global environment variable can never create the DB somewhere else.
if [ -f .env ]; then
  ENV_DB=$(grep -E '^DATABASE_URL=' .env | tail -1 | cut -d'=' -f2- | tr -d '"')
  if [ -n "$ENV_DB" ]; then
    export DATABASE_URL="$ENV_DB"
    echo "Database path (from .env): $DATABASE_URL"
  fi
fi

# 1. Node.js check
if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js is not installed."
  echo "       Install Node.js 20.9 or newer:  https://nodejs.org"
  exit 1
fi
NODE_V=$(node -v)
NODE_MAJOR=$(echo "$NODE_V" | sed 's/^v\([0-9]*\).*/\1/')
echo "Node.js: $NODE_V"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "WARNING: Node 20.9+ is recommended (you have $NODE_V). Continuing..."
fi

# 2. Dependencies (needed for Prisma; first run only)
if [ ! -d node_modules ]; then
  echo "Installing dependencies (first run only)..."
  npm install --no-audit --no-fund
else
  echo "Dependencies: already installed (node_modules found)"
fi

# 3. Generate the Prisma client, then create the database + tables
echo "Generating Prisma client..."
npx prisma generate
echo "Creating database tables (db/custom.db)..."
npx prisma db push

# 4. Verify the tables really exist
node - << 'EOF'
const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();
(async () => {
  const checks = [
    ['Customer',      () => db.customer.count()],
    ['Ticket',        () => db.ticket.count()],
    ['TicketReply',   () => db.ticketReply.count()],
    ['Announcement',  () => db.announcement.count()],
    ['ChatMessage',   () => db.chatMessage.count()],
    ['Setting',       () => db.setting.count()],
    ['UsageLog',      () => db.usageLog.count()],
    ['Preference',    () => db.preference.count()],
  ];
  let ok = 0;
  for (const [name, fn] of checks) {
    try { await fn(); console.log(`  table ${name}: OK`); ok++; }
    catch { console.log(`  table ${name}: MISSING`); }
  }
  await db.$disconnect();
  if (ok === checks.length) {
    console.log('── Database ready: db/custom.db (all tables present) ──');
  } else {
    console.error('Some tables are missing — run:  npm run db:push');
    process.exit(1);
  }
})();
EOF

echo ""
echo "NEXT STEPS"
echo "  npm run build           # production build"
echo "  npm run start           # binds 127.0.0.1:3000; use HTTPS reverse proxy"
echo "  open https://53.jarvis53.dynamicrobotics53.com/admin after configuring a new private PIN in .env"
