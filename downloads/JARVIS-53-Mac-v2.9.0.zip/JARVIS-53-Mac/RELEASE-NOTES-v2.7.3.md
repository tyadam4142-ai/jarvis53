# JARVIS 53 v2.7.3 — security and deployment release

## Required hostname layout
- Marketing site: `https://jarvis53.dynamicrobotics53.com` (static hosting / GitHub Pages).
- Application server and admin portal: `https://53.jarvis53.dynamicrobotics53.com` (Next.js server on your VPS).

## Changes
- Removed shipped `.env` and `ADMIN-ACCESS.txt` from distributable app packages.
- Replaced key-shaped test data in `data/keys.json` with an empty key store. Add real provider keys only in the private server Admin → AI Keys panel.
- Added per-install 256-bit activation tokens; only SHA-256 hashes are stored in the server DB.
- Added an administrator-only one-time activation-token reset action for legacy customers.
- Activation status, AI chat, message drafts, concierge chat and ticket reads require a matching token; hosted server-mode checks active status and a valid future subscription expiry.
- Hosted server mode cannot execute local computer tools or expose customer-local Drive, history, preferences, system status, voice or local activation-token storage.
- Desktop activation and hosted AI route to `https://53.jarvis53.dynamicrobotics53.com`; native desktop tools remain on the customer's machine.
- Updated service-worker cache version labels to `j53-static-v2.7.3`.
- Removed `--accept-data-loss` from database setup and added a backup of the SQLite file before schema sync.
- Added deployment steps for Cloudflare DNS, private localhost binding, systemd, Nginx and HTTPS in `HOST-53-SERVER.md`.

## Migration notes
- This release adds `Customer.accessTokenHash`. Back up the live database before applying the new schema.
- Existing v2.7.2 customer records without an activation-token hash must be reset in Admin → Customers → **Reset token**. Send the one-time token through a private channel. Legacy accounts should be handled before approving access under v2.7.3.
- An account marked active without a future `subscriptionEndsAt` date is not allowed to use paid APIs. Verify a renewal and use Approve to establish a correct expiry.
- The static marketing site is not the application server. Create DNS and HTTPS for `53.jarvis53.dynamicrobotics53.com`; do not expose port 3000 directly.
- Manual UPI reference verification remains manual; an entered reference is not verified against a payment gateway.

## Validation status
This is a best-effort security hardening release assembled from the supplied v2.7.2 source. It is not a guarantee of zero defects or an external security audit. Read `VALIDATION-REPORT.md` for checks executed and release limitations. The full npm lint/build could not run in the build environment because the npm registry failed DNS resolution (`EAI_AGAIN`); run those commands on the VPS before public exposure.
