/**
 * JARVIS 53 — Electron main process.
 * Owns the real desktop lifecycle: window, tray, global shortcut, notifications,
 * server supervision, single-instance lock, launch-at-login. The renderer is a
 * sandboxed view of the local Next.js UI — it never gets Node access.
 */
const { app, BrowserWindow, Tray, Menu, globalShortcut, Notification, shell, dialog, ipcMain, session } = require('electron');
const path = require('path');
const fs = require('fs');
const { ServerManager, log } = require('./server-manager.cjs');

const APP_ROOT = path.join(__dirname, '..');
const CONFIG_DIR = path.join(app.getPath ? app.getPath('home') : require('os').homedir(), '.jarvis53');
const CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');

const DEFAULT_CONFIG = {
  shortcut: 'CmdOrCtrl+Shift+J', // global summon shortcut (user-editable)
  closeAction: 'hide',           // hide-to-tray (default) or quit on window close
  launchAtLogin: false,
  port: 35553,
};

let mainWindow = null;
let tray = null;
let server = null;
let quitting = false;

/* ── Config (tiny JSON file; no extra dependencies) ── */
function loadConfig() {
  try {
    return { ...DEFAULT_CONFIG, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) };
  } catch {
    return { ...DEFAULT_CONFIG };
  }
}
function saveConfig(config) {
  try {
    fs.mkdirSync(CONFIG_DIR, { recursive: true });
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), { mode: 0o600 });
  } catch (e) {
    log(`config save failed: ${e.message}`);
  }
}
let config = loadConfig();

/* ── Single instance ── */
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => showMainWindow());
}

/* ── Window management ── */
function createWindow(port) {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 880,
    minWidth: 980,
    minHeight: 620,
    show: false,
    backgroundColor: '#050911',
    title: 'JARVIS 53',
    icon: path.join(APP_ROOT, 'public', 'icon-512.png'),
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      spellcheck: false,
    },
  });
  mainWindow.loadURL(`http://127.0.0.1:${port}`);
  mainWindow.once('ready-to-show', () => mainWindow.show());

  // Keep navigation inside the app: external links go to the system browser.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?/.test(url)) return { action: 'allow' };
    shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!/^http:\/\/127\.0\.0\.1:\d+/.test(url)) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });

  // Close button hides to tray by default so background work keeps running.
  mainWindow.on('close', (event) => {
    if (!quitting && config.closeAction === 'hide') {
      event.preventDefault();
      mainWindow.hide();
    }
  });
  mainWindow.on('closed', () => { mainWindow = null; });
}

function showMainWindow() {
  if (mainWindow) {
    mainWindow.show();
    mainWindow.focus();
    return;
  }
  if (server && server.baseUrl) createWindow(server.port);
}

/* ── Tray ── */
function createTray() {
  const iconPath = path.join(APP_ROOT, 'public', 'icon-192.png');
  try {
    tray = new Tray(iconPath);
  } catch {
    log('tray icon missing; tray disabled');
    return;
  }
  const menu = Menu.buildFromTemplate([
    { label: 'Show JARVIS 53', click: showMainWindow },
    { label: 'Global shortcut: ' + config.shortcut, enabled: false },
    { type: 'separator' },
    { label: 'Launch at login', type: 'checkbox', checked: config.launchAtLogin, click: (item) => {
      config.launchAtLogin = item.checked;
      saveConfig(config);
      app.setLoginItemSettings({ openAtLogin: item.checked, args: ['--hidden'] });
    } },
    { type: 'separator' },
    { label: 'Quit JARVIS 53', click: () => app.quit() },
  ]);
  tray.setToolTip('JARVIS 53 · Dynamic Robotics');
  tray.setContextMenu(menu);
  tray.on('click', showMainWindow);
}

/* ── Global shortcut ── */
function registerShortcut() {
  globalShortcut.unregisterAll();
  try {
    globalShortcut.register(config.shortcut, () => {
      if (mainWindow && mainWindow.isVisible() && mainWindow.isFocused()) mainWindow.hide();
      else showMainWindow();
    });
    log(`global shortcut registered: ${config.shortcut}`);
  } catch (e) {
    log(`shortcut registration failed: ${e.message}`);
    dialog.showMessageBox({
      type: 'warning',
      title: 'JARVIS 53 — shortcut conflict',
      message: `The global shortcut ${config.shortcut} could not be registered (it may be used by another app).\n\nEdit the "shortcut" value in ${CONFIG_FILE} and restart JARVIS.`,
    });
  }
}

/* ── Menu (with standard roles + quit semantics) ── */
function createMenu() {
  const template = [
    ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
    { role: 'editMenu' },
    { role: 'viewMenu' },
    { role: 'windowMenu' },
    {
      label: 'JARVIS',
      submenu: [
        { label: 'Show JARVIS 53', accelerator: 'CmdOrCtrl+1', click: showMainWindow },
        { label: 'Command Bar', accelerator: 'CmdOrCtrl+K', click: () => { showMainWindow(); if (mainWindow) mainWindow.webContents.send('j53:command-bar'); } },
        { type: 'separator' },
        { label: 'Launch at login', type: 'checkbox', checked: config.launchAtLogin, click: (item) => {
          config.launchAtLogin = item.checked;
          saveConfig(config);
          app.setLoginItemSettings({ openAtLogin: item.checked, args: ['--hidden'] });
        } },
        { type: 'separator' },
        { label: 'Quit JARVIS 53', accelerator: 'CmdOrCtrl+Q', click: () => app.quit() },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

/* ── Server state → user-visible recovery actions ── */
function handleServerState(state) {
  log(`server state: ${JSON.stringify(state)}`);
  if (state.status === 'gave-up' || state.status === 'failed' || state.status === 'unhealthy') {
    if (Notification.isSupported()) {
      new Notification({
        title: 'JARVIS 53 service stopped',
        body: `${state.detail || 'The local AI service is not responding.'} Click Quit and relaunch the app to recover.`,
      }).show();
    }
  } else if (state.status === 'recovered' && Notification.isSupported()) {
    new Notification({ title: 'JARVIS 53 recovered', body: 'The local AI service is back online.' }).show();
  }
}

/* ── Boot ── */
app.whenReady().then(async () => {
  // Strict CSP for the local UI (defense in depth on top of Next.js headers).
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    if (/^http:\/\/127\.0\.0\.1:\d+/.test(details.url)) {
      callback({
        responseHeaders: {
          ...details.responseHeaders,
          'Content-Security-Policy': ["default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'"],
        },
      });
    } else {
      callback({});
    }
  });

  server = new ServerManager(APP_ROOT, { onState: handleServerState });
  try {
    const port = await server.start();
    config.port = port;
    saveConfig(config);
  } catch (e) {
    dialog.showErrorBox('JARVIS 53 could not start', `${e.message}\n\nThe service log is at ~/.jarvis53/server.log`);
    app.quit();
    return;
  }

  if (process.argv.includes('--hidden') || app.getLoginItemSettings?.().wasOpenedAsHidden) {
    // launched at login — start in the tray
  } else {
    createWindow(server.port);
  }
  createTray();
  createMenu();
  registerShortcut();

  app.on('activate', () => showMainWindow());
});

/* ── IPC: minimal, validated surface for the sandboxed renderer ── */
ipcMain.handle('j53:get-launcher-config', () => ({ port: server ? server.port : config.port, shortcut: config.shortcut, closeAction: config.closeAction }));
ipcMain.handle('j53:notify', (event, title, body) => {
  if (!Notification.isSupported()) return false;
  const t = String(title || 'JARVIS 53').slice(0, 80);
  const b = String(body || '').slice(0, 200);
  new Notification({ title: t, body: b }).show();
  return true;
});

/* ── Lifecycle: every quit path must reap the child server ── */
app.on('before-quit', (event) => {
  if (!quitting) {
    // Any quit request (menu, tray, OS session end) goes through here exactly once.
    quitting = true;
    event.preventDefault();
    globalShortcut.unregisterAll();
    const finish = () => app.exit(0);
    if (server) server.stop().then(finish).catch(finish);
    else finish();
  }
  // quitting === true: the prevented handler above already scheduled a clean exit.
});

app.on('window-all-closed', () => {
  // Tray keeps running unless the user really quit (closeAction: quit).
  if (config.closeAction === 'quit') app.quit();
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

process.on('exit', () => {
  try { if (server) server.stop(); } catch { /* best effort */ }
});
