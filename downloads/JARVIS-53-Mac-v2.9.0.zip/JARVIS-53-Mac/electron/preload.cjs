/**
 * JARVIS 53 — preload bridge.
 * The renderer is fully sandboxed; this exposes exactly two capabilities:
 *  - j53.notify(title, body): native desktop notifications for finished tasks
 *  - j53.getLauncherConfig(): port/shortcut info for diagnostics
 *  - j53.onCommandBar(cb): native menu / chord activation of the command bar
 * Everything else (files, shell, tools) goes through the local HTTP API.
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('j53', {
  isDesktop: true,
  notify: (title, body) => ipcRenderer.invoke('j53:notify', String(title || '').slice(0, 80), String(body || '').slice(0, 200)),
  getLauncherConfig: () => ipcRenderer.invoke('j53:get-launcher-config'),
  onCommandBar: (callback) => {
    const handler = () => callback();
    ipcRenderer.on('j53:command-bar', handler);
    return () => ipcRenderer.removeListener('j53:command-bar', handler);
  },
});
