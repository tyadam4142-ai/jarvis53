/**
 * JARVIS 53 — server manager (Electron main-process side).
 * Owns the Next.js production server as a supervised child process:
 * port selection, health wait, crash restart with backoff, clean shutdown.
 * The server's lifetime is bound to the app, NEVER to a window or a tab.
 */
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');

const PREFERRED_PORT = Number(process.env.J53_PORT || 35553);
const MAX_PORT_SCAN = 20;
const HEALTH_TIMEOUT_MS = 120_000;
const MAX_RESTARTS = 3;

function log(line) {
  try {
    const stamp = new Date().toISOString();
    const dir = path.join(os.homedir(), '.jarvis53');
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, 'server.log'), `[${stamp}] ${line}\n`);
  } catch { /* logging must never crash the app */ }
}

/** Pick the first free port starting at `start`. */
function findFreePort(start) {
  return new Promise((resolve) => {
    const tryPort = (port, attempts) => {
      if (attempts <= 0) return resolve(start);
      const srv = http.createServer();
      srv.once('error', () => tryPort(port + 1, attempts - 1));
      srv.once('listening', () => srv.close(() => resolve(port)));
      srv.listen(port, '127.0.0.1');
    };
    tryPort(start, MAX_PORT_SCAN);
  });
}

/** Poll /api/health until it answers ok:true (or timeout). Returns true | 'timeout' | 'bad-payload'. */
function waitHealthy(port, timeoutMs = HEALTH_TIMEOUT_MS) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve) => {
    const attempt = () => {
      const req = http.get({ host: '127.0.0.1', port, path: '/api/health', timeout: 2500 }, (res) => {
        let body = '';
        res.on('data', (c) => { body += c; });
        res.on('end', () => {
          try {
            const data = JSON.parse(body || '{}');
            resolve(data.ok === true ? true : 'bad-payload');
          } catch { resolve('bad-payload'); }
        });
      });
      req.on('error', () => retry());
      req.on('timeout', () => { req.destroy(); retry(); });
    };
    const retry = () => {
      if (Date.now() > deadline) resolve('timeout');
      else setTimeout(attempt, 700);
    };
    attempt();
  });
}

class ServerManager {
  constructor(appRoot, opts = {}) {
    this.appRoot = appRoot;
    this.port = null;
    this.child = null;
    this.restarts = 0;
    this.stopping = false;
    this.onState = opts.onState || (() => {});
  }

  get baseUrl() {
    return this.port ? `http://127.0.0.1:${this.port}` : null;
  }

  async start() {
    this.port = await findFreePort(PREFERRED_PORT);
    await this.spawn();
    const health = await waitHealthy(this.port);
    if (health !== true) {
      log(`server did not become healthy on :${this.port} (${health})`);
      throw new Error(`The JARVIS 53 service did not start (${health}). Check ~/.jarvis53/server.log for details.`);
    }
    log(`server healthy on :${this.port}`);
    return this.port;
  }

  spawn() {
    return new Promise((resolve, reject) => {
      const nextBin = path.join(this.appRoot, 'node_modules', 'next', 'dist', 'bin', 'next');
      if (!fs.existsSync(nextBin)) {
        reject(new Error('The JARVIS 53 runtime files are missing (next binary not found). Reinstall the application.'));
        return;
      }
      log(`spawning next start on :${this.port}`);
      // ELECTRON_RUN_AS_NODE runs the bundled Node runtime instead of spawning a separate Node.
      const child = spawn(process.execPath, [nextBin, 'start', '-H', '127.0.0.1', '-p', String(this.port)], {
        cwd: this.appRoot,
        env: { ...process.env, NODE_ENV: 'production', ELECTRON_RUN_AS_NODE: '1' },
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true,
      });
      this.child = child;
      child.stdout.on('data', (d) => log(`next: ${String(d).trim().slice(0, 400)}`));
      child.stderr.on('data', (d) => log(`next-err: ${String(d).trim().slice(0, 400)}`));
      child.on('exit', (code) => {
        log(`next exited with code ${code}`);
        this.child = null;
        this.onState({ status: 'exited', code });
        // Crash recovery: restart with linear backoff unless the user quit on purpose.
        if (!this.stopping && this.restarts < MAX_RESTARTS) {
          this.restarts += 1;
          const delay = 1500 * this.restarts;
          log(`auto-restarting server in ${delay} ms (attempt ${this.restarts}/${MAX_RESTARTS})`);
          setTimeout(() => {
            this.spawn()
              .then(() => waitHealthy(this.port))
              .then((health) => {
                if (health === true) {
                  this.restarts = 0;
                  this.onState({ status: 'recovered', port: this.port });
                } else {
                  this.onState({ status: 'unhealthy', detail: health });
                }
              })
              .catch((e) => this.onState({ status: 'failed', detail: e.message }));
          }, delay);
        } else if (!this.stopping) {
          this.onState({ status: 'gave-up', detail: 'The local JARVIS service crashed repeatedly.' });
        }
      });
      // Wait for a short spawn-settle window; reject early if it dies instantly.
      const settle = setTimeout(resolve, 1200);
      child.on('exit', (code) => {
        if (code && code !== 0) {
          clearTimeout(settle);
          reject(new Error(`The JARVIS 53 service exited immediately (code ${code}).`));
        }
      });
    });
  }

  async stop() {
    this.stopping = true;
    const child = this.child;
    if (!child) return;
    await new Promise((resolve) => {
      const killTimer = setTimeout(() => {
        try { child.kill('SIGKILL'); } catch { /* already gone */ }
        resolve();
      }, 4000);
      child.once('exit', () => { clearTimeout(killTimer); resolve(); });
      try { child.kill('SIGTERM'); } catch { clearTimeout(killTimer); resolve(); }
    });
    this.child = null;
    log('server stopped');
  }
}

module.exports = { ServerManager, findFreePort, waitHealthy, PREFERRED_PORT, log };
