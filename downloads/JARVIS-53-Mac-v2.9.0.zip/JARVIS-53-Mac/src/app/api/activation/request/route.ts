import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSetting, logUsage } from '@/lib/data';
import { DEFAULT_PLAN, subscriptionPrice } from '@/lib/tools/registry';
import { hashAccessToken, tokenHashMatches } from '@/lib/customer-auth';

function normalizePhone(raw: string): string | null {
  const cleaned = raw.replace(/[^\d+]/g, '');
  if (!/^\+?\d{8,15}$/.test(cleaned)) return null;
  return cleaned.startsWith('+') ? cleaned : `+${cleaned}`;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const phone = normalizePhone(String(body.phone ?? ''));
    if (!phone) return NextResponse.json({ error: 'Enter a valid international phone number (e.g. +919876543210).' }, { status: 400 });
    const accessToken = String(body.accessToken ?? '').trim();
    const accessTokenHash = hashAccessToken(accessToken);
    if (!accessTokenHash) return NextResponse.json({ error: 'Activation token is missing or invalid. Reopen JARVIS and try again.' }, { status: 400 });
    const paymentRef = String(body.paymentRef ?? '').trim().slice(0, 200);
    const billingCycle = body.billingCycle === 'annual' ? 'annual' : 'monthly';
    const name = String(body.name ?? '').trim().slice(0, 80) || null;
    const existing = await db.customer.findUnique({ where: { phone } });

    if (existing && !existing.accessTokenHash) {
      return NextResponse.json({ error: 'This account predates secure activation tokens. Ask the administrator to use Customers → Reset token and send the one-time token to you privately before submitting a payment reference.' }, { status: 409, headers: { 'Cache-Control': 'no-store' } });
    }
    if (existing?.accessTokenHash && !tokenHashMatches(accessToken, existing.accessTokenHash)) {
      return NextResponse.json({ error: 'This phone is already bound to another JARVIS installation. Ask Dynamic Robotics support to reset the activation token; do not submit another payment.' }, { status: 409 });
    }
    if (existing?.status === 'active' && existing.subscriptionEndsAt && existing.subscriptionEndsAt.getTime() > Date.now()) {
      if (!existing.accessTokenHash) {
        return NextResponse.json({ error: 'This is a legacy account without a secure activation token. Ask the administrator to reset the activation token, then enter the token here.' }, { status: 409 });
      }
      return NextResponse.json({ status: 'active', plan: DEFAULT_PLAN, billingCycle: existing.billingCycle ?? 'monthly', message: 'This account already has active access.' });
    }
    if (paymentRef.length < 4) return NextResponse.json({ error: 'A payment transaction reference is required for manual verification.' }, { status: 400 });

    const data = { name: name ?? existing?.name ?? null, accessTokenHash, plan: DEFAULT_PLAN, billingCycle, paymentRef, paymentStatus: 'pending', lastSeenAt: new Date(), status: 'pending' };
    const customer = existing
      ? await db.customer.update({ where: { phone }, data })
      : await db.customer.create({ data: { phone, ...data } });
    void logUsage(phone, 'activation', `plan=${customer.plan}; cycle=${billingCycle}; payment-status=pending; reference submitted; status=${customer.status}`);
    return NextResponse.json({
      status: customer.status,
      plan: DEFAULT_PLAN,
      billingCycle: customer.billingCycle,
      paymentStatus: customer.paymentStatus,
      message: 'Payment reference received. An administrator must verify the transaction before access is activated.',
    }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) {
    return NextResponse.json({ error: `Subscription request failed: ${(e as Error).message}` }, { status: 500 });
  }
}

export async function GET() {
  const paymentInstructions = await getSetting('paymentInstructions', process.env.JARVIS_PAYMENT_INSTRUCTIONS || 'Contact Dynamic Robotics for official payment instructions before paying.');
  return NextResponse.json({
    plans: [DEFAULT_PLAN], defaultPlan: DEFAULT_PLAN,
    monthlyPrice: subscriptionPrice('monthly'), annualPrice: subscriptionPrice('annual'), currency: 'INR',
    paymentInstructions,
  }, { headers: { 'Cache-Control': 'no-store' } });
}
