import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { bearerToken, tokenHashMatches } from '@/lib/customer-auth';

export const dynamic = 'force-dynamic';

function normalizePhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const phone = raw.replace(/[^\d+]/g, '');
  return /^\+?\d{8,15}$/.test(phone) ? (phone.startsWith('+') ? phone : `+${phone}`) : null;
}

/** Token-bound status endpoint. Phone number alone is not authentication. */
export async function GET(req: NextRequest) {
  try {
    const phone = normalizePhone(req.nextUrl.searchParams.get('phone'));
    if (!phone) return NextResponse.json({ error: 'phone required' }, { status: 400 });
    const token = bearerToken(req);
    const customer = await db.customer.findUnique({ where: { phone } });
    if (!customer || !tokenHashMatches(token, customer.accessTokenHash)) {
      return NextResponse.json({ error: 'Activation token is missing or invalid. Use the token on this installation or contact support.' }, { status: 401 },);
    }

    let effectiveStatus = customer.status;
    if (customer.status === 'active' && (!customer.subscriptionEndsAt || customer.subscriptionEndsAt.getTime() <= Date.now())) {
      effectiveStatus = 'expired';
      await db.customer.update({ where: { phone }, data: { status: 'expired' } }).catch(() => undefined);
    } else if (customer.status === 'active') {
      await db.customer.update({ where: { phone }, data: { lastSeenAt: new Date() } }).catch(() => undefined);
    }

    const announcement = await db.announcement.findFirst({ where: { active: true }, orderBy: { createdAt: 'desc' } });
    return NextResponse.json({
      status: effectiveStatus,
      plan: customer.plan === 'free' ? 'all-access' : customer.plan,
      billingCycle: customer.billingCycle ?? 'monthly',
      subscriptionEndsAt: customer.subscriptionEndsAt?.toISOString() ?? null,
      name: customer.name,
      announcement: announcement ? { id: announcement.id, title: announcement.title, body: announcement.body, level: announcement.level } : null,
    }, { headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return NextResponse.json({ error: 'Unable to check activation status.' }, { status: 500 });
  }
}
