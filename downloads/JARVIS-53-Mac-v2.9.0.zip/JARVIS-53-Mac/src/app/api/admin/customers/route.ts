import { randomBytes, createHash } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { guard } from '@/lib/admin-auth';
import { logUsage } from '@/lib/data';

export async function GET(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const customers = await db.customer.findMany({
    select: { id: true, phone: true, name: true, plan: true, billingCycle: true, paymentRef: true, paymentStatus: true, subscriptionEndsAt: true, status: true, createdAt: true, approvedAt: true, lastSeenAt: true, notes: true },
    orderBy: { createdAt: 'desc' }, take: 500,
  });
  return NextResponse.json({ customers }, { headers: { 'Cache-Control': 'no-store' } });
}

/** Actions: approve | decline | suspend | reactivate | delete | update | reset-activation */
export async function POST(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const action = String(body.action ?? '');
    const id = Number(body.id);
    if (!Number.isFinite(id)) return NextResponse.json({ error: 'id required' }, { status: 400 });
    const existing = await db.customer.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'Customer not found' }, { status: 404 });

    switch (action) {
      case 'reset-activation': {
        // Show this token once to the administrator. Only its hash is persisted.
        const activationToken = randomBytes(32).toString('hex');
        const accessTokenHash = createHash('sha256').update(activationToken).digest('hex');
        await db.customer.update({ where: { id }, data: { accessTokenHash } });
        void logUsage(existing.phone, 'admin', 'activation-token-reset');
        return NextResponse.json({ ok: true, activationToken }, { headers: { 'Cache-Control': 'no-store' } });
      }
      case 'approve': {
        if (!existing.accessTokenHash) return NextResponse.json({ error: 'This legacy account has no secure activation token. Use Reset token first, then approve after verifying the payment.' }, { status: 409 });
        if (!existing.paymentRef || existing.paymentRef.trim().length < 4) return NextResponse.json({ error: 'Cannot activate: no transaction reference is on file. Verify the payment reference first.' }, { status: 400 });
        if (existing.status === 'active' && existing.subscriptionEndsAt && existing.subscriptionEndsAt.getTime() > Date.now()) return NextResponse.json({ error: 'This subscription is already active. Do not approve the same payment twice.' }, { status: 409 });
        const now = new Date();
        const startsAt = existing.subscriptionEndsAt && existing.subscriptionEndsAt.getTime() > now.getTime() ? existing.subscriptionEndsAt : now;
        const end = new Date(startsAt);
        if (existing.billingCycle === 'annual') {
          const month = end.getMonth(); const day = end.getDate();
          end.setDate(1); end.setFullYear(end.getFullYear() + 1); end.setMonth(month);
          const lastDay = new Date(end.getFullYear(), end.getMonth() + 1, 0).getDate(); end.setDate(Math.min(day, lastDay));
        } else {
          const month = end.getMonth(); const day = end.getDate();
          end.setDate(1); end.setMonth(month + 1);
          const lastDay = new Date(end.getFullYear(), end.getMonth() + 1, 0).getDate(); end.setDate(Math.min(day, lastDay));
        }
        await db.customer.update({ where: { id }, data: { status: 'active', plan: 'all-access', paymentStatus: 'verified', approvedAt: now, subscriptionEndsAt: end } });
        break;
      }
      case 'decline': await db.customer.update({ where: { id }, data: { status: 'declined', paymentStatus: 'rejected' } }); break;
      case 'suspend': await db.customer.update({ where: { id }, data: { status: 'suspended' } }); break;
      case 'reactivate': {
        if (!existing.accessTokenHash) return NextResponse.json({ error: 'This legacy account has no secure activation token. Use Reset token first.' }, { status: 409 });
        if (!existing.subscriptionEndsAt || existing.subscriptionEndsAt.getTime() <= Date.now()) return NextResponse.json({ error: 'This subscription has no valid future expiry. Verify a renewal payment and use Approve instead.' }, { status: 409 });
        await db.customer.update({ where: { id }, data: { status: 'active' } });
        break;
      }
      case 'delete': await db.customer.delete({ where: { id } }); break;
      case 'update': {
        const data: Record<string, string | null> = {};
        if (typeof body.notes === 'string') data.notes = body.notes.slice(0, 1000) || null;
        if (typeof body.paymentRef === 'string') data.paymentRef = body.paymentRef.trim().slice(0, 200) || null;
        if (body.billingCycle === 'monthly' || body.billingCycle === 'annual') data.billingCycle = body.billingCycle;
        data.plan = 'all-access';
        if (typeof body.name === 'string') data.name = body.name.slice(0, 80) || null;
        await db.customer.update({ where: { id }, data }); break;
      }
      default: return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }
    void logUsage(existing.phone, 'admin', `customer-action:${action}`);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
