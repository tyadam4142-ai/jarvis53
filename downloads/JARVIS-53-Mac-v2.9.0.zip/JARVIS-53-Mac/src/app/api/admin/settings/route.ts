import { NextRequest, NextResponse } from 'next/server';
import { guard, getMasterPin, isDefaultPin, tokenFor, adminCookieName, pinIsUsable } from '@/lib/admin-auth';
import { setSetting, getSetting } from '@/lib/data';

export async function GET(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  return NextResponse.json({
    pinIsDefault: await isDefaultPin(),
    paymentInstructions: await getSetting('paymentInstructions', process.env.JARVIS_PAYMENT_INSTRUCTIONS || 'Contact Dynamic Robotics for official payment instructions before paying.'),
  });
}

/** Body: setPin | setPaymentDetails. Paid subscriptions are always manually verified. */
export async function POST(req: NextRequest) {
  if (!(await guard(req))) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const action = String(body.action ?? '');
    if (action === 'setPin') {
      if ((process.env.JARVIS_ADMIN_PIN ?? '').trim()) {
        return NextResponse.json({ error: 'The administrator PIN is controlled by JARVIS_ADMIN_PIN in the private .env file. Change that value and restart JARVIS; this form cannot override it.' }, { status: 409 });
      }
      const pin = String(body.pin ?? '').trim();
      if (!/^\d{6,12}$/.test(pin) || !pinIsUsable(pin)) return NextResponse.json({ error: 'Use 6–12 digits and avoid common codes like 123456.' }, { status: 400 });
      await setSetting('masterPin', pin);
      const res = NextResponse.json({ ok: true, message: 'Master PIN updated. All sessions re-authenticated.' });
      res.cookies.set(adminCookieName(), tokenFor(await getMasterPin()), { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', path: '/', maxAge: 60 * 60 * 4 });
      return res;
    }
    if (action === 'setPaymentDetails') {
      const instructions = String(body.paymentInstructions ?? '').trim().slice(0, 700);
      await setSetting('paymentInstructions', instructions || 'Contact Dynamic Robotics for official payment instructions before paying.');
      return NextResponse.json({ ok: true, paymentInstructions: instructions });
    }
    return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
