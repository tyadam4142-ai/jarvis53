import { NextRequest, NextResponse } from 'next/server';
import { jarvisThink, runAgentLoop, type AgentStepOutcome } from '@/lib/ai/provider';
import { runTool, type ToolOutcome } from '@/lib/tools/runner';
import { logUsage } from '@/lib/data';
import { db } from '@/lib/db';
import { bearerToken, tokenHashMatches } from '@/lib/customer-auth';

function normalizePhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const phone = raw.replace(/[^\d+]/g, '');
  return /^\+?\d{8,15}$/.test(phone) ? (phone.startsWith('+') ? phone : `+${phone}`) : null;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const text = String(body.text ?? '').trim().slice(0, 4000);
    const remoteBase = (process.env.JARVIS_REMOTE_AI_URL ?? '').trim().replace(/\/+$/, '');
    if (remoteBase && process.env.JARVIS_SERVER_MODE !== '1') {
      const phone = normalizePhone(body.phone);
      const accessToken = typeof body.accessToken === 'string' ? body.accessToken : bearerToken(req);
      if (!phone || !accessToken) return NextResponse.json({ error: 'Activate JARVIS All Access before using AI.' }, { status: 401 });
      const history = Array.isArray(body.history)
        ? body.history.filter((m: { role?: unknown; content?: unknown }) => (m?.role === 'user' || m?.role === 'assistant') && typeof m?.content === 'string')
            .slice(-8).map((m: { role: 'user' | 'assistant'; content: string }) => ({ role: m.role, content: m.content.slice(0, 4000) }))
        : [];
      if (!text) return NextResponse.json({ error: 'Please enter a message.' }, { status: 400 });
      let remoteResponse: Response;
      try {
        remoteResponse = await fetch(`${remoteBase}/api/chat`, {
          method: 'POST', headers: { 'content-type': 'application/json', origin: remoteBase },
          body: JSON.stringify({ text, phone, accessToken, history }), signal: AbortSignal.timeout(45000), cache: 'no-store',
        });
      } catch {
        return NextResponse.json({ error: 'The JARVIS AI server is unreachable. Check your internet connection or try again shortly.' }, { status: 503 });
      }
      let remoteData = await remoteResponse.json().catch(() => ({})) as { error?: string; say?: string; provider?: string; model?: string; routeNote?: string; plan?: string; suggestedActions?: Array<{ tool: string; args?: Record<string, unknown> }> };
      if (!remoteResponse.ok) return NextResponse.json({ error: remoteData.error ?? 'JARVIS AI request was rejected.' }, { status: remoteResponse.status, headers: { 'Cache-Control': 'no-store' } });

      // Execute the suggested actions locally through the real safety pipeline…
      const runSuggested = async (suggested: Array<{ tool: string; args?: Record<string, unknown> }>): Promise<ToolOutcome[]> => {
        const executed: ToolOutcome[] = [];
        for (const action of suggested.slice(0, 8)) {
          if (typeof action?.tool !== 'string') continue;
          executed.push(await runTool(action.tool, action.args ?? {}, { phone, source: 'ai' }));
        }
        return executed;
      };

      let actions: ToolOutcome[] = [];
      if (remoteData.provider !== 'unavailable' && Array.isArray(remoteData.suggestedActions)) {
        actions = await runSuggested(remoteData.suggestedActions);

        // …and give the remote brain ONE bounded follow-up with the real outcomes
        // so its final reply reflects what actually happened (BUG-001 fix for hosted mode).
        const needsFollowUp = actions.some((a) => a.status !== 'done' || a.output);
        if (needsFollowUp && actions.length) {
          const report = actions.map((a) => `- ${a.tool} → ${a.status}: ${String(a.output || '').replace(/\s+/g, ' ').slice(0, 300)}`).join('\n');
          try {
            const followUp = await fetch(`${remoteBase}/api/chat`, {
              method: 'POST', headers: { 'content-type': 'application/json', origin: remoteBase },
              body: JSON.stringify({
                text: `AUTOMATED TOOL REPORT (ground truth — do not claim anything ran unless its status is "done"):\n${report}\nOriginal request: ${text}`,
                phone, accessToken, history: [...history, { role: 'user', content: text }, { role: 'assistant', content: remoteData.say ?? '' }],
              }), signal: AbortSignal.timeout(45000), cache: 'no-store',
            });
            const followData = await followUp.json().catch(() => ({})) as typeof remoteData;
            if (followUp.ok && followData.say) {
              const allFirstRoundDone = actions.every((a) => a.status === 'done');
              const followActions = Array.isArray(followData.suggestedActions) ? followData.suggestedActions : [];
              // Only execute follow-up proposals when the first round fully succeeded,
              // otherwise the model would re-propose the same pending confirmation.
              if (allFirstRoundDone && followActions.length) {
                actions = [...actions, ...(await runSuggested(followActions))];
              }
              remoteData = { ...followData, suggestedActions: [] };
            }
          } catch { /* keep the first-turn reply; outcome cards still show ground truth */ }
        }
      }
      void logUsage(phone, 'chat', `remote:${remoteData.provider ?? 'unknown'}:${remoteData.model ?? 'default'}:${text.slice(0, 100)}`);
      return NextResponse.json({ say: remoteData.say ?? '', actions, provider: remoteData.provider, model: remoteData.model, routeNote: remoteData.routeNote, plan: remoteData.plan }, { headers: { 'Cache-Control': 'no-store' } });
    }
    const suppliedPhone = body.phone ? normalizePhone(body.phone) : null;
    const accessToken = typeof body.accessToken === 'string' ? body.accessToken : bearerToken(req);
    const history = Array.isArray(body.history)
      ? body.history.filter((m: { role?: unknown; content?: unknown }) => (m?.role === 'user' || m?.role === 'assistant') && typeof m?.content === 'string')
          .slice(-8).map((m: { role: 'user' | 'assistant'; content: string }) => ({ role: m.role, content: m.content.slice(0, 4000) }))
      : [];
    if (!text) return NextResponse.json({ error: 'Please enter a message.' }, { status: 400 });
    if (!suppliedPhone) return NextResponse.json({ error: 'Activate JARVIS All Access first.' }, { status: 401 });

    // Hosted server is the source of truth for subscription + AI; the client token is required.
    const customer = await db.customer.findUnique({ where: { phone: suppliedPhone } });
    if (!customer || customer.status !== 'active' || !customer.subscriptionEndsAt || customer.subscriptionEndsAt.getTime() <= Date.now()) {
      return NextResponse.json({ error: 'This JARVIS account is not active. Complete payment verification or renew your subscription.' }, { status: 403 });
    }
    if (!tokenHashMatches(accessToken, customer.accessTokenHash)) {
      return NextResponse.json({ error: 'This installation is not authorized. Check the activation token or ask the administrator to reset it.' }, { status: 401 });
    }

    const plan = customer.plan === 'free' ? 'all-access' : customer.plan;
    const hostedMode = process.env.JARVIS_SERVER_MODE === '1';

    let say = '';
    let provider: string | undefined;
    let model: string | undefined;
    let routeNote: string | undefined;
    let actions: ToolOutcome[] = [];
    let suggestedActions: ToolOutcome[] = [];

    if (hostedMode) {
      // Hosted server mode must never run desktop tools on the server itself.
      const result = await jarvisThink(history, text, plan);
      say = result.actions.length ? `${result.say}\n\nDesktop actions are executed only by the local JARVIS installation.` : result.say;
      provider = result.provider; model = result.model; routeNote = result.routeNote;
      suggestedActions = [];
    } else {
      // Local desktop mode: think → act → observe loop with REAL tool outcomes (BUG-001 fix).
      const result = await runAgentLoop(history, text, async (proposed) => {
        const outcomes: AgentStepOutcome[] = [];
        for (const action of proposed) {
          const outcome = await runTool(action.tool, action.args ?? {}, { phone: suppliedPhone, source: 'ai' });
          // Keep the full card shape so the UI can approve and re-run exactly this action.
          outcomes.push({ tool: outcome.tool, status: outcome.status, output: outcome.output, args: outcome.args, label: outcome.label, risk: outcome.risk, available: outcome.available });
        }
        return outcomes;
      }, { plan });
      say = result.say;
      provider = result.provider; model = result.model; routeNote = result.routeNote;
      actions = result.steps.map(({ tool, label, risk, status, output, args, available }) => ({ tool, label, risk, status, output, args, available }));
    }

    void logUsage(suppliedPhone, 'chat', `${plan}:${provider ?? 'unknown'}:${model ?? 'local'}:${text.slice(0, 100)}`);
    return NextResponse.json({
      say, actions, suggestedActions, provider, model, routeNote, plan,
    }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) {
    const message = e instanceof Error ? e.message : 'Unknown error';
    return NextResponse.json({ error: `JARVIS could not complete that request: ${message.slice(0, 350)}` }, { status: 500 });
  }
}
