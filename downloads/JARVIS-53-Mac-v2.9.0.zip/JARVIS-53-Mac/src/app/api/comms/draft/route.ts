import { NextRequest, NextResponse } from 'next/server';
import { draftMessage } from '@/lib/ai/provider';
import { logUsage } from '@/lib/data';
import { authorizedCustomer, bearerToken } from '@/lib/customer-auth';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const channel = body.channel === 'whatsapp' ? 'whatsapp' : 'email';
    const brief = String(body.brief ?? '').trim().slice(0, 2000);
    if (!brief) return NextResponse.json({ error: 'Tell JARVIS what the message should say (a short brief).' }, { status: 400 });
    const recipient = body.recipient ? String(body.recipient).slice(0, 200) : null;
    const tone = body.tone ? String(body.tone).slice(0, 60) : null;
    const remoteBase = (process.env.JARVIS_REMOTE_AI_URL ?? '').trim().replace(/\/+$/, '');
    if (remoteBase && process.env.JARVIS_SERVER_MODE !== '1') {
      const phone = String(body.phone ?? '').replace(/[^\d+]/g, '');
      const accessToken = typeof body.accessToken === 'string' ? body.accessToken : bearerToken(req);
      if (!phone || !accessToken) return NextResponse.json({ error: 'Activate JARVIS All Access first.' }, { status: 401 });
      let remote: Response;
      try { remote = await fetch(`${remoteBase}/api/comms/draft`, { method: 'POST', headers: { 'content-type': 'application/json', origin: remoteBase }, body: JSON.stringify({ channel, brief, recipient, tone, phone, accessToken }), signal: AbortSignal.timeout(30000), cache: 'no-store' }); }
      catch { return NextResponse.json({ error: 'The JARVIS AI server is unreachable.' }, { status: 503 }); }
      const data = await remote.json().catch(() => ({}));
      return NextResponse.json(data, { status: remote.status, headers: { 'Cache-Control': 'no-store' } });
    }
    if (process.env.JARVIS_SERVER_MODE === '1') {
      const phone = String(body.phone ?? '').replace(/[^\d+]/g, '');
      const accessToken = typeof body.accessToken === 'string' ? body.accessToken : bearerToken(req);
      const customer = /^\+?\d{8,15}$/.test(phone) ? await authorizedCustomer(phone.startsWith('+') ? phone : `+${phone}`, accessToken) : null;
      if (!customer) return NextResponse.json({ error: 'An active, authorized JARVIS account is required.' }, { status: 401 });
    }
    const draft = await draftMessage({ channel, brief, recipient, tone });
    void logUsage(null, 'comms_draft', `${channel} via ${tone ?? 'default'}`);
    return NextResponse.json(draft, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) { return NextResponse.json({ error: `Draft failed: ${(e as Error).message}` }, { status: 500 }); }
}
