import { randomBytes } from 'crypto';
import { promises as fs } from 'fs';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';

function normalizePhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const phone = raw.replace(/[^\d+]/g, '');
  return /^\+?\d{8,15}$/.test(phone) ? (phone.startsWith('+') ? phone : `+${phone}`) : null;
}
function loopbackHost(raw: string): boolean {
  const value = raw.trim().toLowerCase();
  const host = value.startsWith('[') ? value.slice(1, value.indexOf(']')) : value.replace(/:\d+$/, '');
  return host === '127.0.0.1' || host === 'localhost' || host === '::1';
}

/** Persist an installation's token privately for the local native voice companion. Never available on the VPS. */
export async function POST(req: NextRequest) {
  if (process.env.JARVIS_SERVER_MODE === '1') return NextResponse.json({ error: 'Local activation storage is disabled on the hosted server.' }, { status: 404 });
  if (!loopbackHost(req.headers.get('host') ?? '')) return NextResponse.json({ error: 'Local-only endpoint.' }, { status: 403 });
  try {
    const body = await req.json();
    const phone = normalizePhone(body.phone);
    const token = typeof body.accessToken === 'string' ? body.accessToken.trim().toLowerCase() : '';
    if (!phone || !/^[a-f0-9]{64}$/.test(token)) return NextResponse.json({ error: 'Invalid activation credentials.' }, { status: 400 });
    const dataDir = path.join(process.cwd(), 'data');
    await fs.mkdir(dataDir, { recursive: true, mode: 0o700 });
    await fs.chmod(dataDir, 0o700).catch(() => undefined);
    const file = path.join(dataDir, 'active-activation.json');
    const temporary = `${file}.${randomBytes(6).toString('hex')}.tmp`;
    await fs.writeFile(temporary, JSON.stringify({ phone, accessToken: token, updatedAt: new Date().toISOString() }), { encoding: 'utf8', mode: 0o600 });
    await fs.rename(temporary, file);
    await fs.chmod(file, 0o600).catch(() => undefined);
    return NextResponse.json({ ok: true }, { headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return NextResponse.json({ error: 'Could not save local activation state.' }, { status: 500 });
  }
}
