import { NextRequest, NextResponse } from 'next/server';
import { conciergeReply } from '@/lib/ai/provider';
import { db } from '@/lib/db';
import { logUsage } from '@/lib/data';
import { authorizedCustomer, bearerToken } from '@/lib/customer-auth';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const message = String(body.message ?? '').slice(0, 2000);
    const phone = body.phone ? String(body.phone).replace(/[^\d+]/g, '') : '';
    const accessToken = typeof body.accessToken === 'string' ? body.accessToken : bearerToken(req);
    const history = Array.isArray(body.history) ? body.history.slice(-8) : [];
    if (!message.trim()) return NextResponse.json({ error: 'Empty message' }, { status: 400 });
    const remoteBase = (process.env.JARVIS_REMOTE_AI_URL ?? '').trim().replace(/\/+$/, '');
    if (remoteBase && process.env.JARVIS_SERVER_MODE !== '1') {
      if (!phone || !accessToken) return NextResponse.json({ error: 'Activate JARVIS All Access first.' }, { status: 401 });
      let remote: Response;
      try { remote = await fetch(`${remoteBase}/api/support/chat`, { method: 'POST', headers: { 'content-type': 'application/json', origin: remoteBase }, body: JSON.stringify({ message, phone, accessToken, history }), signal: AbortSignal.timeout(30000), cache: 'no-store' }); }
      catch { return NextResponse.json({ error: 'The JARVIS support server is unreachable.' }, { status: 503 }); }
      const data = await remote.json().catch(() => ({}));
      return NextResponse.json(data, { status: remote.status, headers: { 'Cache-Control': 'no-store' } });
    }
    const normalizedPhone = /^\+?\d{8,15}$/.test(phone) ? (phone.startsWith('+') ? phone : `+${phone}`) : '';
    if (process.env.JARVIS_SERVER_MODE === '1' && (!normalizedPhone || !(await authorizedCustomer(normalizedPhone, accessToken)))) return NextResponse.json({ error: 'An active, authorized JARVIS account is required.' }, { status: 401 });
    const result = await conciergeReply(history, message);
    void logUsage(normalizedPhone || null, 'support', message.slice(0, 120));
    let ticketId: number | null = null;
    if (result.needsHuman && normalizedPhone) {
      const ticket = await db.ticket.create({ data: { phone: normalizedPhone, subject: message.slice(0, 70), replies: { create: [{ author: 'customer', body: message }] } } });
      ticketId = ticket.id;
    }
    return NextResponse.json({ text: result.text, needsHuman: result.needsHuman, ticketId, provider: result.provider }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) { return NextResponse.json({ error: `Concierge error: ${(e as Error).message}` }, { status: 500 }); }
}
