import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { authorizedCustomer, bearerToken } from '@/lib/customer-auth';

function normalizedPhone(raw: unknown): string {
  const phone = String(raw ?? '').replace(/[^\d+]/g, '');
  if (!/^\+?\d{8,15}$/.test(phone)) return '';
  return phone.startsWith('+') ? phone : `+${phone}`;
}
function noStore(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
}

/** Ticket reads are scoped to the authorized customer; local clients relay to the hosted control-plane. */
export async function GET(req: NextRequest) {
  const phone = normalizedPhone(req.nextUrl.searchParams.get('phone'));
  const token = bearerToken(req);
  if (!phone || !token) return noStore({ error: 'An activation token is required.' }, 401);
  const remoteBase = (process.env.JARVIS_REMOTE_AI_URL ?? '').trim().replace(/\/+$/, '');
  if (remoteBase && process.env.JARVIS_SERVER_MODE !== '1') {
    try {
      const remote = await fetch(`${remoteBase}/api/support/tickets?phone=${encodeURIComponent(phone)}`, {
        headers: { authorization: `Bearer ${token}`, origin: remoteBase }, cache: 'no-store', signal: AbortSignal.timeout(15000),
      });
      const payload = await remote.json().catch(() => ({}));
      return noStore(payload, remote.status);
    } catch {
      return noStore({ error: 'The JARVIS support server is unreachable.' }, 503);
    }
  }
  if (process.env.JARVIS_SERVER_MODE === '1' && !(await authorizedCustomer(phone, token))) {
    return noStore({ error: 'An active, authorized JARVIS account is required.' }, 401);
  }
  const tickets = await db.ticket.findMany({
    where: { phone }, include: { replies: { orderBy: { createdAt: 'asc' } } },
    orderBy: { updatedAt: 'desc' }, take: 20,
  });
  return noStore({ tickets });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const phone = normalizedPhone(body.phone);
    const token = typeof body.accessToken === 'string' ? body.accessToken : bearerToken(req);
    const subject = String(body.subject ?? '').trim().slice(0, 120);
    const message = String(body.message ?? '').trim().slice(0, 4000);
    if (!phone || !token || !subject) return noStore({ error: 'An activation token, phone and subject are required.' }, 400);
    const remoteBase = (process.env.JARVIS_REMOTE_AI_URL ?? '').trim().replace(/\/+$/, '');
    if (remoteBase && process.env.JARVIS_SERVER_MODE !== '1') {
      try {
        const remote = await fetch(`${remoteBase}/api/support/tickets`, {
          method: 'POST', headers: { 'content-type': 'application/json', origin: remoteBase },
          body: JSON.stringify({ phone, accessToken: token, subject, message }),
          cache: 'no-store', signal: AbortSignal.timeout(15000),
        });
        const payload = await remote.json().catch(() => ({}));
        return noStore(payload, remote.status);
      } catch {
        return noStore({ error: 'The JARVIS support server is unreachable.' }, 503);
      }
    }
    if (process.env.JARVIS_SERVER_MODE === '1' && !(await authorizedCustomer(phone, token))) {
      return noStore({ error: 'An active, authorized JARVIS account is required.' }, 401);
    }
    const ticket = await db.ticket.create({
      data: { phone, subject, replies: message ? { create: [{ author: 'customer', body: message }] } : undefined },
    });
    return noStore({ ticket }, 201);
  } catch {
    return noStore({ error: 'Unable to create support ticket.' }, 500);
  }
}
