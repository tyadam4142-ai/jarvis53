import { NextRequest, NextResponse } from 'next/server';
import { TOOLS } from '@/lib/tools/registry';
import { PLATFORM } from '@/lib/os';

export async function GET() {
  if (process.env.JARVIS_SERVER_MODE === '1') return NextResponse.json({ platform: 'server', tools: [] }, { headers: { 'Cache-Control': 'no-store' } });
  return NextResponse.json({
    platform: PLATFORM,
    tools: TOOLS.map((t) => ({
      ...t,
      available: PLATFORM === 'mac' ? t.os.includes('mac') : PLATFORM === 'win' ? t.os.includes('win') : false,
    })),
  });
}
