import { promises as fs } from 'fs';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';
import { timingSafeEqual } from 'crypto';
import { jarvisThink } from '@/lib/ai/provider';
import { runTool, type ToolOutcome } from '@/lib/tools/runner';
import { logUsage } from '@/lib/data';
import { db } from '@/lib/db';

function safeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}
function requestHost(req: NextRequest): string {
  const raw = (req.headers.get('host') ?? '').trim().toLowerCase();
  return raw.startsWith('[') ? raw.slice(1, raw.indexOf(']')) : raw.replace(/:\d+$/, '');
}
function normalizePhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const phone = raw.replace(/[^\d+]/g, '');
  return /^\+?\d{8,15}$/.test(phone) ? (phone.startsWith('+') ? phone : `+${phone}`) : null;
}

/** Loopback-only global push-to-talk endpoint secured by a per-launch bridge token. */
export async function POST(req: NextRequest) {
  try {
    const expectedToken = process.env.JARVIS_BRIDGE_TOKEN ?? '';
    const suppliedToken = (req.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '').trim();
    const host = requestHost(req);
    if (!['127.0.0.1', 'localhost', '::1'].includes(host)) return NextResponse.json({ error: 'This endpoint is local-only.' }, { status: 403 });
    if (!expectedToken || !suppliedToken || !safeEqual(expectedToken, suppliedToken)) return NextResponse.json({ error: 'Global voice companion is not authorized. Restart JARVIS and its companion.' }, { status: 401 });

    const body = await req.json();
    const text = String(body.text ?? '').trim().slice(0, 4000);
    if (!text) return NextResponse.json({ error: 'No speech was transcribed.' }, { status: 400 });

    const remoteBase = (process.env.JARVIS_REMOTE_AI_URL ?? '').trim().replace(/\/+$/, '');
    if (remoteBase && process.env.JARVIS_SERVER_MODE !== '1') {
      let activation: { phone?: unknown; accessToken?: unknown };
      try { activation = JSON.parse(await fs.readFile(path.join(process.cwd(), 'data', 'active-activation.json'), 'utf8')); }
      catch { return NextResponse.json({ error: 'Activate JARVIS All Access in the dashboard before using global voice.' }, { status: 401 }); }
      const phone = normalizePhone(activation.phone);
      const accessToken = typeof activation.accessToken === 'string' && /^[a-f0-9]{64}$/i.test(activation.accessToken) ? activation.accessToken : '';
      if (!phone || !accessToken) return NextResponse.json({ error: 'The local activation token is missing. Reopen Activation and try again.' }, { status: 401 });
      let response: Response;
      try {
        response = await fetch(`${remoteBase}/api/chat`, {
          method: 'POST', headers: { 'content-type': 'application/json', origin: remoteBase },
          body: JSON.stringify({ text, phone, accessToken, history: [] }), cache: 'no-store', signal: AbortSignal.timeout(45000),
        });
      } catch { return NextResponse.json({ error: 'The hosted JARVIS AI server is unreachable.' }, { status: 503 }); }
      const result = await response.json().catch(() => ({})) as { error?: string; say?: string; provider?: string; model?: string; routeNote?: string; plan?: string; suggestedActions?: Array<{ tool: string; args?: Record<string, unknown> }> };
      if (!response.ok) return NextResponse.json({ error: result.error ?? 'The hosted JARVIS AI request was rejected.' }, { status: response.status });
      const actions: ToolOutcome[] = [];
      if (result.provider !== 'unavailable' && Array.isArray(result.suggestedActions)) {
        for (const action of result.suggestedActions.slice(0, 8)) {
          if (typeof action?.tool !== 'string') continue;
          actions.push(await runTool(action.tool, action.args ?? {}, { phone, source: 'ai' }));
        }
      }
      void logUsage(phone, 'voice', `remote:${result.provider ?? 'unknown'}:${text.slice(0, 100)}`);
      return NextResponse.json({ say: result.say ?? '', actions, provider: result.provider, model: result.model, routeNote: result.routeNote });
    }

    const customer = await db.customer.findFirst({ where: { status: 'active' }, orderBy: { lastSeenAt: 'desc' } });
    const plan = customer?.plan ?? process.env.JARVIS_DEFAULT_PLAN ?? 'all-access';
    const result = await jarvisThink([], text, plan);
    const actions: ToolOutcome[] = [];
    if (result.provider !== 'unavailable') {
      for (const action of result.actions) actions.push(await runTool(action.tool, action.args ?? {}, { phone: customer?.phone ?? null, source: 'ai' }));
    }
    void logUsage(customer?.phone, 'voice', `${plan}:${result.provider}:${text.slice(0, 100)}`);
    return NextResponse.json({ say: result.say, actions, provider: result.provider, model: result.model, routeNote: result.routeNote });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown local voice error';
    return NextResponse.json({ error: `Voice command failed: ${message.slice(0, 300)}` }, { status: 500 });
  }
}
