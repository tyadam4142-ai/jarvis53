'use client';

/**
 * J53 ALL ACCESS — cinematic boot sequence. Skippable with a click.
 */
import { useEffect, useState } from 'react';
import { useJarvis } from './store';

const LINES = [
  'DYNAMIC ROBOTICS · J53 v2.9.0',
  'RESTORING CONVERSATION MEMORY ........... OK',
  'CALIBRATING AUDIO ARRAYS ................. OK',
  'LINKING TOOL REGISTRY [65 MODULES] ....... OK',
  'SAFETY ENGINE ............................ ARMED',
  'ESTABLISHING AI UPLINK ................... OK',
  'ALL SYSTEMS NOMINAL. WELCOME BACK.',
];

export default function Boot() {
  const setPhase = useJarvis((s) => s.setPhase);
  const [visible, setVisible] = useState(0);
  const [granted, setGranted] = useState(false);

  useEffect(() => {
    if (visible >= LINES.length) {
      const g = setTimeout(() => setGranted(true), 250);
      const done = setTimeout(() => setPhase('gate'), 1050);
      return () => {
        clearTimeout(g);
        clearTimeout(done);
      };
    }
    const t = setTimeout(() => setVisible((v) => v + 1), visible === 0 ? 190 : 230);
    return () => clearTimeout(t);
  }, [visible, setPhase]);

  // Any key skips too — not just the mouse.
  useEffect(() => {
    const onKey = () => setPhase('gate');
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [setPhase]);

  return (
    <div
      className="fixed inset-0 z-50 flex cursor-pointer items-center justify-center bg-[var(--j53-bg)]"
      onClick={() => setPhase('gate')}
      aria-label="Boot sequence — click to skip"
    >
      <div className="w-full max-w-xl px-6">
        <div className="mb-8 flex items-center justify-center">
          <div className="h-16 w-16 rounded-full border border-[rgba(var(--j53-accent-rgb),0.35)] shadow-[0_0_30px_rgba(var(--j53-accent-rgb),0.25)] j53-pulse flex items-center justify-center">
            <div className="h-8 w-8 rounded-full bg-[radial-gradient(circle,#fff_0%,var(--j53-accent)_55%,transparent_100%)]" />
          </div>
        </div>
        <div className="font-mono text-[12.5px] leading-7 text-[var(--j53-muted)] sm:text-[13.5px]">
          {LINES.slice(0, visible).map((line, i) => (
            <div key={i} className={`j53-fadeup ${i === LINES.length - 1 ? 'text-[var(--j53-accent)]' : ''}`}>
              <span className="text-[var(--j53-accent)]/50">$ </span>
              {line}
            </div>
          ))}
          {visible < LINES.length && <span className="j53-caret text-[var(--j53-accent)]">█</span>}
        </div>
        <div className="mt-8 h-[3px] w-full overflow-hidden rounded bg-[rgba(var(--j53-accent-rgb),0.12)]">
          <div
            className="h-full bg-gradient-to-r from-[var(--j53-accent)] to-[#7af3ff] transition-all duration-300"
            style={{ width: `${Math.min(100, (visible / LINES.length) * 100)}%` }}
          />
        </div>
        <p className="j53-label mt-4 text-center">click anywhere to skip</p>
      </div>
      {granted && (
        <div className="j53-flash j53-display pointer-events-none absolute inset-0 flex items-center justify-center bg-[var(--j53-bg)]/80">
          <div className="border border-[var(--j53-accent)]/60 bg-[var(--j53-bg)]/90 px-10 py-5 text-2xl font-bold tracking-[0.3em] text-[var(--j53-accent)] shadow-[0_0_60px_rgba(var(--j53-accent-rgb),0.4)]">
            ACCESS GRANTED
          </div>
        </div>
      )}
    </div>
  );
}
