'use client';

/**
 * JARVIS 53 — Comms Deck.
 * Stark-grade WhatsApp + Gmail interfaces. JARVIS composes and hands off —
 * the human always presses the final send (privacy by design).
 * WhatsApp → validated wa.me handoff (tool: whatsapp.compose)
 * Gmail    → Gmail web compose / native Mail draft (tool: email.draft)
 */
import { useState } from 'react';
import { motion } from 'framer-motion';
import { useJarvis, type ToolEvent } from './store';
import { CheckCheck, Loader2, Mail, MessageCircle, Send, Sparkles, Wand2 } from 'lucide-react';

const WA_TEMPLATES = [
  'On my way — give me 10 minutes.',
  'Running about 15 late, so sorry! Start without me.',
  'Free to call now?',
  'Meeting confirmed. Sending the invite shortly.',
  'Reached safely. Talk tonight!',
  'Please send me the file when you get a chance.',
];

const TONES = ['Professional', 'Friendly', 'Firm', 'Apologetic', 'Excited', 'Short & direct'];

function StatusLine({ event }: { event: ToolEvent | null }) {
  if (!event) return null;
  const ok = event.status === 'done';
  return (
    <motion.p
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex items-start gap-2 rounded-lg border px-3 py-2.5 text-[12px] leading-5 ${
        ok
          ? 'border-[rgba(var(--j53-green-rgb),0.35)] bg-[rgba(var(--j53-green-rgb),0.07)] text-[var(--j53-green)]'
          : 'border-[rgba(var(--j53-red-rgb),0.35)] bg-[rgba(var(--j53-red-rgb),0.07)] text-[var(--j53-red)]'
      }`}
    >
      {ok && <CheckCheck className="mt-0.5 h-3.5 w-3.5 shrink-0" />}
      <span className="whitespace-pre-wrap">{ok ? event.output || 'Handed off successfully.' : event.output || 'Something went wrong.'}</span>
    </motion.p>
  );
}

function AIDraftBox({ channel, recipient, onDraft }: { channel: 'whatsapp' | 'email'; recipient: string; onDraft: (subject: string, body: string) => void }) {
  const phone = useJarvis((s) => s.phone);
  const [brief, setBrief] = useState('');
  const [tone, setTone] = useState(TONES[0]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function draft() {
    if (!brief.trim()) {
      setErr('Give JARVIS a brief — what should this message say?');
      return;
    }
    setErr(null);
    setBusy(true);
    try {
      const normalizedPhone = phone ? phone.replace(/[^\d+]/g, '') : '';
      const accessToken = normalizedPhone ? localStorage.getItem(`j53_access_token:${normalizedPhone}`) : null;
      if (!normalizedPhone || !accessToken) { setErr('Activate JARVIS All Access before using AI drafts.'); return; }
      const res = await fetch('/api/comms/draft', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ channel, brief, recipient: recipient || null, tone, phone: normalizedPhone, accessToken }),
      });
      const data = await res.json();
      if (!res.ok) setErr(data.error ?? 'Draft failed.');
      else onDraft(String(data.subject ?? ''), String(data.body ?? ''));
    } catch {
      setErr('Neural link unreachable — try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-xl border border-[rgba(var(--j53-accent-rgb),0.2)] bg-[rgba(var(--j53-accent-rgb),0.04)] p-3.5">
      <p className="j53-label mb-2 flex items-center gap-1.5">
        <Wand2 style={{ width: 11, height: 11 }} /> jarvis, draft it for me
      </p>
      <textarea
        className="j53-input min-h-[54px] resize-y text-[14px]"
        style={{ fontSize: 14 }}
        placeholder="e.g. tell Rahul the 4pm meeting moved to 5pm and I'll share the deck tonight"
        value={brief}
        onChange={(e) => setBrief(e.target.value)}
        maxLength={2000}
      />
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <select className="j53-input w-auto" style={{ width: 'auto', padding: '7px 10px', fontSize: 13 }} value={tone} onChange={(e) => setTone(e.target.value)} aria-label="Tone">
          {TONES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
        <button className="j53-btn" style={{ padding: '8px 14px' }} onClick={() => void draft()} disabled={busy} type="button">
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
          {busy ? 'Composing…' : 'AI Draft'}
        </button>
      </div>
      {err && <p className="mt-2 text-[12px] text-[var(--j53-red)]">{err}</p>}
    </div>
  );
}

function WhatsAppTab() {
  const executeQuick = useJarvis((s) => s.executeQuick);
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [event, setEvent] = useState<ToolEvent | null>(null);
  const [busy, setBusy] = useState(false);

  const digits = phone.replace(/[^\d+]/g, '');
  const valid = /^\+?\d{8,15}$/.test(digits);

  async function send() {
    if (!valid || !message.trim()) return;
    setBusy(true);
    setEvent(null);
    const normalized = digits.startsWith('+') ? digits : `+${digits}`;
    const ev = await executeQuick('whatsapp.compose', { phone: normalized, message: message.trim() }, true);
    setEvent(ev);
    setBusy(false);
    // If the native tool can't run here (e.g. preview server), hand off via wa.me directly.
    if (ev && ev.status !== 'done') {
      window.open(`https://wa.me/${normalized.replace('+', '')}?text=${encodeURIComponent(message.trim())}`, '_blank', 'noopener');
    }
  }

  function fallbackOpen() {
    const normalized = digits.startsWith('+') ? digits : `+${digits}`;
    window.open(`https://wa.me/${normalized.replace('+', '')}?text=${encodeURIComponent(message.trim())}`, '_blank', 'noopener');
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="j53-label mb-1.5 block" htmlFor="wa-phone">
          WhatsApp number · international
        </label>
        <input
          id="wa-phone"
          className="j53-input font-mono"
          style={{ fontSize: 15 }}
          placeholder="+91 98765 43210"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          inputMode="tel"
          autoComplete="tel"
        />
        {phone.length > 0 && !valid && <p className="mt-1.5 text-[11.5px] text-[var(--j53-gold)]">Country code + 8–15 digits, e.g. +919876543210</p>}
      </div>

      <div>
        <div className="mb-1.5 flex items-center justify-between">
          <label className="j53-label" htmlFor="wa-msg">
            Message
          </label>
          <span className="j53-label font-mono" style={{ fontSize: 8.5 }}>
            {message.length}/1000
          </span>
        </div>
        {/* chat-bubble preview styling */}
        <div className="rounded-2xl rounded-tr-sm border border-[rgba(var(--j53-green-rgb),0.3)] bg-[rgba(var(--j53-green-rgb),0.06)] p-3">
          <textarea
            id="wa-msg"
            className="w-full resize-y bg-transparent text-[14.5px] leading-6 text-[var(--j53-text)] outline-none placeholder:text-[var(--j53-muted)]"
            rows={4}
            maxLength={1000}
            placeholder="Type the message JARVIS should hand to WhatsApp…"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
        </div>
      </div>

      <div>
        <p className="j53-label mb-1.5">quick phrases</p>
        <div className="flex flex-wrap gap-1.5">
          {WA_TEMPLATES.map((t) => (
            <button key={t} className="j53-tmpl" onClick={() => setMessage(t)} type="button">
              {t}
            </button>
          ))}
        </div>
      </div>

      <AIDraftBox channel="whatsapp" recipient={phone} onDraft={(_s, body) => setMessage(body)} />

      <div className="flex flex-wrap items-center gap-2">
        <button className="j53-btn j53-glow flex-1" style={{ padding: '11px 16px' }} onClick={() => void send()} disabled={busy || !valid || !message.trim()} type="button">
          <Send className="h-3.5 w-3.5" /> {busy ? 'Handing off…' : 'Open in WhatsApp'}
        </button>
        {valid && message.trim() > '' && (
          <button className="j53-btn" style={{ padding: '11px 14px' }} onClick={fallbackOpen} type="button" aria-label="Direct wa.me link">
            Web
          </button>
        )}
      </div>

      <p className="text-[11.5px] leading-5 text-[var(--j53-muted)]">
        WhatsApp / WhatsApp Web opens with your message pre-filled — <span className="text-[var(--j53-text-2)]">you always press the final send.</span> JARVIS never sends on your behalf.
      </p>

      <StatusLine event={event} />
    </div>
  );
}

function GmailTab() {
  const executeQuick = useJarvis((s) => s.executeQuick);
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [event, setEvent] = useState<ToolEvent | null>(null);
  const [busy, setBusy] = useState(false);

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to.trim());

  function gmailUrl(): string {
    const p = new URLSearchParams({ view: 'cm', fs: '1', to: to.trim(), su: subject, body });
    return `https://mail.google.com/mail/?${p.toString()}`;
  }

  function openGmail() {
    window.open(gmailUrl(), '_blank', 'noopener');
  }

  async function mailAppDraft() {
    if (!emailValid || !subject.trim()) return;
    setBusy(true);
    setEvent(null);
    const ev = await executeQuick('email.draft', { to: to.trim(), subject: subject.trim(), body }, true);
    setEvent(ev);
    setBusy(false);
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="j53-label mb-1.5 block" htmlFor="gm-to">
          To · email address
        </label>
        <input
          id="gm-to"
          className="j53-input font-mono"
          style={{ fontSize: 15 }}
          placeholder="tony@starkindustries.com"
          value={to}
          onChange={(e) => setTo(e.target.value)}
          inputMode="email"
          autoComplete="email"
        />
        {to.length > 0 && !emailValid && <p className="mt-1.5 text-[11.5px] text-[var(--j53-gold)]">That address doesn&apos;t look complete.</p>}
      </div>

      <AIDraftBox channel="email" recipient={to} onDraft={(s, b) => { if (s && s !== 'whatsapp') setSubject(s); setBody(b); }} />

      <div>
        <label className="j53-label mb-1.5 block" htmlFor="gm-subject">
          Subject
        </label>
        <input id="gm-subject" className="j53-input" style={{ fontSize: 15 }} placeholder="Quarterly reactor output review" value={subject} onChange={(e) => setSubject(e.target.value)} maxLength={150} />
      </div>

      <div>
        <label className="j53-label mb-1.5 block" htmlFor="gm-body">
          Body
        </label>
        <textarea
          id="gm-body"
          className="j53-input min-h-[150px] resize-y leading-6"
          style={{ fontSize: 14.5 }}
          placeholder="Write it yourself, or let JARVIS draft it above…"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          maxLength={8000}
        />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button className="j53-btn j53-glow flex-1" style={{ padding: '11px 16px' }} onClick={openGmail} disabled={!emailValid || !body.trim()} type="button">
          <Mail className="h-3.5 w-3.5" /> Open in Gmail
        </button>
        <button className="j53-btn" style={{ padding: '11px 14px' }} onClick={() => void mailAppDraft()} disabled={busy || !emailValid || !subject.trim()} type="button">
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null} Mail app draft
        </button>
      </div>

      <p className="text-[11.5px] leading-5 text-[var(--j53-muted)]">
        <span className="text-[var(--j53-text-2)]">Open in Gmail</span> starts a compose window with everything pre-filled — review, attach, hit send.{' '}
        <span className="text-[var(--j53-text-2)]">Mail app draft</span> queues it in your native Mail client. Nothing is ever sent silently.
      </p>

      <StatusLine event={event} />
    </div>
  );
}

export default function Comms() {
  const [tab, setTab] = useState<'whatsapp' | 'gmail'>('whatsapp');

  return (
    <div className="mx-auto w-full max-w-3xl">
      <div className="j53-panel j53-glow overflow-hidden">
        <div className="flex items-center justify-between gap-3 border-b border-[rgba(var(--j53-accent-rgb),0.12)] px-5 py-4">
          <div>
            <p className="j53-display text-[15px] font-bold tracking-[0.2em] text-[var(--j53-text)]">
              COMMS <span className="text-[var(--j53-accent)]">DECK</span>
            </p>
            <p className="j53-label" style={{ fontSize: 8 }}>
              whatsapp · gmail · jarvis drafts, you send
            </p>
          </div>
          <span className="j53-pill j53-pill--live" style={{ fontSize: 8 }}>
            ● SECURE HANDOFF
          </span>
        </div>

        <div className="flex border-b border-[rgba(var(--j53-accent-rgb),0.12)] px-3" role="tablist" aria-label="Comms channels">
          <button className={`j53-comm-tab ${tab === 'whatsapp' ? 'active' : ''}`} onClick={() => setTab('whatsapp')} role="tab" aria-selected={tab === 'whatsapp'} type="button">
            <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
          </button>
          <button className={`j53-comm-tab ${tab === 'gmail' ? 'active' : ''}`} onClick={() => setTab('gmail')} role="tab" aria-selected={tab === 'gmail'} type="button">
            <Mail className="h-3.5 w-3.5" /> Gmail
          </button>
        </div>

        <div className="p-5" role="tabpanel">
          {tab === 'whatsapp' ? <WhatsAppTab /> : <GmailTab />}
        </div>
      </div>
    </div>
  );
}
