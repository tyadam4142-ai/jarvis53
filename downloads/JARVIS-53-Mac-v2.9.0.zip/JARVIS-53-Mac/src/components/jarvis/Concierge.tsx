'use client';

/**
 * JARVIS 53 — AI Concierge (automated customer service) + human ticket handoff.
 */
import { useEffect, useRef, useState } from 'react';
import { useJarvis } from './store';
import { Bot, LifeBuoy, Send, Ticket } from 'lucide-react';

interface Turn {
  who: 'me' | 'j';
  text: string;
}

interface MyTicket {
  id: number;
  subject: string;
  status: string;
  replies: Array<{ author: string; body: string; createdAt: string }>;
}

export default function Concierge() {
  const phone = useJarvis((s) => s.phone);
  const [turns, setTurns] = useState<Turn[]>([
    {
      who: 'j',
      text: "Hi! I'm the J-53 Concierge — your automated support agent. Ask me about setup, features, or troubleshooting. I can open a human support ticket when needed.",
    },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [tickets, setTickets] = useState<MyTicket[]>([]);
  const [showTickets, setShowTickets] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [turns, showTickets]);

  async function loadTickets() {
    if (!phone) return;
    try {
      const normalizedPhone = phone.replace(/[^\d+]/g, '');
      const accessToken = localStorage.getItem(`j53_access_token:${normalizedPhone}`);
      if (!accessToken) { setTurns((t) => [...t, { who: 'j', text: 'This installation needs a valid activation token. Please reactivate or contact support.' }]); return; }
      const res = await fetch(`/api/support/tickets?phone=${encodeURIComponent(normalizedPhone)}`, { cache: 'no-store', headers: { authorization: `Bearer ${accessToken}` } });
      const data = await res.json();
      setTickets(data.tickets ?? []);
      setShowTickets(true);
    } catch {
      /* ignore */
    }
  }

  async function ask(text: string) {
    if (!text.trim() || busy) return;
    setTurns((t) => [...t, { who: 'me', text }]);
    setInput('');
    setBusy(true);
    try {
      const normalizedPhone = phone ? phone.replace(/[^\d+]/g, '') : '';
      const accessToken = normalizedPhone ? localStorage.getItem(`j53_access_token:${normalizedPhone}`) : null;
      if (!normalizedPhone || !accessToken) { setTurns((t) => [...t, { who: 'j', text: 'Activate JARVIS All Access before using support chat.' }]); return; }
      const res = await fetch('/api/support/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ phone: normalizedPhone, accessToken, message: text, history: turns.slice(-6).map((t) => ({ role: t.who === 'me' ? 'user' : 'assistant', content: t.text })) }),
      });
      const data = await res.json();
      setTurns((t) => [...t, { who: 'j', text: data.text ?? 'My apologies — the concierge is unreachable right now.' }]);
      if (data.ticketId) setTickets((prev) => prev);
    } catch {
      setTurns((t) => [...t, { who: 'j', text: 'Network issue — please retry in a moment.' }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="h-4 w-4 text-[var(--j53-accent)]" />
          <span className="j53-display text-[11px] tracking-[0.18em] text-[var(--j53-accent)]">J-53 CONCIERGE</span>
          <span className="j53-pill j53-pill--live" style={{ fontSize: 8 }}>
            AI · 24/7
          </span>
        </div>
        <button className="j53-btn" style={{ padding: '5px 10px' }} onClick={() => (showTickets ? setShowTickets(false) : loadTickets())} type="button">
          <Ticket className="h-3.5 w-3.5" /> {showTickets ? 'Chat' : 'My tickets'}
        </button>
      </div>

      {showTickets ? (
        <div className="j53-scroll min-h-0 flex-1 space-y-3 overflow-y-auto pr-1">
          {tickets.length === 0 && <p className="text-xs text-[var(--j53-muted)]">No tickets yet. The concierge opens one automatically when a human needs to step in.</p>}
          {tickets.map((t) => (
            <div key={t.id} className="j53-panel p-3">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-[13px] font-semibold text-[var(--j53-text)]">{t.subject}</p>
                <span className="j53-pill" style={{ fontSize: 8, color: t.status === 'closed' ? 'var(--j53-muted)' : 'var(--j53-gold)' }}>
                  {t.status.toUpperCase()}
                </span>
              </div>
              <div className="mt-2 space-y-2">
                {t.replies.map((r, i) => (
                  <div key={i} className={`rounded-md px-2.5 py-2 text-[12.5px] leading-5 ${r.author === 'admin' ? 'border border-[rgba(var(--j53-accent-rgb),0.2)] bg-[rgba(var(--j53-accent-rgb),0.06)] text-[var(--j53-text)]' : r.author === 'ai' ? 'bg-[rgba(var(--j53-green-rgb),0.06)] text-[var(--j53-text-2)]' : 'bg-[rgba(255,255,255,0.03)] text-[var(--j53-text-2)]'}`}>
                    <span className="j53-label mr-1.5" style={{ fontSize: 8 }}>
                      {r.author === 'admin' ? 'SUPPORT DESK' : r.author === 'ai' ? 'CONCIERGE' : 'YOU'}
                    </span>
                    {r.body}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <>
          <div ref={scrollRef} className="j53-scroll min-h-0 flex-1 space-y-3 overflow-y-auto pr-1">
            {turns.map((t, i) => (
              <div key={i} className={`j53-fadeup flex ${t.who === 'me' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[88%] rounded-xl px-3.5 py-2.5 text-[13.5px] leading-5.5 whitespace-pre-wrap ${
                    t.who === 'me'
                      ? 'rounded-br-sm border border-[rgba(var(--j53-accent-rgb),0.25)] bg-[rgba(var(--j53-accent-rgb),0.07)] text-[var(--j53-text)]'
                      : 'j53-panel text-[var(--j53-text-2)]'
                  }`}
                >
                  {t.text}
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex justify-start">
                <div className="j53-panel flex items-center gap-2 px-3.5 py-2.5">
                  <span className="j53-spinner" />
                  <span className="j53-typing">
                    <span />
                    <span />
                    <span />
                  </span>
                </div>
              </div>
            )}
          </div>
          <div className="mt-2 flex gap-2">
            <input
              className="j53-input flex-1"
              placeholder="Ask the concierge anything…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') ask(input);
              }}
              aria-label="Message the concierge"
            />
            <button className="j53-btn" style={{ padding: '11px 14px' }} onClick={() => ask(input)} disabled={busy || !input.trim()} aria-label="Send" type="button">
              <Send className="h-4 w-4" />
            </button>
          </div>
          <p className="mt-1.5 flex items-center gap-1 text-[10.5px] text-[var(--j53-muted)]">
            <LifeBuoy className="h-3 w-3" /> Escalates to a human automatically when needed.
          </p>
        </>
      )}
    </div>
  );
}
