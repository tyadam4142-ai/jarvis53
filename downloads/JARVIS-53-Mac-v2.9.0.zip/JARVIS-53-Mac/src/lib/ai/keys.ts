/**
 * JARVIS 53 multi-provider AI key pool.
 * Supports OpenRouter, NVIDIA NIM, and Google Gemini using OpenAI-compatible endpoints.
 * Keys are kept server-side; raw values are never returned to the browser.
 * Successful requests rotate through providers/keys using least-recently-used selection.
 */
import { randomUUID } from 'crypto';
import { promises as fs } from 'fs';
import path from 'path';

export type AIProvider = 'openrouter' | 'nvidia' | 'gemini';
export type KeySource = 'admin' | 'env';

export interface PoolKey {
  id: string;
  provider: AIProvider;
  key: string;
  source: KeySource;
  addedAt: string;
  lastUsedAt: string | null;
  failures: number;
  cooldownUntil: number | null;
  calls: number;
}

interface PoolFile {
  keys: PoolKey[];
}

export interface CloudChatResult {
  text: string;
  provider: AIProvider;
  model: string;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const POOL_FILE = path.join(DATA_DIR, 'keys.json');
const PROVIDERS: AIProvider[] = ['openrouter', 'nvidia', 'gemini'];
const DEFAULT_MODELS: Record<AIProvider, string> = {
  openrouter: 'z-ai/glm-5.3-flash',
  nvidia: 'meta/llama-3.1-8b-instruct',
  // BUG-006 fix: one supported default across desktop + control plane (override with GEMINI_MODEL).
  gemini: 'gemini-2.5-flash',
};
const ENDPOINTS: Record<AIProvider, string> = {
  openrouter: 'https://openrouter.ai/api/v1/chat/completions',
  nvidia: 'https://integrate.api.nvidia.com/v1/chat/completions',
  gemini: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
};

let cache: PoolFile | null = null;

async function ensureDir(): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true, mode: 0o700 });
  await fs.chmod(DATA_DIR, 0o700).catch(() => undefined);
}

function isProvider(value: unknown): value is AIProvider {
  return typeof value === 'string' && PROVIDERS.includes(value as AIProvider);
}

function emptyKey(provider: AIProvider, key: string, source: KeySource): PoolKey {
  return {
    id: randomUUID(),
    provider,
    key,
    source,
    addedAt: new Date().toISOString(),
    lastUsedAt: null,
    failures: 0,
    cooldownUntil: null,
    calls: 0,
  };
}

function readEnvKeys(provider: AIProvider): PoolKey[] {
  const rawByProvider: Record<AIProvider, string> = {
    openrouter: process.env.OPENROUTER_API_KEYS || process.env.OPENROUTER_API_KEY || '',
    nvidia: process.env.NVIDIA_API_KEYS || process.env.NVIDIA_API_KEY || '',
    gemini: process.env.GEMINI_API_KEYS || process.env.GEMINI_API_KEY || process.env.GOOGLE_GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '',
  };
  return rawByProvider[provider]
    .split(',')
    .map((key) => key.trim())
    .filter((key) => key.length >= 20)
    .map((key) => emptyKey(provider, key, 'env'));
}

function normalizeSavedKey(raw: Partial<PoolKey> & { key?: string }): PoolKey | null {
  if (typeof raw.key !== 'string' || raw.key.trim().length < 20) return null;
  // Existing v2.2.0 key files had no provider field; safely migrate them as OpenRouter keys.
  const provider: AIProvider = isProvider(raw.provider) ? raw.provider : 'openrouter';
  return {
    id: typeof raw.id === 'string' && raw.id.length > 0 ? raw.id : randomUUID(),
    provider,
    key: raw.key.trim(),
    source: 'admin',
    addedAt: typeof raw.addedAt === 'string' ? raw.addedAt : new Date().toISOString(),
    lastUsedAt: typeof raw.lastUsedAt === 'string' ? raw.lastUsedAt : null,
    failures: Number.isFinite(raw.failures) ? Math.max(0, Number(raw.failures)) : 0,
    cooldownUntil: Number.isFinite(raw.cooldownUntil) ? Number(raw.cooldownUntil) : null,
    calls: Number.isFinite(raw.calls) ? Math.max(0, Number(raw.calls)) : 0,
  };
}

async function load(): Promise<PoolFile> {
  if (cache) return cache;
  let saved: PoolKey[] = [];
  try {
    const raw = await fs.readFile(POOL_FILE, 'utf8');
    const parsed = JSON.parse(raw) as { keys?: Array<Partial<PoolKey> & { key?: string }> };
    saved = Array.isArray(parsed.keys)
      ? parsed.keys.map(normalizeSavedKey).filter((key): key is PoolKey => Boolean(key))
      : [];
  } catch {
    saved = [];
  }

  // Environment keys are in-memory entries and are not copied into keys.json.
  const merged = [...saved];
  for (const provider of PROVIDERS) {
    for (const envKey of readEnvKeys(provider)) {
      if (!merged.some((savedKey) => savedKey.provider === provider && savedKey.key === envKey.key)) merged.push(envKey);
    }
  }
  cache = { keys: merged };
  return cache;
}

async function save(): Promise<void> {
  if (!cache) return;
  await ensureDir();
  const persisted = cache.keys.filter((key) => key.source === 'admin');
  await fs.writeFile(POOL_FILE, JSON.stringify({ keys: persisted }, null, 2), { encoding: 'utf8', mode: 0o600 });
  await fs.chmod(POOL_FILE, 0o600).catch(() => undefined);
}

export function providerLabel(provider: AIProvider): string {
  return provider === 'nvidia' ? 'NVIDIA NIM' : provider === 'gemini' ? 'Google Gemini' : 'OpenRouter';
}

export function modelForProvider(provider: AIProvider): string {
  const envName: Record<AIProvider, string> = {
    openrouter: 'OPENROUTER_MODEL',
    nvidia: 'NVIDIA_MODEL',
    gemini: 'GEMINI_MODEL',
  };
  return (process.env[envName[provider]] || DEFAULT_MODELS[provider]).trim();
}

export function maskKey(_key: string): string {
  // Never return any fragment of a provider secret to the UI. `id` is the stable removal handle.
  return '•••••••• (hidden)';
}

export async function poolStatus(): Promise<Array<Omit<PoolKey, 'key'> & { masked: string; healthy: boolean }>> {
  const pool = await load();
  const now = Date.now();
  return pool.keys.map((key) => ({
    id: key.id,
    provider: key.provider,
    source: key.source,
    masked: maskKey(key.key),
    addedAt: key.addedAt,
    lastUsedAt: key.lastUsedAt,
    failures: key.failures,
    cooldownUntil: key.cooldownUntil,
    calls: key.calls,
    healthy: !key.cooldownUntil || key.cooldownUntil < now,
  }));
}

export async function poolCount(): Promise<{ total: number; healthy: number; byProvider: Record<AIProvider, { total: number; healthy: number }> }> {
  const pool = await load();
  const now = Date.now();
  const byProvider: Record<AIProvider, { total: number; healthy: number }> = {
    openrouter: { total: 0, healthy: 0 },
    nvidia: { total: 0, healthy: 0 },
    gemini: { total: 0, healthy: 0 },
  };
  for (const key of pool.keys) {
    byProvider[key.provider].total += 1;
    if (!key.cooldownUntil || key.cooldownUntil < now) byProvider[key.provider].healthy += 1;
  }
  return {
    total: pool.keys.length,
    healthy: pool.keys.filter((key) => !key.cooldownUntil || key.cooldownUntil < now).length,
    byProvider,
  };
}

export async function addKey(provider: AIProvider, key: string): Promise<boolean> {
  if (!isProvider(provider)) return false;
  const trimmed = key.trim();
  if (trimmed.length < 20) return false;
  const pool = await load();
  if (pool.keys.some((entry) => entry.provider === provider && entry.key === trimmed)) return false;
  pool.keys.push(emptyKey(provider, trimmed, 'admin'));
  await save();
  return true;
}

export async function removeKey(provider: AIProvider, keyId: string): Promise<boolean> {
  if (!isProvider(provider)) return false;
  const pool = await load();
  const before = pool.keys.length;
  // Environment variables are intentionally not removable in the UI; edit .env to disable them.
  pool.keys = pool.keys.filter((entry) => !(entry.source === 'admin' && entry.provider === provider && entry.id === keyId));
  await save();
  return pool.keys.length < before;
}

function keyIdentity(key: PoolKey): string {
  return `${key.provider}:${key.key}`;
}

/**
 * Rotate across provider families before using a second key from one provider.
 * Within the chosen provider, use its least-recently-used healthy key.
 */
async function nextKey(excluded: Set<string>, attemptedProviders: Set<AIProvider>): Promise<PoolKey | null> {
  const pool = await load();
  const now = Date.now();
  const available = pool.keys.filter((key) => (!key.cooldownUntil || key.cooldownUntil < now) && !excluded.has(keyIdentity(key)));
  if (!available.length) return null;

  const untriedProviders = available.filter((key) => !attemptedProviders.has(key.provider));
  const candidates = untriedProviders.length ? untriedProviders : available;
  const providerLastUse = (provider: AIProvider): number => {
    const dates = pool.keys
      .filter((key) => key.provider === provider && key.lastUsedAt)
      .map((key) => Date.parse(key.lastUsedAt as string));
    return dates.length ? Math.max(...dates) : 0;
  };
  candidates.sort((a, b) => {
    const providerDelta = providerLastUse(a.provider) - providerLastUse(b.provider);
    if (providerDelta !== 0) return providerDelta;
    const aTime = a.lastUsedAt ? Date.parse(a.lastUsedAt) : 0;
    const bTime = b.lastUsedAt ? Date.parse(b.lastUsedAt) : 0;
    return aTime - bTime || PROVIDERS.indexOf(a.provider) - PROVIDERS.indexOf(b.provider) || a.addedAt.localeCompare(b.addedAt);
  });
  return candidates[0];
}

async function markUsed(key: PoolKey): Promise<void> {
  key.lastUsedAt = new Date().toISOString();
  key.calls += 1;
  key.failures = 0;
  key.cooldownUntil = null;
  await save();
}

async function markFailure(key: PoolKey, isRateLimit = false): Promise<void> {
  key.lastUsedAt = new Date().toISOString();
  key.failures += 1;
  // Cooldown keys that appear broken/rate-limited, but keep rotating to other providers immediately.
  if (isRateLimit || key.failures >= 2) key.cooldownUntil = Date.now() + 5 * 60 * 1000;
  await save();
}

/**
 * Send one chat request and automatically fail over across configured API keys/providers.
 * `validate` lets structured tasks reject malformed model output and try another cloud route.
 */
export async function cloudChat(
  messages: Array<{ role: string; content: string }>,
  opts: { temperature?: number; maxTokens?: number; maxAttempts?: number; validate?: (text: string) => boolean } = {},
): Promise<CloudChatResult> {
  const pool = await load();
  const maxAttempts = Math.max(1, Math.min(opts.maxAttempts ?? 6, pool.keys.length || 1, 6));
  const attempted = new Set<string>();
  const attemptedProviders = new Set<AIProvider>();
  const errors: string[] = [];

  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    const key = await nextKey(attempted, attemptedProviders);
    if (!key) break;
    attempted.add(keyIdentity(key));
    attemptedProviders.add(key.provider);
    const model = modelForProvider(key.provider);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    try {
      const headers: Record<string, string> = {
        authorization: `Bearer ${key.key}`,
        'content-type': 'application/json',
      };
      if (key.provider === 'openrouter') {
        headers['http-referer'] = process.env.JARVIS_SITE_URL || 'https://53.jarvis53.dynamicrobotics53.com';
        headers['x-title'] = 'JARVIS 53';
      }
      const response = await fetch(ENDPOINTS[key.provider], {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model,
          messages,
          temperature: opts.temperature ?? 0.2,
          max_tokens: opts.maxTokens ?? 1200,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const detail = (await response.text()).slice(0, 240).replace(/\s+/g, ' ').trim();
        const message = `${providerLabel(key.provider)} HTTP ${response.status}${detail ? `: ${detail}` : ''}`;
        errors.push(message);
        await markFailure(key, response.status === 429);
        continue;
      }

      const json = await response.json() as {
        choices?: Array<{ message?: { content?: string | Array<{ type?: string; text?: string }> } }>;
        error?: { message?: string };
      };
      const content = json.choices?.[0]?.message?.content;
      const text = typeof content === 'string'
        ? content.trim()
        : Array.isArray(content)
          ? content.map((part) => part.text ?? '').join('').trim()
          : '';
      if (!text) {
        errors.push(`${providerLabel(key.provider)} returned an empty response`);
        await markFailure(key);
        continue;
      }
      await markUsed(key);
      if (opts.validate && !opts.validate(text)) {
        errors.push(`${providerLabel(key.provider)} returned an unreadable response; trying another provider`);
        continue;
      }
      return { text, provider: key.provider, model };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown request error';
      errors.push(`${providerLabel(key.provider)} ${message.includes('aborted') ? 'timed out after 15 seconds' : message}`);
      await markFailure(key);
    } finally {
      clearTimeout(timer);
    }
  }

  if (!pool.keys.length) throw new Error('No cloud API keys are configured. Add OpenRouter, NVIDIA NIM, or Gemini keys in Admin → AI Keys.');
  const summary = errors.slice(-4).join(' | ');
  throw new Error(summary || 'No available API keys. All configured keys may be in cooldown; try again shortly.');
}
