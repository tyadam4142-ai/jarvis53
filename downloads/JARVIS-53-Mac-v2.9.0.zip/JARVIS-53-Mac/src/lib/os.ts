/**
 * JARVIS 53 — OS abstraction layer.
 * Hardened execution primitives: every user-supplied value is either passed as a
 * separate argv element (execFile) or escaped for the target script runtime.
 * Shell injection is prevented by construction — never concatenate raw input.
 */
import { execFile, exec, spawn } from 'child_process';
import os from 'os';
import path from 'path';

export const IS_MAC = process.platform === 'darwin';
export const IS_WIN = process.platform === 'win32';
export const IS_LINUX = process.platform === 'linux';
export const PLATFORM: 'mac' | 'win' | 'linux' = IS_MAC ? 'mac' : IS_WIN ? 'win' : 'linux';
export const HOME = os.homedir();
export const PLATFORM_LABEL =
  PLATFORM === 'mac'
    ? `macOS ${os.release()}`
    : PLATFORM === 'win'
      ? `Windows ${os.release()}`
      : `Linux ${os.release()}`;

export interface ExecResult {
  code: number;
  stdout: string;
  stderr: string;
}

/** Execute a binary with argument array — no shell interpolation. */
export function execCmd(cmd: string, args: string[], timeoutMs = 15000): Promise<ExecResult> {
  return new Promise((resolve) => {
    execFile(
      cmd,
      args,
      { timeout: timeoutMs, windowsHide: true, maxBuffer: 8 * 1024 * 1024, encoding: 'utf8' },
      (err, stdout, stderr) => {
        const code = err && typeof (err as NodeJS.ErrnoException & { code?: number }).code === 'number' ? (err as unknown as { code: number }).code : err ? 1 : 0;
        resolve({ code: code ?? 0, stdout: String(stdout ?? ''), stderr: String(stderr ?? '') });
      }
    );
  });
}

/** Execute an internally-constructed shell line (input MUST be pre-escaped). */
export function execShell(script: string, timeoutMs = 15000): Promise<ExecResult> {
  return new Promise((resolve) => {
    exec(script, { timeout: timeoutMs, windowsHide: true, maxBuffer: 8 * 1024 * 1024 }, (err, stdout, stderr) => {
      resolve({ code: err ? (err as { code?: number }).code || 1 : 0, stdout: String(stdout ?? ''), stderr: String(stderr ?? '') });
    });
  });
}

/** Shell execution pinned to a working directory (used by dev.run_command). */
export function execShellCwd(script: string, cwd: string, timeoutMs = 15000): Promise<ExecResult> {
  return new Promise((resolve) => {
    exec(script, { cwd, timeout: timeoutMs, windowsHide: true, maxBuffer: 8 * 1024 * 1024 }, (err, stdout, stderr) => {
      resolve({ code: err ? (err as { code?: number }).code || 1 : 0, stdout: String(stdout ?? ''), stderr: String(stderr ?? '') });
    });
  });
}

/** Fire-and-forget detached command (used for TTS / UI gestures). */
export function spawnDetached(cmd: string, args: string[]) {
  try {
    const child = spawn(cmd, args, { detached: true, stdio: 'ignore', windowsHide: true });
    child.unref();
    return true;
  } catch {
    return false;
  }
}

/** Execute a binary feeding stdin (pbcopy / Set-Content alternatives). */
export function execWithInput(cmd: string, args: string[], input: string, timeoutMs = 10000): Promise<ExecResult> {
  return new Promise((resolve) => {
    try {
      const child = execFile(cmd, args, { timeout: timeoutMs, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
        resolve({ code: err ? 1 : 0, stdout: String(stdout ?? ''), stderr: String(stderr ?? '') });
      });
      child.stdin?.end(input, 'utf8');
    } catch (e) {
      resolve({ code: 1, stdout: '', stderr: String(e) });
    }
  });
}

/* ─────────────────────────── Path sandbox ─────────────────────────── */

const MAC_BLOCKED = ['/system', '/library', '/private', '/etc', '/usr', '/bin', '/sbin', '/var', '/volumes', '/dev', '/cores', '/opt', '/.spotlight'];
const WIN_BLOCKED = ['c:\\windows', 'c:\\program files', 'c:\\program files (x86)', 'c:\\programdata', 'c:\\users', 'c:\\apps', 'c:\\boot', 'c:\\recovery'];

export function resolvePath(p: string): string {
  if (!p) return HOME;
  let expanded = p.trim();
  if (expanded.startsWith('~')) expanded = path.join(HOME, expanded.slice(1));
  if (IS_WIN && /^~/.test(expanded)) expanded = path.join(HOME, expanded.slice(1));
  return path.resolve(expanded.startsWith('"') ? expanded.slice(1, -1) : expanded);
}

export function isPathSafe(p: string): { safe: boolean; reason?: string } {
  const raw = String(p || '').trim().replace(/^"|"$/g, '');
  // Detect Windows-style paths from the RAW input: path.resolve() on a non-Windows
  // host would treat "C:\..." as a relative segment and destroy the evidence.
  const looksWindows = /^[a-z]:[\\/]/i.test(raw);
  const resolved = resolvePath(p).toLowerCase();
  if (!resolved || resolved === '/' || /^[a-z]:\\?$/.test(resolved) || /^[a-z]:\\?$/.test(raw.toLowerCase())) {
    return { safe: false, reason: 'Root paths are protected by the JARVIS safety engine.' };
  }
  // Windows blocklist applies to Windows hosts AND to Windows-style path input on any host.
  if (looksWindows) {
    const winNorm = raw.toLowerCase().replace(/\//g, '\\').replace(/\\+$/, '');
    for (const b of WIN_BLOCKED) {
      if (winNorm === b || winNorm.startsWith(`${b}\\`)) {
        return { safe: false, reason: `Protected system location: ${winNorm}` };
      }
    }
  }
  const blocked = IS_WIN ? WIN_BLOCKED : MAC_BLOCKED;
  const separator = IS_WIN ? '\\' : '/';
  for (const b of blocked) {
    if (resolved === b || resolved.startsWith(b + separator)) {
      return { safe: false, reason: `Protected system location: ${resolved}` };
    }
  }
  // Never allow destructive ops targeting the home directory itself
  if (resolved === HOME.toLowerCase()) {
    return { safe: false, reason: 'Your home folder itself is protected.' };
  }
  return { safe: true };
}

/* ─────────────────────────── Escapers ─────────────────────────── */

/** Escape a value for embedding inside a double-quoted AppleScript string. */
export function escApple(s: string): string {
  return String(s)
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\r?\n/g, '\\n');
}

/** Escape a value for a single-quoted PowerShell literal. */
export function escPs(s: string): string {
  return String(s).replace(/'/g, "''").replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');
}

/** Escape for sh double quotes (osascript -e argument building). */
export function escSh(s: string): string {
  return String(s).replace(/([$`"\\])/g, '\\$1').replace(/\r?\n/g, '\\n');
}

/** Sanitize an app name to a safe argv token (letters, digits, spaces, some punct). */
export function safeToken(s: string, max = 120): string {
  return String(s)
    .replace(/["'`$;|&><\n\r\\]/g, '')
    .trim()
    .slice(0, max);
}

/** Basic URL-encode for query strings. */
export function enc(s: string): string {
  return encodeURIComponent(String(s));
}

/** Fetch JSON with timeout — server-side only. */
export async function fetchJson<T = unknown>(url: string, timeoutMs = 8000): Promise<T | null> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), timeoutMs);
    const res = await fetch(url, { signal: ctl.signal, headers: { 'user-agent': 'JARVIS53/2.0' } });
    clearTimeout(t);
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

export async function fetchText(url: string, timeoutMs = 8000): Promise<string | null> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), timeoutMs);
    const res = await fetch(url, { signal: ctl.signal, headers: { 'user-agent': 'JARVIS53/2.0' } });
    clearTimeout(t);
    return await res.text();
  } catch {
    return null;
  }
}

export function fmtBytes(n: number): string {
  if (!Number.isFinite(n)) return '—';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

export function toolUnavailable(tool: string, needs: 'mac' | 'win'): ExecResult {
  return {
    code: 2,
    stdout: '',
    stderr: `"${tool}" is a native ${needs === 'mac' ? 'macOS' : 'Windows'} automation. Run JARVIS 53 on ${needs === 'mac' ? 'a Mac' : 'Windows'} to unlock it.`,
  };
}
