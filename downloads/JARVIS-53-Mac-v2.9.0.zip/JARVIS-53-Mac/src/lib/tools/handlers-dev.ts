/**
 * JARVIS 53 — shared dev/coding tool handlers (BUG-005 fix).
 * Platform-neutral implementations used by both the macOS and Windows handler
 * maps. Everything returns the REAL result of a REAL filesystem/process
 * operation — these handlers never fabricate success.
 */
import { promises as fs } from 'fs';
import path from 'path';
import { resolvePath, isPathSafe, execShellCwd, execShell, execCmd, fmtBytes, IS_WIN } from '../os';
import type { ExecResult } from '../os';

type Args = Record<string, unknown>;
type Handler = (a: Args) => Promise<ExecResult>;

const ok = (stdout: string): ExecResult => ({ code: 0, stdout, stderr: '' });
const fail = (stderr: string): ExecResult => ({ code: 1, stdout: '', stderr });

const str = (a: Args, k: string, d = ''): string => (a[k] === undefined || a[k] === null ? d : String(a[k]));

/** Commands that would destroy a system volume or are pure fork bombs — always refused. */
const DESTRUCTIVE_PATTERNS: RegExp[] = [
  /\brm\s+(-[a-z-]*\s+)*-[a-z-]*[rf][a-z-]*\s+(\/|~)(\s|$)/i, // rm -rf / or ~
  /mkfs(\.|\s)/i,
  /:\(\)[\s\S]*\{[\s\S]*\};\s*:/, // fork bomb
  /\bdiskutil\s+erase/i,
  /\bformat\s+[a-z]:/i,
  /remove-item\s+.*-recurse.*\s-[a-z]*force.*\s(hkml?|c:\\)\s?\\/i,
  /\breg\s+delete\s+hklm/i,
  /\bdd\s+if=.*of=\/dev\/(disk|sd)/i,
  /\bshutdown\b|\breboot\b|\bpoweroff\b/i, // system.power tools exist separately with their own confirm
  /\bgit\s+push\s+.*--force/i,
];

/* ── files.edit — exact-text in-place edit with occurrence accounting ── */
export const filesEdit: Handler = async (a) => {
  const p = resolvePath(str(a, 'path'));
  const guard = isPathSafe(p);
  if (!guard.safe) return fail(guard.reason!);
  const find = str(a, 'find');
  const replace = str(a, 'replace');
  if (!find) return fail('Nothing to find — pass the exact text to replace.');
  let current: string;
  try {
    current = await fs.readFile(p, 'utf8');
  } catch (e) {
    return fail(`Could not read ${p}: ${(e as Error).message}`);
  }
  if (current.length > 2_000_000) return fail('File is too large for a safe in-place text edit (2 MB limit).');
  const occurrences = current.split(find).length - 1;
  if (occurrences === 0) return fail(`The text to find was not found in ${path.basename(p)}. Read the file with files.read first, then retry with the exact text.`);
  const all = a.all === true || a.all === 'true';
  if (occurrences > 1 && !all) {
    return fail(`Found ${occurrences} occurrences of the search text. Pass all=true to replace every occurrence, or include more surrounding text so the match is unique.`);
  }
  const next = all ? current.split(find).join(replace) : current.replace(find, () => replace);
  try {
    await fs.writeFile(p, next, 'utf8');
  } catch (e) {
    return fail(`Write failed: ${(e as Error).message}`);
  }
  return ok(`${all ? 'Replaced all' : 'Replaced'} ${all ? occurrences : 1} occurrence${occurrences === 1 && !all ? '' : 's'} in ${p} (file is now ${fmtBytes(Buffer.byteLength(next))}).`);
};

/* ── files.search_content — grep-style content search ── */
export const filesSearchContent: Handler = async (a) => {
  const query = str(a, 'query').trim();
  if (!query) return fail('Give a text query to search for.');
  const dir = resolvePath(str(a, 'folder') || '~');
  const guard = isPathSafe(dir);
  if (!guard.safe) return fail(guard.reason!);
  let stat;
  try {
    stat = await fs.stat(dir);
  } catch {
    return fail(`Folder not found: ${dir}`);
  }
  if (!stat.isDirectory()) return fail(`Not a folder: ${dir}`);
  if (IS_WIN) {
    // PowerShell: recursive Select-String, skipping common junk folders.
    const esc = (s: string) => s.replace(/'/g, "''");
    const script = `$ErrorActionPreference='SilentlyContinue'; Get-ChildItem -LiteralPath '${esc(dir)}' -Recurse -File -Depth 6 | Where-Object { $_.FullName -notmatch '\\\\(node_modules|\\.git|\\.next|dist|build)\\\\' } | Select-String -Pattern '${esc(query)}' -SimpleMatch -List | Select-Object -First 25 Path,LineNumber | ForEach-Object { "$($_.Path):$($_.LineNumber)" }`;
    const r = await execShell(script, 20000);
    if (r.code !== 0 && !r.stdout.trim()) return fail(`Content search failed: ${r.stderr.trim() || 'no matches'}`);
    return ok(r.stdout.trim() ? `Matches:\n${r.stdout.trim()}` : 'No matches found.');
  }
  // macOS / Linux: prefer ripgrep when present, fall back to grep.
  const rg = await execShellCwd(`command -v rg >/dev/null 2>&1 && echo yes || echo no`, dir, 2000);
  if (rg.stdout.trim() === 'yes') {
    const r = await execCmd('rg', ['-n', '--max-count', '3', '--max-filesize', '1M', '--glob', '!{node_modules,.git,.next,dist,build}/**', '-m', '25', '--no-heading', '-e', query, dir], 20000);
    if (r.code === 2) return fail(`Content search failed: ${r.stderr.trim()}`);
    return ok(r.stdout.trim() ? `Matches:\n${r.stdout.trim().split('\n').slice(0, 25).join('\n')}` : 'No matches found.');
  }
  const r2 = await execCmd('grep', ['-rnI', '--exclude-dir=node_modules', '--exclude-dir=.git', '--exclude-dir=.next', '-m', '3', '-e', query, dir], 20000);
  return ok(r2.stdout.trim() ? `Matches:\n${r2.stdout.trim().split('\n').slice(0, 25).join('\n')}` : 'No matches found.');
};

/* ── dev.run_command — approval-gated, cwd-pinned, real exit code ── */
export const devRunCommand: Handler = async (a) => {
  const command = str(a, 'command').trim();
  if (!command) return fail('No command given.');
  if (command.length > 1000) return fail('Command is too long (1000-character limit).');
  for (const pattern of DESTRUCTIVE_PATTERNS) {
    if (pattern.test(command)) return fail(`Refused for safety: this command matches a protected destructive pattern. JARVIS will not run it. If it is truly required, run it yourself in a terminal.`);
  }
  const dir = resolvePath(str(a, 'cwd') || '~');
  const guard = isPathSafe(dir);
  if (!guard.safe) return fail(guard.reason!);
  try {
    (await fs.stat(dir)).isDirectory();
  } catch {
    return fail(`Working folder not found: ${dir}`);
  }
  const timeoutMs = 120_000;
  const result = await execShellCwd(command, dir, timeoutMs);
  const stdout = result.stdout.trim();
  const stderr = result.stderr.trim();
  const body = [
    `exit code: ${result.code}`,
    stdout ? `stdout:\n${stdout.slice(0, 8000)}` : 'stdout: (empty)',
    stderr ? `stderr:\n${stderr.slice(0, 4000)}` : 'stderr: (empty)',
  ].join('\n');
  return result.code === 0 ? ok(body) : fail(body);
};

/* ── dev.inspect_project — bounded tree + manifest summary ── */
const SKIP_DIRS = new Set(['node_modules', '.git', '.next', 'dist', 'build', '.venv', 'venv', '__pycache__', '.cache', 'target']);

async function walkTree(root: string, depth: number, budget: { count: number }): Promise<string[]> {
  const lines: string[] = [];
  const walk = async (dir: string, level: number, prefix: string): Promise<void> => {
    if (level > depth || budget.count <= 0) return;
    let entries;
    try {
      entries = await fs.readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    entries.sort((x, y) => Number(y.isDirectory()) - Number(x.isDirectory()) || x.name.localeCompare(y.name));
    for (const entry of entries) {
      if (budget.count <= 0) {
        lines.push(`${prefix}… (listing truncated)`);
        return;
      }
      budget.count -= 1;
      if (entry.isDirectory()) {
        if (SKIP_DIRS.has(entry.name)) {
          lines.push(`${prefix}${entry.name}/ (skipped)`);
          continue;
        }
        lines.push(`${prefix}${entry.name}/`);
        await walk(path.join(dir, entry.name), level + 1, `${prefix}  `);
      } else {
        lines.push(`${prefix}${entry.name}`);
      }
    }
  };
  await walk(root, 0, '');
  return lines;
}

export const devInspectProject: Handler = async (a) => {
  const dir = resolvePath(str(a, 'path') || '~');
  const guard = isPathSafe(dir);
  if (!guard.safe) return fail(guard.reason!);
  let stat;
  try {
    stat = await fs.stat(dir);
  } catch {
    return fail(`Folder not found: ${dir}`);
  }
  if (!stat.isDirectory()) return fail(`Not a folder: ${dir}`);
  const budget = { count: 250 };
  const tree = await walkTree(dir, 2, budget);
  const manifests = ['package.json', 'requirements.txt', 'pyproject.toml', 'README.md'];
  const manifestChunks: string[] = [];
  for (const name of manifests) {
    const file = path.join(dir, name);
    try {
      const content = await fs.readFile(file, 'utf8');
      manifestChunks.push(`--- ${name} (first 45 lines) ---\n${content.split('\n').slice(0, 45).join('\n')}`);
    } catch {
      /* manifest not present */
    }
  }
  return ok(`Project: ${dir}\n\nTree:\n${tree.join('\n') || '(empty folder)'}\n\n${manifestChunks.join('\n\n') || '(no package.json / requirements.txt / pyproject.toml / README.md found)'}`);
};
