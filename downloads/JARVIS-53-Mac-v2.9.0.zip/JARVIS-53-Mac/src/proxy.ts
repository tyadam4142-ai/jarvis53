/**
 * JARVIS 53 — request guard.
 * - Host allow-list protects local desktop endpoints against DNS rebinding.
 * - State-changing requests use same-origin CSRF checks, with explicit CORS only for activation
 *   requests from the local desktop app to the central service.
 * - Hosted server mode cannot execute or inspect customer desktop tools/files.
 */
import { NextResponse, type NextRequest } from 'next/server';

const LOOPBACK = new Set(['127.0.0.1', 'localhost', '[::1]']);
const LOCAL_APP_ORIGINS = new Set(['http://127.0.0.1:3000', 'http://localhost:3000', 'http://[::1]:3000']);

function siteUrlHost(): string {
  try { return new URL(process.env.JARVIS_SITE_URL ?? '').hostname.toLowerCase(); } catch { return ''; }
}
function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));
}
function forbiddenHostPage(blockedHost: string, siteHost: string): NextResponse {
  const shown = blockedHost ? escapeHtml(blockedHost) : '(empty host header)';
  const site = siteHost ? escapeHtml(siteHost) : '53.jarvis53.dynamicrobotics53.com';
  return new NextResponse(`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>403 · Unknown host — JARVIS 53</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#050911;color:#d7e6f0;font:15px/1.6 system-ui;padding:24px}.card{max-width:650px;border:1px solid #634b24;border-radius:16px;background:#0a111d;padding:28px}code{color:#ffd98a;overflow-wrap:anywhere}</style></head><body><main class="card"><p>JARVIS 53 · DYNAMIC ROBOTICS</p><h1>403 — hostname not allowed</h1><p>The host guard rejected <code>${shown}</code>. Allowed application host: <code>${site}</code> plus loopback.</p><p>Correct the DNS/domain and JARVIS_ALLOWED_HOSTS values, then restart the server. Do not add untrusted hostnames.</p></main></body></html>`, { status: 403, headers: { 'content-type': 'text/html; charset=utf-8', 'x-robots-tag': 'noindex' } });
}
function trustedLocalOrigin(raw: string | null): string | null {
  if (!raw) return null;
  try {
    const u = new URL(raw);
    return LOCAL_APP_ORIGINS.has(u.origin) ? u.origin : null;
  } catch { return null; }
}

export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const host = (req.headers.get('host') ?? '').toLowerCase();
  const hostname = host.replace(/:\d+$/, '');
  const allowed = (process.env.JARVIS_ALLOWED_HOSTS ?? '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  const site = siteUrlHost();
  if (site) allowed.push(site);
  if (!LOOPBACK.has(hostname) && !allowed.includes(hostname)) return forbiddenHostPage(host, site);

  const isAdminPath = pathname === '/admin' || pathname.startsWith('/admin/') || pathname.startsWith('/api/admin');
  if (isAdminPath && process.env.JARVIS_ADMIN_MODE !== '1') return new NextResponse('Not found', { status: 404 });

  const hosted = process.env.JARVIS_SERVER_MODE === '1';
  if (hosted) {
    const localOnly = pathname === '/api/tools/execute' || pathname === '/api/system/status' || pathname === '/api/voice/command' ||
      pathname === '/api/preferences' || pathname.startsWith('/api/preferences/') ||
      pathname === '/api/chat/history' || pathname.startsWith('/api/chat/history/') ||
      pathname === '/api/drive' || pathname.startsWith('/api/drive/') || pathname === '/api/local/activation-token' || pathname.startsWith('/api/local/activation-token/');
    if (localOnly) return NextResponse.json({ error: 'This capability is available only in the local desktop installation.' }, { status: 403, headers: { 'Cache-Control': 'no-store' } });
  }

  const origin = req.headers.get('origin');
  const activationPath = pathname === '/api/activation/request' || pathname === '/api/activation/status';
  const localOrigin = activationPath ? trustedLocalOrigin(origin) : null;
  if (activationPath && req.method === 'OPTIONS' && localOrigin) {
    return new NextResponse(null, { status: 204, headers: {
      'Access-Control-Allow-Origin': localOrigin,
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '600', 'Vary': 'Origin',
    } });
  }

  const unsafe = !['GET', 'HEAD', 'OPTIONS'].includes(req.method);
  if (unsafe && pathname.startsWith('/api/')) {
    const fetchSite = req.headers.get('sec-fetch-site');
    let sameOrigin = false;
    if (origin) { try { sameOrigin = new URL(origin).host.toLowerCase() === host; } catch { sameOrigin = false; } }
    else if (fetchSite) sameOrigin = fetchSite === 'same-origin' || fetchSite === 'none';
    if (!sameOrigin && !localOrigin) return NextResponse.json({ error: 'Cross-origin request blocked.' }, { status: 403 });
  }

  const res = NextResponse.next();
  res.headers.set('X-Frame-Options', pathname.startsWith('/api/drive/preview') ? 'SAMEORIGIN' : 'DENY');
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('Referrer-Policy', 'no-referrer');
  res.headers.set('Permissions-Policy', 'camera=(), microphone=(self), geolocation=()');
  if (activationPath && localOrigin) {
    res.headers.set('Access-Control-Allow-Origin', localOrigin);
    res.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.headers.set('Vary', 'Origin');
  }
  return res;
}

export const config = { matcher: ['/((?!_next/static|_next/image|.*\\.(?:svg|png|jpg|jpeg|ico|webp)$).*)'] };
