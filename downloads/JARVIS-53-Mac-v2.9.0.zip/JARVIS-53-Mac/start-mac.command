#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  J53 All Access · Desktop AI Assistant  ·  v2.7.3
#  One-command launcher for macOS · Dynamic Robotics
#  Double-click any time: if JARVIS is already running, this
#  simply reopens the app window — it never kills your session.
# ═══════════════════════════════════════════════════════════════
cd "$(dirname "$0")" || exit 1

CYAN='\033[36m'; GOLD='\033[33m'; RED='\033[31m'; GREEN='\033[32m'; NC='\033[0m'

# ── 0. Already running? Just reopen the window, like a real desktop app. ──
reopen_window() {
  CHROME_BIN="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
  if [ -x "$CHROME_BIN" ]; then
    # Chrome coalesces into the running instance and opens a dedicated
    # chromeless app window (no browser tab, no address bar).
    "$CHROME_BIN" --app="http://127.0.0.1:3000" >/dev/null 2>&1 &
  else
    open "http://127.0.0.1:3000" 2>/dev/null || true
  fi
}

if lsof -iTCP:3000 -sTCP:LISTEN >/dev/null 2>&1; then
  if curl -fs -o /dev/null --max-time 3 "http://127.0.0.1:3000/api/health"; then
    echo -e "${GREEN}[✓] JARVIS 53 is already running.${NC}"
    # Keep the system-wide voice companion alive even if it was killed.
    if [ -x "native/.venv/bin/python" ]; then
      COMPANION_ALIVE=0
      if [ -f native/global-voice.pid ] && kill "$(cat native/global-voice.pid 2>/dev/null)" 2>/dev/null; then
        COMPANION_ALIVE=1
      fi
      if [ "$COMPANION_ALIVE" -eq 0 ]; then
        BRIDGE_TOKEN=$(cat .j53-bridge-token 2>/dev/null || python3 -c 'import secrets; print(secrets.token_hex(32))')
        printf '%s' "$BRIDGE_TOKEN" > .j53-bridge-token; chmod 600 .j53-bridge-token 2>/dev/null || true
        JARVIS_BRIDGE_TOKEN="$BRIDGE_TOKEN" nohup native/.venv/bin/python native/global_voice_bridge.py >> native/global-voice.log 2>&1 &
        echo $! > native/global-voice.pid
        echo -e "${GREEN}[✓] Global voice companion re-attached (hold Right Option ⌥ / Right ⌘ in any app).${NC}"
        echo -e "${GREEN}[✓] Command 53: press ⌘5 then ⌘3 in any app to summon this window.${NC}"
      fi
    fi
    reopen_window
    echo -e "${GOLD}    Welcome back, sir. Window reopened.${NC}"
    exit 0
  else
    echo -e "${GOLD}[!] Port 3000 is busy but not responding — cleaning up the stuck process…${NC}"
    lsof -ti tcp:3000 | xargs kill 2>/dev/null || true
    sleep 1
  fi
fi

# Create a private local configuration from the template only on first launch.
# Existing .env files are preserved so the operator's API keys/settings are never overwritten.
if [ ! -f .env ]; then
  cp .env.example .env || { echo "[X] Could not create .env from .env.example"; exit 1; }
  chmod 600 .env 2>/dev/null || true
  echo "[i] Created local .env from the safe template. Add API keys in Admin → AI Keys."
fi

echo ""
echo -e "${CYAN}  J  5  3   ·   A L L   A C C E S S   ·   v 2 . 7 . 3${NC}"
echo -e "${GOLD}        D Y N A M I C   R O B O T I C S${NC}"
echo ""

# ── 1. Node.js check ──────────────────────────────────────────
if ! command -v node >/dev/null 2>&1; then
  echo -e "${RED}[X] Node.js is not installed.${NC}"
  echo -e "${GOLD}[!] Installing Node.js is a one-click process:${NC}"
  echo "    1. Opening https://nodejs.org in your browser…"
  echo "    2. Download the LTS installer and drag it to Applications."
  echo "    3. Run this file again."
  open "https://nodejs.org" 2>/dev/null
  exit 1
fi
NODE_MAJOR=$(node -e 'console.log(process.versions.node.split(".")[0])')
NODE_MINOR=$(node -e 'console.log(process.versions.node.split(".")[1])')
if [ "$NODE_MAJOR" -lt 20 ] || { [ "$NODE_MAJOR" -eq 20 ] && [ "$NODE_MINOR" -lt 9 ]; }; then
  echo -e "${RED}[X] Node.js 20.9+ is required (you have $(node -v)).${NC}"
  echo -e "${GOLD}[!] Update from https://nodejs.org then run this file again.${NC}"
  exit 1
fi
echo -e "${GREEN}[✓] Node.js $(node -v) detected${NC}"

# ── 2. Dependencies (first run) ───────────────────────────────
if [ ! -d node_modules ]; then
  echo -e "${CYAN}[*] First launch — installing dependencies (2–4 minutes, one time only)…${NC}"
  npm install --no-audit --no-fund || { echo -e "${RED}[X] npm install failed. Check your internet connection.${NC}"; exit 1; }
  echo -e "${GREEN}[✓] Dependencies installed${NC}"
else
  echo -e "${GREEN}[✓] Dependencies ready${NC}"
fi

# ── 3. Database ───────────────────────────────────────────────
echo -e "${CYAN}[*] Preparing the local database…${NC}"
if ! npx prisma db push --skip-generate; then
  echo "[i] Retrying database setup with Prisma client generation enabled…"
  if ! npx prisma db push; then
    echo -e "${RED}[X] Database setup failed. Review the Prisma error above; JARVIS will not start with a broken database.${NC}"
    exit 1
  fi
fi
echo -e "${GREEN}[✓] Database schema ready${NC}"
npx prisma generate || { echo -e "${RED}[X] Prisma client generation failed. Check Node.js and dependencies."; exit 1; }
echo -e "${GREEN}[✓] Prisma client ready${NC}"

# ── 4. Production build (first run) ───────────────────────────
if [ ! -f .next/BUILD_ID ]; then
  echo -e "${CYAN}[*] Compiling JARVIS 53 (one time, ~1 minute)…${NC}"
  npm run build || {
    echo -e "${GOLD}[!] Build hiccup — not starting an unreliable dev fallback.${NC}"
    echo "    Fix the build errors shown above and run this launcher again."
    exit 1
  }
  echo -e "${GREEN}[✓] Compiled${NC}"
fi

# ── 5. Local-only bridge security + global voice companion ────
BRIDGE_TOKEN=$(python3 -c 'import secrets; print(secrets.token_hex(32))' 2>/dev/null || openssl rand -hex 32)
printf '%s' "$BRIDGE_TOKEN" > .j53-bridge-token
chmod 600 .j53-bridge-token 2>/dev/null || true
export JARVIS_BRIDGE_TOKEN="$BRIDGE_TOKEN"

# The global companion is optional: it needs one-time Python dependencies and OS permissions.
# macOS hotkeys: hold Right Option (⌥) or Right Command (⌘) in ANY app to talk.
# (F8 is intentionally not used on macOS — the system maps it to Play/Pause.)
# "Command 53": ⌘5 then ⌘3 re-opens this window from anywhere.
if [ -x "native/.venv/bin/python" ]; then
  if [ -f native/global-voice.pid ]; then kill "$(cat native/global-voice.pid)" 2>/dev/null || true; fi
  nohup native/.venv/bin/python native/global_voice_bridge.py >> native/global-voice.log 2>&1 &
  echo $! > native/global-voice.pid
  echo -e "${GREEN}[✓] Global voice companion started — hold Right Option ⌥ or Right ⌘ in any app (needs Microphone + Input Monitoring permission).${NC}"
  echo -e "${GREEN}[✓] Command 53: press ⌘5 then ⌘3 in any app to summon the JARVIS window.${NC}"
else
  echo "[i] In-browser push-to-talk is ready. For system-wide talk, run native/install-global-voice.command once."
fi

# ── 6. Launch ─────────────────────────────────────────────────
echo ""
echo -e "${CYAN}[*] Waking JARVIS…${NC}"
# Wait until the server really answers, then open a dedicated app window.
( for i in $(seq 1 160); do curl -fs -o /dev/null "http://127.0.0.1:3000/api/health" && break; sleep 0.75; done
  reopen_window ) &
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GOLD}   J53 ALL ACCESS IS LIVE →  http://127.0.0.1:3000${NC}"
echo -e "${GOLD}   In-app: hold SPACE or tap the mic. Any app: hold Right Option ⌥ / Right ⌘ (after voice setup).${NC}"
echo -e "${GOLD}   Summon anytime: ⌘5 then ⌘3 (Command 53). Press ⌘K for the command bar.${NC}"
echo -e "${GOLD}   JARVIS opens in its own window automatically when ready.${NC}"
echo -e "${GOLD}   Keep this window open. To stop: run stop-mac.command${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
npm start
