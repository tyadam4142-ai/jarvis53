/**
 * JARVIS 53 — desktop unit tests (run: bun test tests/).
 * Covers the v2.9.0 fixes: agent-loop plumbing, honest result reporting,
 * new file/dev tool semantics, tool registry/platform consistency.
 */
import { describe, test, expect } from 'bun:test';
import { parseAIJson, formatToolReport, isLoopProgress, jarvisThink } from '../src/lib/ai/provider';
import { TOOLS, TOOL_MAP, toolCatalog } from '../src/lib/tools/registry';
import { filesEdit, devRunCommand, devInspectProject } from '../src/lib/tools/handlers-dev';
import { isPathSafe, resolvePath } from '../src/lib/os';
import { mkdtemp, writeFile, readFile, rm } from 'fs/promises';
import { tmpdir } from 'os';
import path from 'path';

describe('parseAIJson — model output contract', () => {
  test('parses the structured action format', () => {
    const r = parseAIJson('{"say":"Opening Spotify.","actions":[{"tool":"apps.launch","args":{"app":"Spotify"}}]}');
    expect(r?.say).toBe('Opening Spotify.');
    expect(r?.actions[0].tool).toBe('apps.launch');
    expect(r?.actions[0].args.app).toBe('Spotify');
  });

  test('accepts fenced JSON and trailing commas', () => {
    const r = parseAIJson('```json\n{"say":"Done.","actions":[{"tool":"system.mute","args":{}},]}\n```');
    expect(r?.actions.length).toBe(1);
  });

  test('filters unknown tool ids instead of crashing', () => {
    const r = parseAIJson('{"say":"x","actions":[{"tool":"not.a.tool","args":{}},{"tool":"files.read","args":{"path":"~"}}]}');
    expect(r?.actions.length).toBe(1);
  });

  test('ordinary prose answers pass through (no silent provider switching)', () => {
    const r = parseAIJson('The capital of France is Paris.');
    expect(r?.say).toContain('Paris');
    expect(r?.actions).toEqual([]);
  });

  test('JSON-shaped garbage returns null so another provider can try', () => {
    expect(parseAIJson('{"say": "unterminated')).toBeNull();
  });
});

describe('agent loop plumbing — honest tool reporting', () => {
  test('formatToolReport carries status + output and forbids fabrication', () => {
    const report = formatToolReport([
      { tool: 'files.write', status: 'done', output: 'Wrote /tmp/x.py (12 B).', args: {}, label: 'Write File', risk: 'medium', available: true },
      { tool: 'dev.run_command', status: 'error', output: 'exit code: 1', args: {}, label: 'Run Command', risk: 'high', available: true },
    ]);
    expect(report).toContain('files.write → done');
    expect(report).toContain('dev.run_command → error');
    expect(report).toContain('ground truth');
  });

  test('isLoopProgress detects a stalling loop', () => {
    const a = [{ tool: 'files.read', status: 'error' as const, output: 'nope', args: {}, label: '', risk: 'low' as const, available: true }];
    const b = [{ tool: 'files.read', status: 'error' as const, output: 'nope', args: {}, label: '', risk: 'low' as const, available: true }];
    expect(isLoopProgress(a, b)).toBe(false);
    expect(isLoopProgress(a, [{ ...b[0], output: 'fixed' }])).toBe(true);
  });

  test('deterministic local commands still route locally without any network call', async () => {
    const result = await jarvisThink([], 'volume 50');
    expect(result.provider).toBe('offline');
    expect(result.actions[0]?.tool).toBe('system.volume');
  });
});

describe('tool registry — platform and schema integrity', () => {
  test('every tool has valid metadata and at least one platform', () => {
    for (const t of TOOLS) {
      expect(TOOL_MAP[t.id]).toBeTruthy();
      expect(t.os.length).toBeGreaterThan(0);
      expect(['low', 'medium', 'high']).toContain(t.risk);
    }
  });

  test('v2.9.0 coding tools exist with the right risk tiers', () => {
    expect(TOOL_MAP['files.edit'].risk).toBe('medium');
    expect(TOOL_MAP['files.search_content'].risk).toBe('low');
    expect(TOOL_MAP['dev.run_command'].risk).toBe('high');
    expect(TOOL_MAP['dev.inspect_project'].risk).toBe('low');
  });

  test('new tools are advertised to the model on mac and win', () => {
    const mac = toolCatalog('mac');
    expect(mac).toContain('files.edit');
    expect(mac).toContain('dev.run_command');
    const win = toolCatalog('win');
    expect(win).toContain('dev.inspect_project');
  });

  test('system.unmute is available on Windows (BUG-009)', () => {
    expect(TOOL_MAP['system.unmute'].os).toContain('win');
  });
});

describe('files.edit — real in-place editing semantics', () => {
  test('replaces a unique occurrence and reports the count', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'j53-test-'));
    const file = path.join(dir, 'app.py');
    await writeFile(file, "print('hello')\nprint('world')\n");
    const r = await filesEdit({ path: file, find: "print('world')", replace: "print('JARVIS')" });
    expect(r.code).toBe(0);
    expect(r.stdout).toContain('Replaced 1 occurrence');
    const after = await readFile(file, 'utf8');
    expect(after).toContain("print('JARVIS')");
    expect(after).toContain("print('hello')");
    await rm(dir, { recursive: true, force: true });
  });

  test('refuses ambiguous matches without all=true', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'j53-test-'));
    const file = path.join(dir, 'dup.txt');
    await writeFile(file, 'a b a b');
    const r = await filesEdit({ path: file, find: 'a b', replace: 'x' });
    expect(r.code).toBe(1);
    expect(r.stderr).toContain('2 occurrences');
    expect(await readFile(file, 'utf8')).toBe('a b a b');
    const r2 = await filesEdit({ path: file, find: 'a b', replace: 'x', all: true });
    expect(r2.code).toBe(0);
    expect(await readFile(file, 'utf8')).toBe('x x');
    await rm(dir, { recursive: true, force: true });
  });

  test('fails honestly when the text is not found', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'j53-test-'));
    const file = path.join(dir, 'nofind.txt');
    await writeFile(file, 'nothing here');
    const r = await filesEdit({ path: file, find: 'MISSING TEXT', replace: 'y' });
    expect(r.code).toBe(1);
    expect(r.stderr).toContain('was not found');
    await rm(dir, { recursive: true, force: true });
  });
});

describe('dev.run_command — real execution with real exit codes', () => {
  test('runs a successful command and reports its output', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'j53-test-'));
    const r = await devRunCommand({ command: 'echo j53-ok', cwd: dir });
    expect(r.code).toBe(0);
    expect(r.stdout).toContain('exit code: 0');
    expect(r.stdout).toContain('j53-ok');
    await rm(dir, { recursive: true, force: true });
  });

  test('reports a failing command honestly (no fake success)', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'j53-test-'));
    const r = await devRunCommand({ command: 'node -e "process.exit(3)"', cwd: dir });
    expect(r.code).toBe(1);
    expect(r.stderr).toContain('exit code: 3');
    await rm(dir, { recursive: true, force: true });
  });

  test('refuses destructive system commands', async () => {
    for (const bad of ['rm -rf /', 'diskutil eraseDisk JHFSX Disk0 disk0', 'mkfs.ext4 /dev/sda1']) {
      const r = await devRunCommand({ command: bad });
      expect(r.code).toBe(1);
      expect(r.stderr).toMatch(/Refused for safety/i);
    }
  });
});

describe('dev.inspect_project — bounded, honest project summary', () => {
  test('lists real files and manifests without node_modules noise', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'j53-proj-'));
    await writeFile(path.join(dir, 'package.json'), '{"name":"demo","scripts":{"test":"node test.js"}}\n');
    await writeFile(path.join(dir, 'main.js'), 'console.log(1)\n');
    const r = await devInspectProject({ path: dir });
    expect(r.code).toBe(0);
    expect(r.stdout).toContain('main.js');
    expect(r.stdout).toContain('package.json');
    expect(r.stdout).toContain('"name":"demo"');
    await rm(dir, { recursive: true, force: true });
  });
});

describe('path sandbox — traversal and system-location protection', () => {
  test('blocks protected system roots', () => {
    expect(isPathSafe('/etc').safe).toBe(false);
    expect(isPathSafe('/System/Library').safe).toBe(false);
    expect(isPathSafe('C:\\Windows\\System32').safe).toBe(false);
  });
  test('expands ~ to the real home directory', () => {
    expect(resolvePath('~/Documents')).not.toContain('~');
  });
});
