# JARVIS 53 Web App — Server Deployment Guide (v2.7.0)

Deploy the full JARVIS 53 app — console, Studio → Drive, database, and the
**Master Admin portal** — on your own server, then use it from your website
link instead of a local customer install.

---

## 1. What this package is

| Piece | What it does |
|---|---|
| Full JARVIS 53 source (Next.js + Prisma) | The console customers use |
| `db/custom.db` (SQLite, auto-created) | Customers, chat memory, preferences, announcements, tickets, usage — all connected out of the box |
| `.env` — admin **enabled** with your PIN | `/admin` goes live the moment the app starts |
| `workspace/` | The JARVIS Drive — every file & website JARVIS builds lives here |

## 2. Requirements

- A Linux server (Ubuntu 22.04+ or any modern distro) or VPS — 1 vCPU / 1 GB is enough to start
- Node.js **20.9+** (`node -v` to check)
- A domain pointed at the server (e.g. `this.jarvis53.dynamicrobotics53.com`)

## 3. Deploy — five commands

```bash
unzip JARVIS-53-WebApp-v2.7.0.zip && cd JARVIS-53-WebApp
npm install                 # installs deps + generates the Prisma client
npm run db:push             # creates/updates db/custom.db (the database)
npm run build               # production build
npm run start -- -H 0.0.0.0 -p 3000
```

JARVIS is now listening on port `3000`.

## 4. Point your domain at it

**Option A — reverse proxy (recommended).** Nginx / Caddy / your host's proxy:
proxy `https://your-domain` → `http://127.0.0.1:3000`. Enable HTTPS
(`certbot --nginx` on Ubuntu). The app itself binds loopback by default, so
only your proxy reaches it.

**Option B — direct.** Run `npm run start -- -H 0.0.0.0 -p 3000` and open
`http://SERVER-IP:3000` (avoid on public networks; use Option A).

> ⚠️ After changing your domain, set it in `.env` → `JARVIS_ALLOWED_HOSTS`
> (comma separated, no `https://`). The request guard **403s unknown hosts** —
> that is a security feature, not a bug. Restart the app after editing.

## 5. Open your Admin portal

1. Visit **`https://YOUR-DOMAIN/admin`**
2. Sign in with the master PIN from `.env` (`JARVIS_ADMIN_PIN`) — it is also
   printed in **ADMIN-ACCESS.txt** in this package
3. First stop: **Admin → AI Keys** — add at least one OpenRouter / NVIDIA NIM /
   Google Gemini key. Chat, concierge and site-building run on this key pool.

Inside the portal: Dashboard · Customers (approve activations & payments) ·
Support Inbox (+ AI draft replies) · Key Pool · Broadcast · Settings (change
master PIN, prices, UPI, payment instructions) · Export.

Admin is protected by: hostname allow-list, origin/CSRF guard, PIN throttling
(5 wrong tries → 5-minute lock), and a 4-hour session cookie. Customer
installs keep `/admin` nonexistent (404) — only your server has it on.

## 6. JARVIS Drive on the server

Everything customers ask JARVIS to build — websites, files, documents — lands
in `workspace/<customer-phone>/`. Customers browse it live in
**Studio → Drive** (sandboxed preview + one-click zip). Back up `db/` +
`workspace/` together. Prefer a bigger disk? Set `JARVIS_DRIVE_DIR` in `.env`.

## 7. Keep it running

```bash
npm i -g pm2
pm2 start "npm run start" --name jarvis53
pm2 startup && pm2 save       # auto-start on reboot
```

## 8. Updating later

Replace the source folders (`src/`, `public/`, `prisma/`, `package.json`),
then: `npm install && npm run db:push && npm run build && pm2 restart jarvis53`.
Chat history and customers live in `db/custom.db` and survive updates.

— Dynamic Robotics · J53 All Access
