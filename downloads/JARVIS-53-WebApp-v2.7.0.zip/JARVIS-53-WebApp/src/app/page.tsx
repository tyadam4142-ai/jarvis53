'use client';

/**
 * JARVIS 53 — HUD shell (customer-facing).
 * boot sequence → activation gate → main console (console / studio / support).
 * The Master Admin portal lives on a separate, unlisted route: /admin
 */
import { useEffect, useState } from 'react';
import { useJarvis, loadAppearance, applyAppearance } from '@/components/jarvis/store';
import ArcReactor from '@/components/jarvis/ArcReactor';
import Boot from '@/components/jarvis/Boot';
import Activation from '@/components/jarvis/Activation';
import Chat from '@/components/jarvis/Chat';
import { ActivityFeed, Diagnostics, QuickActions } from '@/components/jarvis/Panels';
import Concierge from '@/components/jarvis/Concierge';
import Studio from '@/components/jarvis/Studio';
import Comms from '@/components/jarvis/Comms';
import Customize from '@/components/jarvis/Customize';
import CommandBar from '@/components/jarvis/CommandBar';
import { Megaphone, Terminal, ListChecks, LifeBuoy, MessageSquare, Palette, X, Command } from 'lucide-react';

function TopBar() {
  const view = useJarvis((s) => s.view);
  const setView = useJarvis((s) => s.setView);
  const health = useJarvis((s) => s.health);
  const announcement = useJarvis((s) => s.announcement);
  const setAnnouncement = useJarvis((s) => s.setAnnouncement);
  const [clock, setClock] = useState('');

  useEffect(() => {
    const tick = () => setClock(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);

  const nav = [
    ['console', <Terminal key="c" className="h-3.5 w-3.5" />, 'Console'],
    ['comms', <MessageSquare key="m" className="h-3.5 w-3.5" />, 'Comms'],
    ['studio', <ListChecks key="s" className="h-3.5 w-3.5" />, 'Studio'],
    ['support', <LifeBuoy key="h" className="h-3.5 w-3.5" />, 'Support'],
  ] as const;

  return (
    <header className="relative z-10 border-b border-[rgba(var(--j53-accent-rgb),0.1)] bg-[rgba(var(--j53-bg-rgb),0.6)] backdrop-blur-md">
      {announcement && (
        <div
          className="flex items-center justify-center gap-2 px-4 py-1.5 text-[12px]"
          style={{ background: announcement.level === 'warning' ? 'rgba(var(--j53-gold-rgb),0.1)' : announcement.level === 'success' ? 'rgba(var(--j53-green-rgb),0.1)' : 'rgba(var(--j53-accent-rgb),0.08)', color: announcement.level === 'warning' ? 'var(--j53-gold)' : announcement.level === 'success' ? 'var(--j53-green)' : 'var(--j53-accent)' }}
        >
          <Megaphone className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate">
            <strong>{announcement.title}</strong> — {announcement.body}
          </span>
          <button onClick={() => setAnnouncement(null)} aria-label="Dismiss announcement" type="button">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4 py-2.5 sm:px-5">
        <div className="flex items-center gap-3">
          <img src="/j53-logo.svg" alt="J53" className="h-10 w-10 shrink-0 drop-shadow-[0_0_14px_rgba(229,178,75,0.25)]" />
          <div>
            <p className="j53-display text-[13px] font-bold tracking-[0.2em] text-[var(--j53-text)]">
              J53 <span className="text-[var(--j53-accent)]">ALL ACCESS</span>
            </p>
            <p className="j53-label" style={{ fontSize: 7.5 }}>
              dynamic robotics
            </p>
          </div>
          {health && (
            <div className="ml-2 hidden items-center gap-1.5 lg:flex">
              <span className="j53-pill j53-pill--live" style={{ fontSize: 8 }}>
                ● ONLINE
              </span>
              <span className="j53-pill" style={{ fontSize: 8 }}>
                {health.toolCount} TOOLS
              </span>
              <span className="j53-pill" style={{ fontSize: 8 }}>
                {health.platform === 'mac' ? 'macOS' : health.platform === 'win' ? 'WINDOWS' : 'SERVER'}
              </span>
            </div>
          )}
        </div>

        <nav className="flex items-center gap-1.5" aria-label="Main views">
          <button className="j53-pill hidden cursor-pointer md:flex" onClick={() => useJarvis.getState().setCmdOpen(true)} style={{ cursor: 'pointer' }} type="button">
            <Command className="h-3 w-3" /> K
          </button>
          <button
            className="j53-pill cursor-pointer"
            style={{ cursor: 'pointer', color: 'var(--j53-accent)', borderColor: 'rgba(var(--j53-accent-rgb),0.35)' }}
            onClick={() => useJarvis.getState().setCustomizeOpen(true)}
            aria-label="Open appearance lab"
            title="Customize — themes, accent, glow, effects"
            type="button"
          >
            <Palette className="h-3 w-3" />
            <span className="hidden lg:inline">Customize</span>
          </button>
          {nav.map(([id, icon, label]) => (
            <button
              key={id}
              className={`j53-btn ${view === id ? 'j53-glow' : ''}`}
              style={{ padding: '7px 12px' }}
              onClick={() => setView(id)}
              aria-current={view === id}
              type="button"
            >
              {icon} <span className="hidden sm:inline">{label}</span>
            </button>
          ))}
          <span className="j53-pill ml-1 hidden font-mono sm:flex" style={{ color: 'var(--j53-accent)' }}>
            {clock}
          </span>
        </nav>
      </div>
    </header>
  );
}

function Hud() {
  const view = useJarvis((s) => s.view);
  const orbMode = useJarvis((s) => s.orbMode);
  const systemStatus = useJarvis((s) => s.systemStatus);
  const [toolToast, setToolToast] = useState<string | null>(null);

  // Poll diagnostics + health
  useEffect(() => {
    const loadStatus = () =>
      fetch('/api/system/status', { cache: 'no-store' })
        .then((r) => r.json())
        .then((d) => useJarvis.getState().setSystemStatus(d))
        .catch(() => undefined);
    const loadHealth = () =>
      fetch('/api/health', { cache: 'no-store' })
        .then((r) => r.json())
        .then((d) => useJarvis.getState().setHealth(d))
        .catch(() => undefined);
    loadStatus();
    loadHealth();
    const t = setInterval(loadStatus, 15000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="flex min-h-screen flex-col">
      <TopBar />

      <main className="relative z-10 mx-auto w-full max-w-7xl flex-1 px-3 py-4 sm:px-5">
        {view === 'studio' ? (
          <Studio />
        ) : view === 'comms' ? (
          <Comms />
        ) : (
          <div className="grid gap-4 lg:grid-cols-[270px_minmax(0,1fr)] xl:grid-cols-[270px_minmax(0,1fr)_330px]">
            {/* left rail */}
            <aside className={`space-y-4 ${view === 'support' ? 'hidden lg:block' : ''}`}>
              <div className="j53-panel j53-glow flex flex-col items-center gap-1.5 p-5">
                <ArcReactor size={168} />
                <p className="j53-display mt-1 text-[12px] tracking-[0.24em] text-[var(--j53-accent)]">
                  {orbMode === 'listening' ? 'LISTENING…' : orbMode === 'thinking' ? 'PROCESSING' : orbMode === 'speaking' ? 'RESPONDING' : 'STANDBY'}
                </p>
                <p className="j53-label" style={{ fontSize: 8 }}>
                  {systemStatus?.host ?? 'neural core'} · J53 v2.7.0
                </p>
              </div>
              <Diagnostics />
            </aside>

            {/* center */}
            <section className={`min-h-[58vh] lg:min-h-[72vh] ${view === 'support' ? 'hidden lg:block' : ''}`}>
              <div className="j53-panel flex h-full min-h-[58vh] flex-col p-4 lg:min-h-[72vh]">
                <Chat />
              </div>
            </section>

            {/* right rail */}
            <aside className={`space-y-4 ${view === 'console' ? 'hidden xl:block' : 'xl:block'} ${view === 'support' ? 'block' : ''}`}>
              {view === 'support' ? (
                <div className="j53-panel h-[72vh] p-4">
                  <Concierge />
                </div>
              ) : (
                <>
                  <QuickActions onResult={setToolToast} />
                  <ActivityFeed />
                </>
              )}
            </aside>
          </div>
        )}

        {/* quick-action result toast */}
        {toolToast && (
          <div className="j53-panel j53-fadeup fixed bottom-5 left-1/2 z-40 max-h-40 w-[min(92vw,560px)] -translate-x-1/2 overflow-y-auto p-4" role="status">
            <div className="flex items-start justify-between gap-3">
              <p className="whitespace-pre-wrap font-mono text-[12px] leading-5 text-[var(--j53-text-2)]">{toolToast}</p>
              <button onClick={() => setToolToast(null)} aria-label="Dismiss" type="button">
                <X className="h-4 w-4 text-[var(--j53-muted)]" />
              </button>
            </div>
          </div>
        )}
      </main>

      <footer className="relative z-10 border-t border-[rgba(var(--j53-accent-rgb),0.08)] bg-[rgba(var(--j53-bg-rgb),0.55)] py-3">
        <p className="j53-label text-center">
          J53 All Access v2.7.0 · <a href="https://dynamicrobotics53.com" target="_blank" rel="noreferrer" className="text-[var(--j53-accent)]/70 transition-colors hover:text-[var(--j53-accent)]">dynamicrobotics53.com</a> · just a rather very intelligent system
        </p>
      </footer>

      <CommandBar />
      <Customize />
    </div>
  );
}

export default function Page() {
  const phase = useJarvis((s) => s.phase);

  // Restore saved appearance before first paint of any phase
  useEffect(() => {
    const saved = loadAppearance();
    applyAppearance(saved);
    useJarvis.setState({ appearance: saved });
  }, []);

  // Pre-warm announcement + hydrate database-backed memory when phase resolves
  useEffect(() => {
    if (phase !== 'app') return;
    void useJarvis.getState().hydrate();
    fetch('/api/announcements/active', { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => {
        if (d.announcement) useJarvis.getState().setAnnouncement(d.announcement);
      })
      .catch(() => undefined);
  }, [phase]);

  return (
    <div className="j53-root">
      {phase === 'boot' && <Boot />}
      {phase === 'gate' && <Activation />}
      {phase === 'app' && <Hud />}
    </div>
  );
}
