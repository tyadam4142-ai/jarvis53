@echo off
REM JARVIS 53 - system diagnostic for Windows
title JARVIS 53 - Doctor
cd /d "%~dp0"
color 0B
echo.
echo  ============ JARVIS 53 . SYSTEM DOCTOR ============
echo.

where node >nul 2>nul
if errorlevel 1 (
  color 0C
  echo [X] Node.js missing - install the LTS from nodejs.org
) else (
  echo [OK] Node.js:
  node -v
  for /f "tokens=1 delims=." %%v in ('node -v') do set NODEV=%%v
  set NODEV=%NODEV:v=%
  if %NODEV% LSS 18 echo [!] Node.js 20.9+ recommended - update from nodejs.org
)
where npm >nul 2>nul && (echo [OK] npm present) || (echo [X] npm missing)

if exist node_modules (echo [OK] Dependencies installed) else (echo [!] Dependencies not installed - run start-windows.bat first)
if exist ".next\BUILD_ID" (echo [OK] Production build present) else (echo [!] No build yet - start-windows.bat creates it)
if exist "db\custom.db" (echo [OK] Database file present) else (echo [!] Database not initialized yet)

netstat -aon | findstr :3000 | findstr LISTENING >nul 2>nul
if errorlevel 1 (echo [OK] Port 3000 is free) else (echo [!] Port 3000 busy - run stop-windows.bat first)

echo.
echo TIP: Windows SmartScreen may warn on first run - click "More info" then "Run anyway".
echo.
pause
