@echo off
setlocal
cd /d "%~dp0\.."
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.10+ is required. Install it from https://www.python.org/downloads/windows/ and select "Add Python to PATH".
  start "" https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
  echo Python 3.10+ is required. Current Python version is too old.
  pause
  exit /b 1
)
if not exist "native\.venv\Scripts\python.exe" py -3 -m venv native\.venv
call "native\.venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error
call "native\.venv\Scripts\python.exe" -m pip install -r native\requirements.txt
if errorlevel 1 goto :error
echo.
echo Preparing local English speech model (base.en). This happens once.
call "native\.venv\Scripts\python.exe" -c "from faster_whisper import WhisperModel; WhisperModel('base.en', device='cpu', compute_type='int8'); print('Local speech model is ready.')"
if errorlevel 1 goto :error
echo.
echo GLOBAL VOICE SETUP COMPLETE
 echo 1. In Windows Settings, allow microphone access for desktop apps.
 echo 2. Restart JARVIS using start-windows.bat.
 echo 3. Hold F8 while speaking in another app, then release to run the command.
 echo    Prefer a different key? Set JARVIS_HOTKEY, e.g. right_ctrl or caps_lock.
echo Audio transcription runs locally. The chosen AI provider may be online according to your plan.
pause
exit /b 0
:error
echo.
echo The global voice dependencies could not be installed. Check Python and internet connectivity, then retry.
pause
exit /b 1
