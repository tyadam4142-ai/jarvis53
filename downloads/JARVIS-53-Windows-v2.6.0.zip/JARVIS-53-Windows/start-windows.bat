@echo off
REM ═══════════════════════════════════════════════════════════════
REM  J53 All Access - Desktop AI Assistant  ·  v2.6.0
REM  One-command launcher for Windows - Dynamic Robotics
REM  Double-click any time: if JARVIS is already running, this
REM  simply reopens the app window - it never kills your session.
REM ═══════════════════════════════════════════════════════════════
title JARVIS 53 - Dynamic Robotics
cd /d "%~dp0"

REM -- 0. Already running? Reopen the window like a real desktop app. ----
netstat -aon | findstr :3000 | findstr LISTENING >nul 2>nul
if not errorlevel 1 (
  powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 'http://127.0.0.1:3000/api/health' | Out-Null; exit 0 } catch { exit 1 }"
  if not errorlevel 1 (
    color 0A
    echo [OK] JARVIS 53 is already running. Reopening the app window...
    powershell -NoProfile -Command "$c=@(\"$env:ProgramFiles\Google\Chrome\Application\chrome.exe\",\"${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe\",\"$env:LocalAppData\Google\Chrome\Application\chrome.exe\") | Where-Object { Test-Path $_ } | Select-Object -First 1; if($c){ Start-Process $c '--app=http://127.0.0.1:3000' } else { try { Start-Process 'msedge.exe' '--app=http://127.0.0.1:3000' } catch { Start-Process 'http://127.0.0.1:3000' } }"
    echo     Welcome back, sir. Window reopened.
    timeout /t 2 /nobreak >nul
    exit /b 0
  )
  echo [!] Port 3000 is busy but not responding - cleaning up the stuck process...
  for /f "tokens=5" %%p in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do taskkill /PID %%p /F >nul 2>nul
  timeout /t 2 /nobreak >nul
)

REM Create a safe local environment file only on first launch. Never overwrite existing user keys.
if not exist ".env" (
  copy /Y ".env.example" ".env" >nul
  if errorlevel 1 (
    color 0C
    echo [X] Could not create .env from .env.example.
    pause
    exit /b 1
  )
  echo [i] Created local .env from the safe template. Add API keys in Admin - AI Keys.
)
color 06
echo.
echo   J  5  3   -   A L L   A C C E S S   -   v 2 . 6 . 0
echo         D Y N A M I C   R O B O T I C S
echo.

REM -- 1. Node.js check ------------------------------------------------
where node >nul 2>nul
if errorlevel 1 (
  color 0C
  echo [X] Node.js is not installed.
  echo [!] Opening https://nodejs.org - download the LTS, click Next-Next-Next,
  echo     then double-click start-windows.bat again.
  start "" https://nodejs.org
  pause
  exit /b 1
)
powershell -NoProfile -Command "if ([version]((node -v).TrimStart('v')) -lt [version]'20.9.0') { exit 1 }"
if errorlevel 1 (
  color 0C
  echo [X] Node.js 20.9+ is required. You have:
  node -v
  echo [!] Install the current LTS from https://nodejs.org then run this file again.
  pause
  exit /b 1
)
color 06
echo [OK] Node.js detected:
node -v

REM -- 2. Dependencies (first run) --------------------------------------
if not exist node_modules (
  echo [*] First launch - installing dependencies. This is ONE TIME only, about 2-4 minutes.
  echo     Go grab a coffee. JARVIS will be ready when you are back.
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    color 0C
    echo [X] npm install failed - check your internet connection and try again.
    pause
    exit /b 1
  )
  echo [OK] Dependencies installed.
) else (
  echo [OK] Dependencies ready.
)

REM -- 3. Database -------------------------------------------------------
echo [*] Preparing the local database...
call npx prisma db push --skip-generate
if errorlevel 1 (
  echo [i] Retrying database setup with Prisma client generation enabled...
  call npx prisma db push
  if errorlevel 1 (
    color 0C
    echo [X] Database setup failed. Review the Prisma error above; JARVIS will not start with a broken database.
    pause
    exit /b 1
  )
)
echo [OK] Database schema ready.
call npx prisma generate
if errorlevel 1 (
  color 0C
  echo [X] Prisma client generation failed.
  pause
  exit /b 1
)
echo [OK] Prisma client ready.

REM -- 4. Production build (first run) -----------------------------------
if not exist ".next\BUILD_ID" (
  echo [*] Compiling JARVIS 53. One time only, about 1 minute...
  call npm run build
  if not exist ".next\BUILD_ID" (
    color 0E
    echo [!] Build failed. The app will NOT start in an unreliable dev fallback.
    echo     Fix the build errors above and run this launcher again.
    pause
    exit /b 1
  )
  echo [OK] Compiled.
)

REM -- 5. Secure local bridge + optional system-wide voice ----------------
for /f %%t in ('powershell -NoProfile -Command "[guid]::NewGuid().ToString() + [guid]::NewGuid().ToString()"') do set JARVIS_BRIDGE_TOKEN=%%t
echo %JARVIS_BRIDGE_TOKEN%> .j53-bridge-token
if exist "native\.venv\Scripts\python.exe" (
  powershell -NoProfile -Command "$p=Start-Process -FilePath 'native\.venv\Scripts\python.exe' -ArgumentList 'native\global_voice_bridge.py' -WorkingDirectory (Get-Location).Path -PassThru -WindowStyle Hidden; $p.Id | Set-Content 'native\global-voice.pid'"
  echo [OK] Global voice companion started - hold F8 in any app.
) else (
  echo [i] For system-wide F8 talk, run native\install-global-voice.bat once.
)

REM -- 6. Launch ---------------------------------------------------------
echo [*] Waking JARVIS...
netstat -aon | findstr :3000 | findstr LISTENING >nul 2>nul
if not errorlevel 1 (
  color 0C
  echo [X] Port 3000 is already in use. Run stop-windows.bat, then start again.
  pause
  exit /b 1
)
REM Wait until the server really answers, then open a dedicated app window (no browser tab).
start "" /min powershell -NoProfile -WindowStyle Hidden -Command "$u='http://127.0.0.1:3000/api/health'; for($i=0;$i -lt 160;$i++){ try{ Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 $u | Out-Null; break }catch{ Start-Sleep -Milliseconds 750 } }; $c=@(\"$env:ProgramFiles\Google\Chrome\Application\chrome.exe\",\"${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe\",\"$env:LocalAppData\Google\Chrome\Application\chrome.exe\") | Where-Object { Test-Path $_ } | Select-Object -First 1; if($c){ Start-Process $c '--app=http://127.0.0.1:3000' } else { try { Start-Process 'msedge.exe' '--app=http://127.0.0.1:3000' } catch { Start-Process 'http://127.0.0.1:3000' } }"
color 0A
echo.
echo ============================================================
echo    J53 ALL ACCESS IS LIVE  -^>  http://127.0.0.1:3000
echo    In-app: hold SPACE or tap the mic. Any app: hold F8 after voice setup. Press Ctrl+K for the command bar.
echo    JARVIS opens in its own window automatically when ready.
echo    Keep this window open. To stop: stop-windows.bat
echo ============================================================
call npm start
pause
