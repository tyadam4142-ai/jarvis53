@echo off
REM JARVIS 53 - stops the local server (port 3000)
title JARVIS 53 - Stop
set FOUND=0
if exist "native\global-voice.pid" (
  for /f %%p in (native\global-voice.pid) do taskkill /F /PID %%p >nul 2>nul
  del "native\global-voice.pid" >nul 2>nul
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do (
  taskkill /F /PID %%a >nul 2>nul
  set FOUND=1
)
if %FOUND%==1 (
  echo [OK] JARVIS 53 powered down. See you soon.
) else (
  echo [OK] JARVIS 53 is not running.
)
pause
