# JARVIS 53 All Access v2.9.0 — Windows

JARVIS 53 by Dynamic Robotics combines local computer actions with hosted AI and centrally managed subscription access.

## Quick install

1. Install Node.js 22 LTS (20.9+ minimum): https://nodejs.org
2. Extract this ZIP into a normal folder you can write to.
3. On Windows, launch `start-windows.bat`.
4. The first launch creates a private `.env`, installs dependencies and builds the local dashboard. It needs an internet connection for package installation and hosted activation/AI.
5. Open `http://127.0.0.1:3000` if the browser does not open automatically. The desktop server binds to loopback; do not expose port 3000 to your network.
6. Submit the payment reference in J53 All Access. Access is granted only after the owner verifies the payment on the central admin server.

## Correct production hostnames

- Marketing website: `https://jarvis53.dynamicrobotics53.com`
- Application server, activation, AI and owner admin: `https://53.jarvis53.dynamicrobotics53.com`
- Owner admin portal: `https://53.jarvis53.dynamicrobotics53.com/admin`

Customer installs already point to the application server. Do not add AI API keys to this desktop package. The product owner configures provider keys privately in Admin → AI Keys on the central server. Never send your activation token or `.env` to anyone except when an official support workflow specifically instructs you.

## Local vs hosted behavior

- Approved cloud AI requests, message drafts, and concierge responses go through the central server and require an active account and installation activation token.
- Computer-control tools execute on the customer's own computer, never on the hosted VPS.
- Local UI/settings and file tools are available locally. AI generation and activation require network access; this build does not promise offline cloud inference.
- WhatsApp and email are drafts/handoffs. JARVIS does not automatically send the final message.

## Troubleshooting

- **Activation server unreachable:** verify internet access and that `https://53.jarvis53.dynamicrobotics53.com` has working DNS/HTTPS.
- **Token invalid after support reset:** enter the one-time token provided privately by the owner in the Activation screen.
- **Port 3000 already in use:** close the other JARVIS process or another service using port 3000, then relaunch.
- **First build fails:** check Node is 20.9+ (Node 22 LTS recommended), ensure the computer has internet, then run the launcher again. Do not delete `db/custom.db` or `workspace/` to fix a build error.

See `RELEASE-NOTES-v2.9.0.md` for the changes and migration notes.
