@echo off
REM ═══════════════════════════════════════════════════════════════
REM  JARVIS 53 · MAKE-DB (Windows) — create / update the database
REM  Double-click this file, or run it from a terminal inside the
REM  JARVIS-53-WebApp folder. Safe to re-run — never deletes data.
REM ═══════════════════════════════════════════════════════════════
setlocal
cd /d "%~dp0"
if not exist .env copy /Y .env.example .env >nul

REM Back up existing SQLite data before a schema update.
if exist db\custom.db (
  if not exist backups mkdir backups
  for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMddTHHmmssZ"') do set STAMP=%%i
  if not defined STAMP set STAMP=manual
  copy /y db\custom.db backups\custom.db.%STAMP%.bak >nul
  if errorlevel 1 (echo ERROR: Database backup failed. Stopping.& exit /b 1)
  echo Database backup: backups\custom.db.%STAMP%.bak
)

echo ── JARVIS 53 · database setup ──────────────────────────

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed.
  echo        Install Node.js 20.9 or newer:  https://nodejs.org
  pause
  exit /b 1
)
for /f "tokens=* usebackq" %%v in (`node -v`) do set NODE_V=%%v
echo Node.js: %NODE_V%

REM Always use the DATABASE_URL from this folder's .env so a stray global
REM environment variable can never create the DB somewhere else.
if exist .env (
  for /f "usebackq eol=# tokens=1,* delims==" %%a in (`findstr /b /l "DATABASE_URL=" .env`) do set DATABASE_URL=%%b
)
set DATABASE_URL=%DATABASE_URL:"=%
if defined DATABASE_URL echo Database path ^(from .env^): %DATABASE_URL%

if not exist node_modules (
  echo Installing dependencies ^(first run only^)...
  call npm install --no-audit --no-fund
  if errorlevel 1 exit /b 1
) else (
  echo Dependencies: already installed
)

echo Generating Prisma client...
call npx prisma generate
if errorlevel 1 exit /b 1
echo Creating database tables ^(db\custom.db^)...
call npx prisma db push
if errorlevel 1 exit /b 1

echo.
echo ── Database ready: db\custom.db ──
echo.
echo NEXT STEPS
echo   npm run build           ^(production build^)
echo   npm run start:server    ^(start on 0.0.0.0:3000^)
echo   open https://53.jarvis53.dynamicrobotics53.com/admin  ^(PIN in private JARVIS_ADMIN_PIN in .env^)
pause
